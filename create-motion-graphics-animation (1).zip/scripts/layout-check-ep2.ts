/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * layout-check.ts — بررسیِ خودکارِ سرریز و برخوردِ متن‌ها با دنبال‌کردنِ ماتریسِ تبدیل
 */
import { drawEp2Frame } from '../src/motion2/renderer2';
import { EP2_CHAPTERS as MOTION_CHAPTERS } from '../src/motion2/timeline2';

const W = 1280;
const H = 720;
const TOP_SAFE = 86;
const BOTTOM_SAFE = 604;

type M = { a: number; b: number; c: number; d: number; e: number; f: number };
const ID = (): M => ({ a: 1, b: 0, c: 0, d: 1, e: 0, f: 0 });
const mul = (m: M, n: M): M => ({
  a: m.a * n.a + m.c * n.b,
  b: m.b * n.a + m.d * n.b,
  c: m.a * n.c + m.c * n.d,
  d: m.b * n.c + m.d * n.d,
  e: m.a * n.e + m.c * n.f + m.e,
  f: m.b * n.e + m.d * n.f + m.f,
});
const apply = (m: M, x: number, y: number) => ({ x: m.a * x + m.c * y + m.e, y: m.b * x + m.d * y + m.f });

interface Item {
  text: string;
  left: number;
  top: number;
  right: number;
  bottom: number;
  t: number;
}

let items: Item[] = [];
let currentT = 0;
const problems: string[] = [];

function parseFont(font: string) {
  return Number(/(\d+(?:\.\d+)?)px/.exec(font)?.[1] ?? '20');
}

function makeCtx() {
  const stack: Array<{ m: M; alpha: number }> = [];
  const st = {
    m: ID(),
    alpha: 1,
    font: '400 20px "Vazirmatn"',
    textAlign: 'center',
    textBaseline: 'middle',
  };
  const grad = () => ({ addColorStop: () => undefined });

  const api: Record<string, (...a: any[]) => any> = {
    save: () => stack.push({ m: { ...st.m }, alpha: st.alpha }),
    restore: () => {
      const s = stack.pop();
      if (s) {
        st.m = s.m;
        st.alpha = s.alpha;
      }
    },
    translate: (x: number, y: number) => {
      st.m = mul(st.m, { a: 1, b: 0, c: 0, d: 1, e: x, f: y });
    },
    scale: (x: number, y: number) => {
      st.m = mul(st.m, { a: x, b: 0, c: 0, d: y ?? x, e: 0, f: 0 });
    },
    rotate: (r: number) => {
      st.m = mul(st.m, { a: Math.cos(r), b: Math.sin(r), c: -Math.sin(r), d: Math.cos(r), e: 0, f: 0 });
    },
    setTransform: () => {
      st.m = ID();
    },
    resetTransform: () => {
      st.m = ID();
    },
    createLinearGradient: grad,
    createRadialGradient: grad,
    measureText: (text: string) => ({ width: String(text).length * parseFont(st.font) * 0.52 }),
    fillText: (text: string, x: number, y: number) => {
      const size = parseFont(st.font);
      const sx = Math.hypot(st.m.a, st.m.b) || 0.0001;
      const w = String(text).length * size * 0.52 * sx;
      const h = size * 1.25 * (Math.hypot(st.m.b, st.m.d) || sx);
      let lx = x;
      if (st.textAlign === 'center') lx = x - (String(text).length * size * 0.52) / 2;
      else if (st.textAlign === 'right') lx = x - String(text).length * size * 0.52;
      const p1 = apply(st.m, lx, y - size * 0.62);
      const p2 = apply(st.m, lx + String(text).length * size * 0.52, y + size * 0.62);
      const sc = Math.hypot(st.m.a, st.m.b);
      if (st.alpha < 0.06 || sc < 0.15) return;
      items.push({
        text: String(text),
        left: Math.min(p1.x, p2.x),
        top: Math.min(p1.y, p2.y),
        right: Math.max(p1.x, p2.x),
        bottom: Math.max(p1.y, p2.y),
        t: currentT,
      });
    },
  };

  return new Proxy(
    {
      font: st.font,
      textAlign: st.textAlign,
      textBaseline: st.textBaseline,
      globalAlpha: 1,
      direction: 'rtl',
    } as any,
    {
      get(t, p: string) {
        if (p in api) return api[p];
        if (p === 'canvas') return { width: W, height: H };
        if (p === 'globalAlpha') return st.alpha;
        if (p === 'font') return st.font;
        if (p === 'textAlign') return st.textAlign;
        if (p === 'textBaseline') return st.textBaseline;
        if (p in t) return t[p];
        return () => undefined;
      },
      set(t, p: string, v) {
        if (p === 'globalAlpha') st.alpha = Number(v);
        else if (p === 'font') st.font = String(v);
        else if (p === 'textAlign') st.textAlign = String(v);
        else if (p === 'textBaseline') st.textBaseline = String(v);
        t[p] = v;
        return true;
      },
    },
  ) as any;
}

const ctx = makeCtx();

for (const ch of MOTION_CHAPTERS) {
  for (let k = 0; k <= 8; k++) {
    const t = ch.start + ((ch.end - ch.start) * k) / 8;
    currentT = t;
    items = [];
    drawEp2Frame(ctx, t, W, H, 0.4, { showSubtitles: false, showHud: false });
    for (const it of items) {
      if (it.left < 2 || it.right > W - 2)
        problems.push(`t=${it.t.toFixed(1)} OUT-X «${it.text}» [${it.left.toFixed(0)}..${it.right.toFixed(0)}]`);
      if (it.top < 2 || it.bottom > H - 2)
        problems.push(`t=${it.t.toFixed(1)} OUT-Y «${it.text}» [${it.top.toFixed(0)}..${it.bottom.toFixed(0)}]`);
      if (it.top < TOP_SAFE && it.bottom > 8)
        problems.push(`t=${it.t.toFixed(1)} HUD «${it.text}» top=${it.top.toFixed(0)}`);
      if (it.bottom > BOTTOM_SAFE)
        problems.push(`t=${it.t.toFixed(1)} SUBS «${it.text}» bottom=${it.bottom.toFixed(0)}`);
    }
    // برخوردِ متن‌ها با یکدیگر
    for (let i = 0; i < items.length; i++) {
      for (let j = i + 1; j < items.length; j++) {
        const A = items[i];
        const B = items[j];
        const ox = Math.min(A.right, B.right) - Math.max(A.left, B.left);
        const oy = Math.min(A.bottom, B.bottom) - Math.max(A.top, B.top);
        if (ox <= 2 || oy <= 2) continue;
        const areaA = Math.max(1, (A.right - A.left) * (A.bottom - A.top));
        const areaB = Math.max(1, (B.right - B.left) * (B.bottom - B.top));
        const ratio = (ox * oy) / Math.min(areaA, areaB);
        if (ratio > 0.45)
          problems.push(`t=${t.toFixed(1)} OVERLAP «${A.text}» × «${B.text}» (${(ratio * 100).toFixed(0)}٪)`);
      }
    }
  }
}

/* ---- پاسِ دوم: خودِ HUD و زیرنویس هم سرریز نکنند ---- */
const hudProblems: string[] = [];
for (const ch of MOTION_CHAPTERS) {
  for (let k = 0; k <= 4; k++) {
    const t = ch.start + ((ch.end - ch.start) * k) / 4;
    currentT = t;
    items = [];
    drawEp2Frame(ctx, t, W, H, 0.4, { showSubtitles: true, showHud: true });
    for (const it of items) {
      if (it.left < 2 || it.right > W - 2)
        hudProblems.push(`t=${it.t.toFixed(1)} OUT-X «${it.text}» [${it.left.toFixed(0)}..${it.right.toFixed(0)}]`);
      if (it.top < 0 || it.bottom > H)
        hudProblems.push(`t=${it.t.toFixed(1)} OUT-Y «${it.text}» [${it.top.toFixed(0)}..${it.bottom.toFixed(0)}]`);
    }
  }
}

const uniq = Array.from(new Set(problems));
const uniqHud = Array.from(new Set(hudProblems));
console.log('scene problems :', uniq.length);
uniq.slice(0, 40).forEach((p) => console.log('  ' + p));
console.log('hud/sub problems:', uniqHud.length);
uniqHud.slice(0, 40).forEach((p) => console.log('  ' + p));
