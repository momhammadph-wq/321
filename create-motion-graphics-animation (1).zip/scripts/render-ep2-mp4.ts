/**
 * render-ep2-mp4.ts — رندرِ آفلاینِ اپیزود ۲ به MP4 (H.264 + AAC) در Node
 *
 *   npx tsx scripts/render-ep2-mp4.ts <audio.ogg> <out.mp4> [fps] [ffmpegPath]
 *
 * نیازمندی‌ها: @napi-rs/canvas ، ffmpeg ، فونت‌های Vazirmatn و Amiri در /tmp/fonts
 */
import { spawn } from 'node:child_process';
import { appendFileSync, existsSync, readFileSync, writeFileSync } from 'node:fs';
import { createCanvas, GlobalFonts } from '@napi-rs/canvas';
import { drawEp2Frame } from '../src/motion2/renderer2';
import { EP2_DURATION } from '../src/motion2/timeline2';

const [audioPath = '/tmp/b.ogg', outPath = '/tmp/out/ep2.mp4', fpsArg = '30', ffArg] = process.argv.slice(2);
const FPS = Number(fpsArg);
const W = 1280;
const H = 720;
const FF = ffArg ?? '/tmp/ff/node_modules/ffmpeg-static/ffmpeg';
const LOG = '/tmp/out/render.log';

for (const f of ['vazir400', 'vazir700', 'vazir800']) GlobalFonts.registerFromPath(`/tmp/fonts/${f}.ttf`, 'Vazirmatn');
GlobalFonts.registerFromPath('/tmp/fonts/amiri700.ttf', 'Amiri');

/* ---------- پاکتِ انرژیِ صدا (از PCM ۱۶kHz) ---------- */
function buildEnvelope(): Float32Array {
  const n = Math.ceil(EP2_DURATION * FPS) + 2;
  const env = new Float32Array(n);
  const pcmPath = '/tmp/b16.f32';
  if (!existsSync(pcmPath)) return env.fill(0.25);
  const buf = readFileSync(pcmPath);
  const pcm = new Float32Array(buf.buffer, buf.byteOffset, Math.floor(buf.byteLength / 4));
  const step = 16000 / FPS;
  let peak = 0;
  for (let i = 0; i < n; i++) {
    const s = Math.floor(i * step);
    const e = Math.min(pcm.length, Math.floor((i + 1) * step));
    let sum = 0;
    for (let k = s; k < e; k++) sum += pcm[k] * pcm[k];
    env[i] = e > s ? Math.sqrt(sum / (e - s)) : 0;
    peak = Math.max(peak, env[i]);
  }
  // نرمال‌سازی + هموارسازیِ حمله/رهایی
  const out = new Float32Array(n);
  let v = 0;
  for (let i = 0; i < n; i++) {
    const x = Math.min(1, (env[i] / (peak * 0.6 || 1)) ** 0.8);
    v = x > v ? v + (x - v) * 0.5 : v + (x - v) * 0.08;
    out[i] = 0.08 + v * 0.85;
  }
  return out;
}

async function main() {
  writeFileSync(LOG, `start ${new Date().toISOString()}\n`);
  const env = buildEnvelope();
  const maxSec = Number(process.env.MAX_SEC ?? 0);
  const total = Math.round((maxSec > 0 ? Math.min(maxSec, EP2_DURATION) : EP2_DURATION) * FPS);

  const ff = spawn(
    FF,
    [
      '-y', '-hide_banner', '-loglevel', 'error',
      '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', `${W}x${H}`, '-r', String(FPS), '-i', 'pipe:0',
      '-i', audioPath,
      '-map', '0:v', '-map', '1:a',
      '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '21', '-pix_fmt', 'yuv420p', '-profile:v', 'high',
      '-g', String(FPS * 2),
      '-c:a', 'aac', '-b:a', '128k', '-ar', '48000',
      '-movflags', '+faststart', '-shortest',
      '-metadata', 'title=تسلیم؛ رمز موفقیت پیامبران — موشن گرافیک',
      outPath,
    ],
    { stdio: ['pipe', 'inherit', 'pipe'] },
  );
  ff.stderr.on('data', (d) => appendFileSync(LOG, `ffmpeg: ${d}`));
  const done = new Promise<number>((res) => ff.on('close', (c) => res(c ?? 1)));

  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d') as unknown as CanvasRenderingContext2D;
  const t0 = Date.now();
  for (let i = 0; i < total; i++) {
    const t = i / FPS;
    drawEp2Frame(ctx, t, W, H, env[i] ?? 0.2, { showSubtitles: true, showHud: true });
    const img = (ctx as unknown as { getImageData: (...a: number[]) => { data: Uint8ClampedArray } }).getImageData(0, 0, W, H);
    const chunk = Buffer.from(img.data.buffer, img.data.byteOffset, img.data.byteLength);
    if (!ff.stdin.write(chunk)) await new Promise((r) => ff.stdin.once('drain', r));
    if (i % (FPS * 10) === 0) {
      const el = (Date.now() - t0) / 1000;
      const fpsNow = i / Math.max(0.001, el);
      appendFileSync(LOG, `frame ${i}/${total} ${((i / total) * 100).toFixed(1)}% ${fpsNow.toFixed(1)}fps eta ${((total - i) / Math.max(0.1, fpsNow) / 60).toFixed(1)}min\n`);
    }
  }
  ff.stdin.end();
  const code = await done;
  appendFileSync(LOG, `ffmpeg exit ${code} after ${((Date.now() - t0) / 60000).toFixed(1)} min\nDONE\n`);
}

main().catch((e) => {
  appendFileSync(LOG, `ERROR ${e?.stack ?? e}\n`);
  process.exit(1);
});
