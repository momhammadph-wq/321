/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * smoke.ts — اجرای موتورِ رندر خارج از مرورگر با یک Canvas2D ساختگی
 * تا از نبودِ خطای زمانِ اجرا و مقدارِ NaN در مختصات‌ها مطمئن شویم.
 */
import { drawEp2Frame } from '../src/motion2/renderer2';
import { EP2_DURATION } from '../src/motion2/timeline2';

let nanHits = 0;
const nanSamples: string[] = [];

function makeCtx() {
  const state: any = { font: '400 20px "Vazirmatn", sans-serif', textAlign: 'center', textBaseline: 'middle' };
  const grad = () => ({ addColorStop: (_o: number, c: string) => checkColor(c) });
  const noop = () => undefined;

  const handler: ProxyHandler<any> = {
    get(target, prop: string) {
      if (prop in target) return target[prop];
      if (prop === 'createLinearGradient' || prop === 'createRadialGradient') return grad;
      if (prop === 'measureText')
        return (text: string) => {
          const size = parseFontSize(target.font);
          return { width: String(text).length * size * 0.5 };
        };
      if (prop === 'fillText' || prop === 'strokeText')
        return (text: string, x: number, y: number) => {
          checkNums(prop, [x, y]);
          if (typeof text !== 'string' || text.includes('NaN')) record(prop, String(text));
        };
      if (prop === 'canvas') return { width: 1280, height: 720 };
      return (...args: number[]) => {
        checkNums(prop, args);
        return noop();
      };
    },
    set(target, prop: string, value) {
      if (typeof value === 'number') checkNums('set:' + prop, [value]);
      if (typeof value === 'string' && (prop === 'fillStyle' || prop === 'strokeStyle')) checkColor(value);
      target[prop] = value;
      return true;
    },
  };
  const ctx: any = new Proxy(
    {
      ...state,
      save: noop,
      restore: noop,
      clearRect: noop,
      drawImage: noop,
      setLineDash: noop,
      direction: 'rtl',
      globalAlpha: 1,
    },
    handler,
  );
  return ctx;
}

function parseFontSize(font: string): number {
  const m = /(\d+(?:\.\d+)?)px/.exec(font ?? '');
  return m ? Number(m[1]) : 20;
}

function checkNums(name: string, args: any[]) {
  for (const a of args) {
    if (typeof a === 'number' && !Number.isFinite(a)) {
      record(name, String(a));
      return;
    }
  }
}

function checkColor(c: string) {
  if (typeof c === 'string' && /NaN|undefined|Infinity/.test(c)) record('color', c);
}

function record(name: string, val: string) {
  nanHits++;
  if (nanSamples.length < 12) nanSamples.push(`${name} -> ${val}`);
}

/* ---------------- رندر کل تایم‌لاین اپیزود ۲ ---------------- */
const ctx = makeCtx();
let frames = 0;
for (let t = 0; t <= EP2_DURATION; t += 0.2) {
  drawEp2Frame(ctx, t, 1280, 720, 0.3 + 0.3 * Math.sin(t), { showSubtitles: true, showHud: true });
  frames++;
}
for (const e of [0, 1]) for (let t = 0; t <= EP2_DURATION; t += 3.3) { drawEp2Frame(ctx, t, 1920, 1080, e, { showSubtitles: true, showHud: true }); frames++; }
console.log('frames rendered :', frames);
console.log('NaN / invalid   :', nanHits);
if (nanSamples.length) console.log(nanSamples.join('\n'));
console.log(nanHits === 0 ? '✅ EP2 SMOKE PASSED' : '❌ EP2 SMOKE FAILED');
