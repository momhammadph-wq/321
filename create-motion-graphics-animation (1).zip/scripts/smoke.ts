/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * smoke.ts — اجرای موتورِ رندر خارج از مرورگر با یک Canvas2D ساختگی
 * تا از نبودِ خطای زمانِ اجرا و مقدارِ NaN در مختصات‌ها مطمئن شویم.
 */
import { drawMotionFrame, drawChapterThumb } from '../src/motion/renderer';
import { MOTION_CHAPTERS, DURATION_7MIN, DURATION_FULL } from '../src/motion/timelineData';
import { scheduleAmbientRange } from '../src/motion/ambientScore';
import { seeded } from '../src/motion/drawPrimitives';

let nanHits = 0;
const nanSamples: string[] = [];

function makeCtx() {
  const state: any = { font: '400 20px "Vazirmatn", sans-serif', textAlign: 'center', textBaseline: 'middle' };
  const grad = () => ({ addColorStop: (_o: number, c: string) => checkColor(c) });
  const noop = () => undefined;

  const handler: ProxyHandler<any> = {
    get(target, prop: string) {
      if (prop in target) return target[prop];
      if (prop === 'createLinearGradient' || prop === 'createRadialGradient') return grad;
      if (prop === 'measureText')
        return (text: string) => {
          const size = parseFontSize(target.font);
          return { width: String(text).length * size * 0.5 };
        };
      if (prop === 'fillText' || prop === 'strokeText')
        return (text: string, x: number, y: number) => {
          checkNums(prop, [x, y]);
          if (typeof text !== 'string' || text.includes('NaN')) record(prop, String(text));
        };
      if (prop === 'canvas') return { width: 1280, height: 720 };
      return (...args: number[]) => {
        checkNums(prop, args);
        return noop();
      };
    },
    set(target, prop: string, value) {
      if (typeof value === 'number') checkNums('set:' + prop, [value]);
      if (typeof value === 'string' && (prop === 'fillStyle' || prop === 'strokeStyle')) checkColor(value);
      target[prop] = value;
      return true;
    },
  };
  const ctx: any = new Proxy(
    {
      ...state,
      save: noop,
      restore: noop,
      clearRect: noop,
      drawImage: noop,
      setLineDash: noop,
      direction: 'rtl',
      globalAlpha: 1,
    },
    handler,
  );
  return ctx;
}

function parseFontSize(font: string): number {
  const m = /(\d+(?:\.\d+)?)px/.exec(font ?? '');
  return m ? Number(m[1]) : 20;
}

function checkNums(name: string, args: any[]) {
  for (const a of args) {
    if (typeof a === 'number' && !Number.isFinite(a)) {
      record(name, String(a));
      return;
    }
  }
}

function checkColor(c: string) {
  if (typeof c === 'string' && /NaN|undefined|Infinity/.test(c)) record('color', c);
}

function record(name: string, val: string) {
  nanHits++;
  if (nanSamples.length < 12) nanSamples.push(`${name} -> ${val}`);
}

/* ---------------- رندر کل تایم‌لاین ---------------- */
const ctx = makeCtx();
let frames = 0;
for (let t = 0; t <= DURATION_7MIN; t += 0.25) {
  drawMotionFrame(ctx, t, 1280, 720, 0.3 + 0.2 * Math.sin(t), {
    mode: '7min',
    showSubtitles: true,
    showHud: true,
    totalDur: DURATION_7MIN,
  });
  frames++;
}
// حالتِ روایتِ کامل
for (let t = 0; t <= DURATION_FULL; t += 7.77) {
  drawMotionFrame(ctx, t, 1920, 1080, 0.2, {
    mode: 'full',
    showSubtitles: true,
    showHud: true,
    totalDur: DURATION_FULL,
  });
  frames++;
}
// انرژیِ صفر و یک (حالت‌های حدّی)
for (const e of [0, 1]) {
  MOTION_CHAPTERS.forEach((c) => {
    drawMotionFrame(ctx, (c.start + c.end) / 2, 1280, 720, e, {
      mode: '7min',
      showSubtitles: true,
      showHud: true,
      totalDur: DURATION_7MIN,
    });
    frames++;
    drawChapterThumb(ctx, c, 126, 70);
    frames++;
  });
}

/* ---------------- زمان‌بندیِ موسیقی ---------------- */
let scheduled = 0;
const audioNode = () => ({ connect: (n: any) => n ?? audioNode(), disconnect: () => undefined });
const param = () => ({ value: 0, setValueAtTime: () => undefined, linearRampToValueAtTime: () => undefined, exponentialRampToValueAtTime: () => undefined });
const mockAudio: any = {
  sampleRate: 48000,
  currentTime: 100,
  destination: audioNode(),
  createGain: () => ({ ...audioNode(), gain: param() }),
  createOscillator: () => {
    scheduled++;
    return { ...audioNode(), type: 'sine', frequency: param(), detune: param(), start: (t: number) => checkNums('osc.start', [t]), stop: (t: number) => checkNums('osc.stop', [t]) };
  },
  createBiquadFilter: () => ({ ...audioNode(), type: 'lowpass', frequency: param(), Q: param() }),
  createConvolver: () => ({ ...audioNode(), buffer: null }),
  createBuffer: (_ch: number, len: number, _sr: number) => ({
    getChannelData: () => new Float32Array(len),
  }),
};
// آفلاین (t0 = -s) — هر سگمنت = یک فصل
scheduled = 0;
for (const c of MOTION_CHAPTERS) {
  scheduleAmbientRange(mockAudio, audioNode(), c.start, Math.min(c.end, DURATION_7MIN), -c.start, {});
}
const offlineNodes = scheduled;

// زنده با پنجرهٔ ۱.۶ ثانیه‌ای — نباید پَدِ تکراری بسازد
scheduled = 0;
for (let t = 0; t < DURATION_7MIN; t += 1.6) {
  scheduleAmbientRange(mockAudio, audioNode(), t, Math.min(DURATION_7MIN, t + 1.6), 100 - t, {});
}
const liveNodes = scheduled;

// تعدادِ موردِ انتظار
const thumps = Array.from({ length: Math.ceil(DURATION_7MIN / 2) }, (_, i) => i * 2).filter(
  (t) => t < DURATION_7MIN,
).length;
let bells = 0;
for (let bar = 0; bar < DURATION_7MIN; bar += 4) {
  const idx = bar / 4;
  bells += 1 + Math.floor(seeded(idx * 3.7) * 3);
}
const expected = 12 * 4 + thumps + bells * 2;

console.log('frames rendered :', frames);
console.log('offline osc     :', offlineNodes);
console.log('live osc        :', liveNodes, '(expected', expected + ')');
console.log('thumps/bells    :', thumps, '/', bells);
console.log('NaN / invalid   :', nanHits);
if (nanSamples.length) console.log(nanSamples.join('\n'));
console.log(nanHits === 0 ? '✅ SMOKE TEST PASSED' : '❌ SMOKE TEST FAILED');
