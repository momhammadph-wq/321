import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  CalendarCheck,
  CheckCircle2,
  ChevronLeft,
  Clapperboard,
  Clock,
  Eye,
  Gauge,
  Layers,
  LoaderCircle,
  Maximize,
  Minimize,
  Music,
  Pause,
  Play,
  Radio,
  RotateCcw,
  Sparkles,
  Subtitles,
  Volume2,
  VolumeX,
  Wand2,
} from 'lucide-react';
import { cn } from '@/utils/cn';
import ExportPanel, { ExportPanelFooter } from '@/components/ExportPanel';
import { AmbientPlayer } from '@/motion/ambientScore';
import { ensureFontsReady, exportMotionToMp4, isWebCodecsSupported, type ExportResult } from '@/motion/mp4Exporter';
import { PUBLISHED, captionAt, chapterAt, getEpisode, type EpisodeId } from '@/episodes';
import { formatTimeFa, toFaDigits } from '@/motion/drawPrimitives';
import type { HostedLink } from '@/motion/uploader';
import { uploadToGofile, uploadToTmpfiles } from '@/motion/uploader';

type Mode = '7min' | 'full';
type Tab = 'export' | 'chapters' | 'captions' | 'guide';

const CANVAS_W = 1280;
const CANVAS_H = 720;

export default function App() {
  /* ---------------- state ---------------- */
  const [mode, setMode] = useState<Mode>('7min');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [muted, setMuted] = useState(false);
  const [volume, setVolume] = useState(0.85);
  const [showSubtitles, setShowSubtitles] = useState(true);
  const [showHud, setShowHud] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [tab, setTab] = useState<Tab>('export');
  const [audioSource, setAudioSource] = useState<'ambient' | 'voice' | 'none'>('ambient');
  const [episode, setEpisode] = useState<EpisodeId>('ep2');
  const [narrationOverride, setNarrationOverride] = useState<string | undefined>(undefined);
  const info = useMemo(() => getEpisode(episode, mode, narrationOverride), [episode, mode, narrationOverride]);
  const narrationUrl = info.audioUrl ?? '';
  const usesVoice = info.audioUrl !== null;
  const [narrationState, setNarrationState] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle');
  const [webcodecsOk] = useState(() => isWebCodecsSupported());

  const [resolution, setResolution] = useState<'720p' | '1080p'>('720p');
  const [fps, setFps] = useState(30);
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState<{
    phase: string;
    percent: number;
    currentFrame: number;
    totalFrames: number;
    elapsedSec: number;
    etaSec: number;
    detail: string;
  } | null>(null);
  const [exportError, setExportError] = useState<string | null>(null);
  const [exportResult, setExportResult] = useState<{ data: ExportResult; url: string } | null>(null);
  const [links, setLinks] = useState<HostedLink[]>([]);
  const [uploading, setUploading] = useState<{ host: string; percent: number } | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);

  /* ---------------- refs ---------------- */
  const stageWrapRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const previewRef = useRef<HTMLCanvasElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const narrationCtxRef = useRef<AudioContext | null>(null);
  const narrationAnalyserRef = useRef<AnalyserNode | null>(null);
  const narrationAttachedRef = useRef(false);
  const ambientRef = useRef<AmbientPlayer | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const freqRef = useRef<Uint8Array | null>(null);
  const clockRef = useRef(0);
  const playingRef = useRef(false);
  const lastTsRef = useRef(0);
  const uiTsRef = useRef(0);
  const rafRef = useRef(0);
  const abortRef = useRef<AbortController | null>(null);
  const thumbRefs = useRef<Record<number, HTMLCanvasElement | null>>({});
  const captionBoxRef = useRef<HTMLDivElement | null>(null);
  const audioSourceRef = useRef<'ambient' | 'voice' | 'none'>(audioSource);

  const totalDur = info.duration;
  const visualTime = info.toVisual(currentTime);
  const chapter = chapterAt(info.chapters, visualTime);
  const caption = captionAt(info.captions, visualTime);
  const captionIndex = useMemo(() => info.captions.findIndex((c) => c === caption), [caption, info]);

  const renderOptsRef = useRef({ info, showSubtitles, showHud, totalDur });
  renderOptsRef.current = { info, showSubtitles, showHud, totalDur };

  /* ---------------- narration element ---------------- */
  useEffect(() => {
    if (!usesVoice) return;
    setNarrationState('loading');
    const a = audioRef.current;
    if (!a) return;
    a.src = narrationUrl;
    a.load();
    const onReady = () => setNarrationState('ready');
    const onErr = () => setNarrationState('error');
    a.addEventListener('loadedmetadata', onReady);
    a.addEventListener('error', onErr);
    return () => {
      a.removeEventListener('loadedmetadata', onReady);
      a.removeEventListener('error', onErr);
    };
  }, [usesVoice, narrationUrl]);

  /* ---------------- rAF render loop ---------------- */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;
    let alive = true;

    const sampleEnergy = (t: number) => {
      const an = analyserRef.current;
      if (an) {
        if (!freqRef.current || freqRef.current.length !== an.frequencyBinCount * 2) {
          freqRef.current = new Uint8Array(an.fftSize);
        }
        an.getByteTimeDomainData(freqRef.current as Uint8Array<ArrayBuffer>);
        let sum = 0;
        for (let i = 0; i < freqRef.current.length; i++) {
          const v = (freqRef.current[i] - 128) / 128;
          sum += v * v;
        }
        const rms = Math.sqrt(sum / freqRef.current.length);
        return Math.max(0.05, Math.min(1, rms * 4.2));
      }
      return 0.2 + 0.09 * Math.sin(t * 2.1) + 0.05 * Math.sin(t * 5.3);
    };

    const loop = (ts: number) => {
      if (!alive) return;
      const prev = lastTsRef.current || ts;
      const dt = Math.min(0.06, (ts - prev) / 1000);
      lastTsRef.current = ts;

      const o = renderOptsRef.current;
      const dur = o.totalDur;
      if (playingRef.current) {
        clockRef.current = Math.min(dur, clockRef.current + dt);
        if (clockRef.current >= dur) {
          playingRef.current = false;
          setIsPlaying(false);
          ambientRef.current?.stop();
          audioRef.current?.pause();
        }
      }

      const energy = sampleEnergy(clockRef.current);
      o.info.draw(ctx, clockRef.current, canvas.width, canvas.height, energy, { showSubtitles: o.showSubtitles, showHud: o.showHud });

      if (ts - uiTsRef.current > 85) {
        uiTsRef.current = ts;
        setCurrentTime(clockRef.current);
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => {
      alive = false;
      cancelAnimationFrame(rafRef.current);
    };
  }, []);

  audioSourceRef.current = usesVoice ? 'voice' : audioSource;

  /* ---------------- fonts + thumbs ---------------- */
  useEffect(() => {
    let alive = true;
    void ensureFontsReady().then(() => {
      if (!alive) return;
      info.chapters.forEach((ch) => {
        const c = thumbRefs.current[ch.id];
        if (!c) return;
        const ctx = c.getContext('2d');
        if (ctx) info.thumb(ctx, ch, c.width, c.height);
      });
    });
    return () => {
      alive = false;
    };
  }, [info]);

  /* ---------------- transport ---------------- */
  const ensureNarrationAnalyser = useCallback(() => {
    const a = audioRef.current;
    if (!a || narrationAttachedRef.current) return;
    try {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      narrationCtxRef.current ??= new Ctx();
      const ctx = narrationCtxRef.current;
      void ctx.resume();
      const src = ctx.createMediaElementSource(a);
      const an = ctx.createAnalyser();
      an.fftSize = 512;
      an.smoothingTimeConstant = 0.75;
      src.connect(an);
      an.connect(ctx.destination);
      narrationAnalyserRef.current = an;
      narrationAttachedRef.current = true;
    } catch {
      narrationAttachedRef.current = false;
    }
  }, []);

  const play = useCallback(() => {
    playingRef.current = true;
    setIsPlaying(true);
    if (!usesVoice) {
      if (audioSourceRef.current === 'ambient') {
        if (!ambientRef.current) ambientRef.current = new AmbientPlayer(volume, !muted);
        ambientRef.current.setVolume(volume);
        ambientRef.current.setEnabled(!muted);
        ambientRef.current.start(clockRef.current);
        analyserRef.current = ambientRef.current.getAnalyser();
      } else {
        ambientRef.current?.stop();
        analyserRef.current = null;
      }
    } else {
      const a = audioRef.current;
      if (a && audioSourceRef.current === 'voice') {
        ensureNarrationAnalyser();
        analyserRef.current = narrationAnalyserRef.current;
        try {
          a.currentTime = clockRef.current;
        } catch {
          /* noop */
        }
        a.volume = muted ? 0 : volume;
        void a.play().catch(() => undefined);
      } else {
        analyserRef.current = null;
      }
    }
  }, [usesVoice, volume, muted, ensureNarrationAnalyser]);

  const pause = useCallback(() => {
    playingRef.current = false;
    setIsPlaying(false);
    ambientRef.current?.stop();
    audioRef.current?.pause();
  }, []);

  const togglePlay = useCallback(() => {
    if (playingRef.current) pause();
    else play();
  }, [play, pause]);

  const seek = useCallback(
    (t: number) => {
      const clamped = Math.max(0, Math.min(totalDur, t));
      clockRef.current = clamped;
      setCurrentTime(clamped);
      lastTsRef.current = 0;
      if (playingRef.current) {
        pause();
        window.setTimeout(() => play(), 10);
      } else {
        ambientRef.current?.stop();
      }
    },
    [totalDur, pause, play],
  );

  const restart = useCallback(() => {
    seek(0);
    window.setTimeout(() => play(), 40);
  }, [seek, play]);

  /* volume / mute sync */
  useEffect(() => {
    ambientRef.current?.setVolume(volume);
    ambientRef.current?.setEnabled(!muted);
    const a = audioRef.current;
    if (a) {
      a.volume = muted ? 0 : volume;
      a.muted = muted;
    }
  }, [volume, muted]);

  /* mode switch resets the clock & syncs the audio source */
  useEffect(() => {
    pause();
    clockRef.current = 0;
    setCurrentTime(0);
    analyserRef.current = null;
    setAudioSource((prev) => {
      if (mode === 'full' || episode === 'ep2') return prev === 'none' ? 'none' : 'voice';
      return prev === 'voice' ? 'ambient' : prev;
    });
  }, [mode, episode, pause]);

  /* fullscreen tracking */
  useEffect(() => {
    const onFs = () => setIsFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFs);
    return () => document.removeEventListener('fullscreenchange', onFs);
  }, []);

  /* keyboard shortcuts */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return;
      if (e.code === 'Space') {
        e.preventDefault();
        togglePlay();
      } else if (e.code === 'ArrowRight') {
        seek(clockRef.current + 5);
      } else if (e.code === 'ArrowLeft') {
        seek(clockRef.current - 5);
      } else if (e.key === 's' || e.key === 'S') {
        setShowSubtitles((v) => !v);
      } else if (e.key === 'h' || e.key === 'H') {
        setShowHud((v) => !v);
      } else if (e.key === 'f' || e.key === 'F') {
        void toggleFullscreen();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [togglePlay, seek]);

  const toggleFullscreen = useCallback(() => {
    const el = stageWrapRef.current;
    if (!el) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void el.requestFullscreen?.();
  }, []);

  /* ---------------- export ---------------- */
  useEffect(() => {
    return () => {
      if (exportResult?.url) URL.revokeObjectURL(exportResult.url);
    };
  }, [exportResult]);

  const startExport = useCallback(async () => {
    if (isExporting) return;
    pause();
    setExportError(null);
    setExportResult((prev) => {
      if (prev) URL.revokeObjectURL(prev.url);
      return null;
    });
    setLinks([]);
    setUploadError(null);
    setIsExporting(true);
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    const src = usesVoice ? (audioSource === 'none' ? 'none' : 'voice') : audioSource === 'voice' ? 'ambient' : audioSource;
    try {
      const res = await exportMotionToMp4({
        mode,
        episode,
        audioSource: src,
        resolution,
        fps,
        showSubtitles,
        showHud,
        narrationUrl,
        signal: ctrl.signal,
        onProgress: (p) => setExportProgress({ ...p }),
        onPreviewCanvas: (c) => {
          const pc = previewRef.current;
          if (!pc) return;
          const ctx = pc.getContext('2d');
          if (!ctx) return;
          ctx.clearRect(0, 0, pc.width, pc.height);
          ctx.drawImage(c, 0, 0, pc.width, pc.height);
        },
      });
      const url = URL.createObjectURL(res.blob);
      setExportResult({ data: res, url });
      setTab('export');
    } catch (err) {
      if ((err as Error)?.name !== 'AbortError') {
        setExportError((err as Error)?.message ?? 'خطای ناشناخته در ساخت ویدیو.');
      } else {
        setExportError('فرایندِ ساخت ویدیو لغو شد.');
      }
    } finally {
      setIsExporting(false);
      setExportProgress(null);
      abortRef.current = null;
    }
  }, [isExporting, pause, mode, episode, usesVoice, audioSource, resolution, fps, showSubtitles, showHud, narrationUrl]);

  const cancelExport = useCallback(() => abortRef.current?.abort(), []);

  const uploadTo = useCallback(
    async (host: 'tmpfiles.org' | 'gofile.io') => {
      if (!exportResult) return;
      setUploadError(null);
      setUploading({ host, percent: 0 });
      try {
        const fn = (p: number) => setUploading({ host, percent: p });
        const link =
          host === 'tmpfiles.org'
            ? await uploadToTmpfiles(exportResult.data.blob, exportResult.data.filename, fn)
            : await uploadToGofile(exportResult.data.blob, exportResult.data.filename, fn);
        setLinks((prev) => [...prev.filter((l) => l.host !== host), link]);
      } catch (err) {
        setUploadError((err as Error)?.message ?? 'آپلود ناموفق بود.');
      } finally {
        setUploading(null);
      }
    },
    [exportResult],
  );

  const pickAudioFile = useCallback((file: File) => {
    setNarrationOverride(URL.createObjectURL(file));
    setNarrationState('loading');
  }, []);

  /* ---------------- derived UI ---------------- */
  const playFraction = visualTime / info.span;
  const chapterFraction = (visualTime - chapter.start) / Math.max(0.001, chapter.end - chapter.start);

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-studio text-slate-100">
      {/* ------- لایه‌های محیطی پس‌زمینه ------- */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="bg-grid-fine absolute inset-0 opacity-70" />
        <div className="animate-drift-slow absolute -left-40 top-10 h-[520px] w-[520px] rounded-full border border-amber-400/10" />
        <div
          className="animate-drift-slow absolute -right-32 bottom-0 h-[620px] w-[620px] rounded-full border border-sky-400/10"
          style={{ animationDuration: '88s', animationDirection: 'reverse' }}
        />
        <div className="absolute left-[12%] top-[18%] h-40 w-40 rounded-full bg-amber-500/10 blur-3xl" />
        <div className="absolute right-[8%] top-[46%] h-52 w-52 rounded-full bg-sky-500/10 blur-3xl" />
        <div className="absolute bottom-[6%] left-[42%] h-44 w-44 rounded-full bg-emerald-500/10 blur-3xl" />
      </div>

      <audio ref={audioRef} crossOrigin="anonymous" preload="auto" className="hidden" />

      {/* ------- هدر ------- */}
      <header className="relative z-10 border-b border-slate-800/60 bg-[#05070f]/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1600px] flex-wrap items-center justify-between gap-4 px-4 py-5 lg:px-8">
          <div className="flex items-center gap-4">
            <div className="relative grid h-14 w-14 place-items-center rounded-2xl border border-amber-400/30 bg-gradient-to-b from-amber-400/15 to-transparent">
              <Clapperboard className="h-7 w-7 text-amber-300" />
              <span className="animate-pulse-soft absolute inset-0 rounded-2xl border border-amber-300/25" />
            </div>
            <div>
              <h1 className="font-display text-[26px] leading-tight font-bold text-amber-200 drop-shadow-[0_0_18px_rgba(251,191,36,0.35)] sm:text-[32px]">
                {episode === 'ep2' ? 'تسلیم؛ رمزِ موفقیتِ پیامبران' : 'صَدَّقَ بِالْحُسْنَىٰ'}
              </h1>
              <p className="text-[12.5px] font-medium text-slate-400 sm:text-[13.5px]">
                استودیوی موشن گرافیکِ المان‌محور • دو اپیزود • خروجیِ MP4 و لینکِ دانلودِ عمومی
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-[11.5px] font-bold">
            <Chip
              tone={webcodecsOk ? 'ok' : 'warn'}
              icon={<Wand2 className="h-3.5 w-3.5" />}
              text={webcodecsOk ? 'WebCodecs فعال' : 'بدونِ WebCodecs'}
            />
            <Chip tone="info" icon={<Layers className="h-3.5 w-3.5" />} text={`${info.chapters.length} صحنهٔ المان‌محور`} />
            <Chip tone="gold" icon={<Clock className="h-3.5 w-3.5" />} text={formatTimeFa(info.duration)} />
            <Chip tone="muted" icon={<Radio className="h-3.5 w-3.5" />} text={info.tagline} />
          </div>
        </div>
      </header>

      {/* ------- بدنه ------- */}
      <main className="relative z-10 mx-auto grid max-w-[1600px] gap-5 px-4 py-6 lg:grid-cols-[minmax(0,1fr)_384px] lg:px-8">
        {/* ستونِ صحنه */}
        <section className="flex flex-col gap-4">
          {/* انتخابِ اپیزود */}
          <div className="grid gap-3 sm:grid-cols-2">
            {(
              [
                { id: 'ep2', n: 'اپیزود ۲ • تسلیم', s: 'رمزِ موفقیتِ پیامبران • ۱۵ فصل • ۱۴:۴۰', c: '#fbbf24' },
                { id: 'ep1', n: 'اپیزود ۱ • صدّق بالحُسنی', s: 'فراوانی و شکر • ۱۲ فصل • ۷ دقیقه', c: '#38bdf8' },
              ] as const
            ).map((ep) => {
              const active = episode === ep.id;
              return (
                <button
                  key={ep.id}
                  type="button"
                  onClick={() => setEpisode(ep.id)}
                  className={cn(
                    'group relative overflow-hidden rounded-2xl border p-4 text-right transition-all duration-300',
                    active
                      ? 'border-amber-400/60 bg-gradient-to-l from-amber-400/15 to-transparent shadow-[0_0_40px_-16px_rgba(251,191,36,0.9)]'
                      : 'border-slate-800 bg-[#080c1a]/70 hover:-translate-y-0.5 hover:border-slate-600',
                  )}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl text-[#0a0d18]"
                      style={{ background: ep.c, boxShadow: active ? `0 0 24px -4px ${ep.c}` : 'none' }}
                    >
                      <Clapperboard className="h-5 w-5" />
                    </span>
                    <div className="min-w-0">
                      <div className={cn('text-[14.5px] font-black', active ? 'text-amber-100' : 'text-slate-200')}>{ep.n}</div>
                      <div className="truncate text-[11.5px] text-slate-400">{ep.s}</div>
                    </div>
                    {active ? <CheckCircle2 className="mr-auto h-5 w-5 shrink-0 text-amber-300" /> : null}
                  </div>
                </button>
              );
            })}
          </div>

          {PUBLISHED[episode].length > 0 ? (
            <div className="animate-rise rounded-2xl border border-emerald-500/40 bg-gradient-to-l from-emerald-500/12 to-transparent p-4">
              <div className="mb-2 flex items-center gap-2 text-[13.5px] font-black text-emerald-200">
                <CheckCircle2 className="h-4 w-4" />
                MP4 آماده — لینکِ مستقیمِ دانلود (رندرشده در 720p / 30fps با صدای اصلی)
              </div>
              <div className="grid gap-2 sm:grid-cols-2">
                {PUBLISHED[episode].map((l) => (
                  <a
                    key={l.url}
                    href={l.url}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="group flex items-center justify-between gap-3 rounded-xl border border-slate-700/70 bg-slate-950/60 px-3 py-2.5 transition hover:border-emerald-400/60 hover:bg-emerald-500/10"
                  >
                    <span className="min-w-0">
                      <span className="block text-[12.5px] font-extrabold text-slate-100">
                        {l.host} {l.direct ? '• مستقیم' : '• صفحهٔ دانلود'}
                      </span>
                      <span className="block truncate text-[11px] text-slate-400" dir="ltr">
                        {l.url}
                      </span>
                    </span>
                    <ChevronLeft className="h-4 w-4 shrink-0 text-emerald-300 transition group-hover:-translate-x-1" />
                  </a>
                ))}
              </div>
            </div>
          ) : null}
          {/* نوارِ فصلِ جاری */}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-slate-800/70 bg-[#080c1a]/75 px-4 py-3 backdrop-blur">
            <div className="flex items-center gap-3">
              <span
                className="grid h-9 w-9 place-items-center rounded-xl text-[13px] font-black text-[#0a0d18]"
                style={{ background: chapter.accent, boxShadow: `0 0 26px -6px ${chapter.accent}` }}
              >
                {toFaDigits(chapter.id)}
              </span>
              <div>
                <div className="text-[14.5px] font-extrabold text-slate-100">{chapter.title}</div>
                <div className="text-[11.5px] text-slate-400">{chapter.subtitle}</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-left">
                <div className="font-display text-[15px] text-amber-200/90">{chapter.verseAr ?? '—'}</div>
                <div className="text-[10.5px] text-slate-500">{chapter.verseRef ?? 'المان‌های بصریِ فصل'}</div>
              </div>
              <div className="h-9 w-24 overflow-hidden rounded-full bg-slate-900">
                <div
                  className="h-full rounded-full transition-[width] duration-150"
                  style={{ width: `${chapterFraction * 100}%`, background: chapter.accent }}
                />
              </div>
            </div>
          </div>

          {/* صحنه */}
          <div
            ref={stageWrapRef}
            className="relative overflow-hidden rounded-[22px] border border-slate-800/80 bg-black"
          >
            <div className="relative aspect-video w-full">
              <canvas
                ref={canvasRef}
                width={CANVAS_W}
                height={CANVAS_H}
                className="stage-canvas h-full w-full rounded-[21px]"
              />
              {/* کرنرهای سینمایی */}
              <div className="pointer-events-none absolute inset-0">
                {[
                  'right-3 top-3 border-r-2 border-t-2',
                  'left-3 top-3 border-l-2 border-t-2',
                  'right-3 bottom-3 border-r-2 border-b-2',
                  'left-3 bottom-3 border-l-2 border-b-2',
                ].map((c) => (
                  <span key={c} className={cn('absolute h-5 w-5 rounded-sm border-amber-300/40', c)} />
                ))}
              </div>

              {/* اورلیِ رندر */}
              {isExporting ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-[#04070f]/88 backdrop-blur-sm">
                  <div className="flex items-center gap-2 rounded-full border border-rose-500/40 bg-rose-500/10 px-3 py-1 text-[11.5px] font-black text-rose-200">
                    <span className="animate-rec h-2 w-2 rounded-full bg-rose-400" />
                    در حالِ رندرِ آفلاین
                  </div>
                  <canvas
                    ref={previewRef}
                    width={320}
                    height={180}
                    className="rounded-xl border border-slate-700/70 shadow-[0_20px_60px_-20px_rgba(251,191,36,0.5)]"
                  />
                  <div className="w-[min(420px,80%)]">
                    <div className="mb-1 flex justify-between text-[11px] font-bold text-slate-300">
                      <span>{exportProgress?.detail}</span>
                      <span className="tabular-nums text-amber-300">
                        {Math.round(exportProgress?.percent ?? 0)}٪
                      </span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-slate-900">
                      <div
                        className="h-full rounded-full bg-gradient-to-l from-amber-300 to-rose-400 transition-[width] duration-200"
                        style={{ width: `${exportProgress?.percent ?? 2}%` }}
                      />
                    </div>
                  </div>
                </div>
              ) : null}

              {!isPlaying && !isExporting && currentTime === 0 ? (
                <button
                  type="button"
                  onClick={togglePlay}
                  className="group absolute inset-0 grid place-items-center bg-gradient-to-t from-[#04070f]/85 via-transparent to-transparent"
                >
                  <span className="grid h-20 w-20 place-items-center rounded-full border border-amber-300/50 bg-[#0b1020]/85 shadow-[0_0_60px_-12px_rgba(251,191,36,0.85)] transition-transform duration-300 group-hover:scale-110">
                    <Play className="mr-1 h-8 w-8 text-amber-300" />
                  </span>
                </button>
              ) : null}
            </div>
          </div>

          {/* نوارِ پخش */}
          <div className="rounded-2xl border border-slate-800/70 bg-[#080c1a]/80 p-3 backdrop-blur">
            {/* تایم‌لاینِ فصل‌دار */}
            <div className="relative mb-2 h-8 w-full select-none">
              <div className="absolute inset-x-0 top-3 flex h-2 overflow-hidden rounded-full bg-slate-900">
                {info.chapters.map((c) => (
                  <span
                    key={c.id}
                    title={`${c.badge} — ${c.title}`}
                    className="h-full border-l border-[#05070f] transition-all duration-300 hover:brightness-150"
                    style={{
                      width: `${((c.end - c.start) / info.span) * 100}%`,
                      background: `linear-gradient(90deg, ${c.bgBottom}, ${c.accent}55)`,
                      opacity: visualTime >= c.start ? 1 : 0.4,
                    }}
                  />
                ))}
              </div>
              <div
                className="absolute top-1.5 h-5 w-1 -translate-x-1/2 rounded-full bg-amber-200 shadow-[0_0_14px_rgba(251,191,36,0.95)] transition-[right] duration-100"
                style={{ right: `${playFraction * 100}%` }}
              />
              <input
                type="range"
                min={0}
                max={1000}
                value={Math.round(playFraction * 1000)}
                onChange={(e) => seek((Number(e.target.value) / 1000) * totalDur)}
                className="seek absolute inset-0 h-8 w-full cursor-pointer opacity-0"
                aria-label="جست‌وجوی زمان"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <IconBtn onClick={restart} title="از ابتدا">
                <RotateCcw className="h-4 w-4" />
              </IconBtn>
              <button
                type="button"
                onClick={togglePlay}
                className="grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-b from-amber-300 to-orange-500 text-[#1c1305] shadow-[0_12px_30px_-12px_rgba(251,191,36,0.95)] transition hover:-translate-y-0.5"
                title={isPlaying ? 'توقف' : 'پخش'}
              >
                {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="mr-0.5 h-5 w-5" />}
              </button>
              <div className="rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2 text-[12px] font-bold tabular-nums text-slate-200">
                {formatTimeFa(currentTime)} <span className="text-slate-600">/</span> {formatTimeFa(totalDur)}
              </div>

              <div className="mr-auto flex items-center gap-2">
                <IconBtn onClick={() => setMuted((v) => !v)} title={muted ? 'صدا روشن' : 'بی‌صدا'}>
                  {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                </IconBtn>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={Math.round(volume * 100)}
                  onChange={(e) => {
                    setVolume(Number(e.target.value) / 100);
                    setMuted(false);
                  }}
                  className="vol h-6 w-24 cursor-pointer"
                  aria-label="بلندیِ صدا"
                />
                <IconBtn onClick={() => setShowSubtitles((v) => !v)} title="زیرنویس (S)" active={showSubtitles}>
                  <Subtitles className="h-4 w-4" />
                </IconBtn>
                <IconBtn onClick={() => setShowHud((v) => !v)} title="هدرِ فصل (H)" active={showHud}>
                  <Eye className="h-4 w-4" />
                </IconBtn>
                <IconBtn onClick={toggleFullscreen} title="تمام‌صفحه (F)">
                  {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
                </IconBtn>
              </div>
            </div>

            {/* زیرنویسِ جاری */}
            <div className="mt-3 min-h-[46px] rounded-xl border border-slate-800/80 bg-slate-950/60 px-4 py-2.5">
              {caption ? (
                <p
                  className={cn(
                    'text-[13.5px] leading-7',
                    caption.highlight ? 'font-extrabold text-amber-200' : 'text-slate-300',
                  )}
                >
                  {caption.text}
                </p>
              ) : (
                <p className="text-[12.5px] text-slate-600">—</p>
              )}
            </div>
          </div>

          {/* ریلِ فصل‌ها */}
          <div className="rounded-2xl border border-slate-800/70 bg-[#080c1a]/70 p-3 backdrop-blur">
            <div className="mb-2 flex items-center justify-between px-1">
              <h2 className="flex items-center gap-2 text-[12.5px] font-extrabold text-slate-300">
                <Layers className="h-4 w-4 text-amber-400" />
                ریلِ فصل‌ها — کلیک برای پرش
              </h2>
              <span className="text-[11px] text-slate-500">
                فصلِ {toFaDigits(chapter.id)} از ۱۲ • {toFaDigits(Math.round(playFraction * 100))}٪
              </span>
            </div>
            <div className="rail flex gap-2 overflow-x-auto pb-2">
              {info.chapters.map((c) => {
                const active = c.id === chapter.id;
                const playStart = info.fromVisual(c.start);
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => seek(playStart + 0.05)}
                    className={cn(
                      'group relative w-[132px] shrink-0 overflow-hidden rounded-xl border p-1 text-right transition-all duration-300',
                      active
                        ? 'border-amber-400/60 bg-amber-400/10 shadow-[0_0_30px_-12px_rgba(251,191,36,0.9)]'
                        : 'border-slate-800 bg-slate-950/50 hover:-translate-y-0.5 hover:border-slate-600',
                    )}
                  >
                    <canvas
                      ref={(el) => {
                        thumbRefs.current[c.id] = el;
                      }}
                      width={126}
                      height={70}
                      className="h-[62px] w-full rounded-lg object-cover"
                    />
                    <div className="mt-1 flex items-center gap-1 px-1 pb-0.5">
                      <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: c.accent }} />
                      <span
                        className={cn(
                          'truncate text-[10.5px] font-bold',
                          active ? 'text-amber-200' : 'text-slate-400 group-hover:text-slate-200',
                        )}
                      >
                        {c.badge} • {c.title}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        {/* پنلِ کناری */}
        <aside className="flex flex-col gap-4 lg:sticky lg:top-4 lg:h-[calc(100vh-2rem)] lg:overflow-hidden">
          <div className="flex gap-1 rounded-2xl border border-slate-800/70 bg-[#080c1a]/80 p-1.5 backdrop-blur">
            {(
              [
                { id: 'export', label: 'خروجی و لینک', icon: <Sparkles className="h-3.5 w-3.5" /> },
                { id: 'chapters', label: 'فصل‌ها', icon: <Layers className="h-3.5 w-3.5" /> },
                { id: 'captions', label: 'زیرنویس', icon: <Subtitles className="h-3.5 w-3.5" /> },
                { id: 'guide', label: 'راهنما', icon: <Gauge className="h-3.5 w-3.5" /> },
              ] as const
            ).map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={cn(
                  'flex flex-1 items-center justify-center gap-1.5 rounded-xl px-2 py-2 text-[11.5px] font-bold transition-all duration-300',
                  tab === t.id
                    ? 'bg-gradient-to-b from-slate-100 to-slate-300 text-[#0a0d18] shadow-[0_10px_24px_-14px_rgba(255,255,255,0.9)]'
                    : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-100',
                )}
              >
                {t.icon}
                {t.label}
              </button>
            ))}
          </div>

          <div className="rail min-h-0 flex-1 overflow-y-auto rounded-2xl border border-slate-800/70 bg-[#060a15]/70 p-3 backdrop-blur">
            {tab === 'export' ? (
              <ExportPanel
                mode={mode}
                setMode={setMode}
                audioSource={usesVoice ? (audioSource === 'none' ? 'none' : 'voice') : audioSource}
                episodeId={episode}
                setAudioSource={setAudioSource}
                resolution={resolution}
                setResolution={setResolution}
                fps={fps}
                setFps={setFps}
                showSubtitles={showSubtitles}
                setShowSubtitles={setShowSubtitles}
                showHud={showHud}
                setShowHud={setShowHud}
                webcodecsOk={webcodecsOk}
                narrationUrl={narrationUrl}
                onPickAudioFile={pickAudioFile}
                isExporting={isExporting}
                startExport={() => void startExport()}
                cancelExport={cancelExport}
                progress={exportProgress}
                error={exportError}
                result={exportResult}
                links={links}
                uploading={uploading}
                uploadError={uploadError}
                uploadTo={(h) => void uploadTo(h)}
              />
            ) : null}

            {tab === 'chapters' ? (
              <div className="space-y-2">
                {info.chapters.map((c) => {
                  const active = c.id === chapter.id;
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => seek(info.fromVisual(c.start) + 0.05)}
                      className={cn(
                        'w-full rounded-xl border p-3 text-right transition-all duration-300',
                        active
                          ? 'border-amber-400/50 bg-amber-400/8'
                          : 'border-slate-800 bg-slate-950/40 hover:border-slate-600 hover:bg-slate-900/60',
                      )}
                    >
                      <div className="mb-1 flex items-center gap-2">
                        <span
                          className="grid h-6 w-6 shrink-0 place-items-center rounded-lg text-[11px] font-black text-[#080b16]"
                          style={{ background: c.accent }}
                        >
                          {toFaDigits(c.id)}
                        </span>
                        <span className="text-[13px] font-extrabold text-slate-100">{c.title}</span>
                        <span className="mr-auto text-[10.5px] tabular-nums text-slate-500">
                          {formatTimeFa(c.start)} – {formatTimeFa(c.end)}
                        </span>
                      </div>
                      <p className="text-[11.5px] leading-6 text-slate-400">{c.subtitle}</p>
                      {c.verseAr ? (
                        <p className="font-display mt-1 truncate text-[12.5px] text-amber-200/80">{c.verseAr}</p>
                      ) : null}
                    </button>
                  );
                })}
              </div>
            ) : null}

            {tab === 'captions' ? (
              <div ref={captionBoxRef} className="space-y-1.5">
                {info.captions.map((c, i) => {
                  const active = i === captionIndex;
                  return (
                    <button
                      key={`${c.start}-${i}`}
                      type="button"
                      onClick={() => seek(info.fromVisual(c.start) + 0.02)}
                      className={cn(
                        'flex w-full gap-2 rounded-lg border px-3 py-2 text-right transition-all duration-300',
                        active
                          ? 'border-amber-400/50 bg-amber-400/10 text-amber-100'
                          : 'border-transparent bg-slate-950/40 text-slate-400 hover:border-slate-700 hover:text-slate-200',
                      )}
                    >
                      <span className="mt-0.5 shrink-0 text-[10.5px] tabular-nums text-slate-500">
                        {formatTimeFa(c.start)}
                      </span>
                      <span className={cn('text-[12px] leading-6', c.highlight && 'font-extrabold')}>{c.text}</span>
                    </button>
                  );
                })}
              </div>
            ) : null}

            {tab === 'guide' ? <GuidePanel narrationState={narrationState} /> : null}

            <ExportPanelFooter />
          </div>
        </aside>
      </main>

      <footer className="relative z-10 border-t border-slate-800/60 bg-[#05070f]/80 px-4 py-5 text-center text-[11.5px] leading-7 text-slate-500 lg:px-8">
        موتورِ رندر: Canvas2D + WebCodecs + mp4-muxer • تایپوگرافی: Amiri و Vazirmatn • میان‌برها: Space پخش، ← →
        پنج ثانیه، S زیرنویس، H هدر، F تمام‌صفحه
      </footer>
    </div>
  );
}

/* ------------------------------------------------------------------ */

function Chip({
  tone,
  icon,
  text,
}: {
  tone: 'ok' | 'warn' | 'info' | 'gold' | 'muted';
  icon: React.ReactNode;
  text: string;
}) {
  const tones: Record<string, string> = {
    ok: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200',
    warn: 'border-rose-500/40 bg-rose-500/10 text-rose-200',
    info: 'border-sky-500/40 bg-sky-500/10 text-sky-200',
    gold: 'border-amber-400/40 bg-amber-400/10 text-amber-200',
    muted: 'border-slate-700 bg-slate-900/60 text-slate-300',
  };
  return (
    <span className={cn('flex items-center gap-1.5 rounded-full border px-3 py-1.5', tones[tone])}>
      {icon}
      {text}
    </span>
  );
}

function IconBtn({
  onClick,
  title,
  active,
  children,
}: {
  onClick: () => void;
  title: string;
  active?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      className={cn(
        'grid h-9 w-9 place-items-center rounded-lg border transition-all duration-300 hover:-translate-y-0.5',
        active
          ? 'border-amber-400/50 bg-amber-400/12 text-amber-200'
          : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:border-slate-600 hover:text-slate-100',
      )}
    >
      {children}
    </button>
  );
}

function GuidePanel({ narrationState }: { narrationState: string }) {
  const steps = [
    {
      icon: <Clapperboard className="h-4 w-4" />,
      title: '۱) پیش‌نمایش',
      body: 'کلیدِ پخش را بزنید؛ ۱۲ فصلِ المان‌محور با موسیقیِ آمبینتِ تولیدشده پخش می‌شود و تصویر به صدا واکنش می‌دهد.',
    },
    {
      icon: <Wand2 className="h-4 w-4" />,
      title: '۲) ساختِ MP4',
      body: 'نسخهٔ ۷ دقیقه‌ای یا روایتِ کامل را انتخاب کنید، کیفیت را بگذارید و «ساختِ MP4» را بزنید. رندر آفلاین است؛ یعنی چند برابرِ سریع‌تر از زمانِ واقعی ویدیو ساخته می‌شود.',
    },
    {
      icon: <ChevronLeft className="h-4 w-4" />,
      title: '۳) دانلود',
      body: 'پس از پایان، فایل با دکمهٔ سبز مستقیماً روی دستگاهِ شما ذخیره می‌شود.',
    },
    {
      icon: <Radio className="h-4 w-4" />,
      title: '۴) لینکِ عمومی',
      body: 'با یک کلیک، همان فایل روی tmpfiles.org یا gofile.io آپلود می‌شود و لینکِ مستقیمِ دانلود به شما داده می‌شود (قابلِ کپی و اشتراک).',
    },
  ];
  return (
    <div className="space-y-3">
      {steps.map((s) => (
        <div
          key={s.title}
          className="rounded-xl border border-slate-800 bg-slate-950/50 p-3 transition-colors duration-300 hover:border-amber-400/40"
        >
          <div className="mb-1 flex items-center gap-2 text-[12.5px] font-extrabold text-amber-200">
            {s.icon}
            {s.title}
          </div>
          <p className="text-[11.5px] leading-6 text-slate-400">{s.body}</p>
        </div>
      ))}

      <div className="rounded-xl border border-slate-800 bg-slate-950/50 p-3">
        <div className="mb-1 flex items-center gap-2 text-[12.5px] font-extrabold text-slate-200">
          <Music className="h-4 w-4 text-sky-400" />
          فایلِ صوتیِ روایت
        </div>
        <p className="text-[11.5px] leading-6 text-slate-400">
          منبع: <span className="text-slate-300">01-WhatsApp Ptt 2026-11-04 at 12.00.55.ogg</span> — مدتِ تقریبی
          ۱۸:۴۵. در حالتِ «روایتِ کامل» همین صدا روی تایم‌لاینِ تصویری نگاشت می‌شود.
        </p>
        <div className="mt-2 flex items-center gap-2 text-[11px] font-bold">
          <span className="flex items-center gap-1 text-slate-500">
            <LoaderCircle className={cn('h-3.5 w-3.5', narrationState === 'loading' && 'animate-spin')} />
            وضعیتِ بارگذاری:
          </span>
          <span
            className={cn(
              narrationState === 'ready'
                ? 'text-emerald-300'
                : narrationState === 'error'
                  ? 'text-rose-300'
                  : 'text-slate-400',
            )}
          >
            {narrationState === 'ready'
              ? 'آماده'
              : narrationState === 'error'
                ? 'در دسترس نیست — فایل را دستی انتخاب کنید'
                : narrationState === 'loading'
                  ? 'در حالِ دریافت…'
                  : 'در انتظارِ انتخابِ حالتِ کامل'}
          </span>
        </div>
      </div>

      <div className="rounded-xl border border-slate-800 bg-slate-950/50 p-3">
        <div className="mb-1 flex items-center gap-2 text-[12.5px] font-extrabold text-slate-200">
          <CalendarCheck className="h-4 w-4 text-emerald-400" />
          نکاتِ مهم
        </div>
        <ul className="space-y-1 text-[11.5px] leading-6 text-slate-400">
          <li>• برای ساختِ MP4 از Chrome یا Edge به‌روز استفاده کنید (WebCodecs).</li>
          <li>• در ویدیوی ۱۰۸۰p و حالتِ کامل، حافظهٔ بیشتری مصرف می‌شود؛ تب‌های اضافی را ببندید.</li>
          <li>• متنِ فصل‌ها و زیرنویس‌ها در فایلِ timelineData.ts قابلِ ویرایش است.</li>
          <li>• لینکِ tmpfiles.org موقتی است؛ فایل را پس از آپلود زود دانلود کنید.</li>
        </ul>
      </div>

      <div className="flex items-center gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/8 p-3 text-[11.5px] leading-6 text-emerald-200">
        <CheckCircle2 className="h-4 w-4 shrink-0" />
        <span>
          هر ۱۲ صحنه به‌صورتِ المان‌محور و کدنویسی‌شده هستند: خورشید و طلوع، منشورِ ورودیِ ذهن، شهرِ در حالِ رشد،
          منظومهٔ تسبیح، هفت دریا و قلم‌ها، آناتومیِ انفس، باشگاهِ ذهن، ساعتِ ده دقیقه، سینمای غیب، پله‌های هدایت،
          تجزیهٔ فَسَنُيَسِّرُهُ و رویشِ بذر.
        </span>
      </div>
    </div>
  );
}
