import { useCallback, useRef, useState } from 'react';
import {
  CheckCircle2,
  Copy,
  Download,
  ExternalLink,
  FileVideo,
  Film,
  LoaderCircle,
  Music,
  Radio,
  Sparkles,
  Upload,
  XCircle,
  Zap,
} from 'lucide-react';
import { cn } from '@/utils/cn';
import type { ExportResult } from '@/motion/mp4Exporter';
import type { HostedLink } from '@/motion/uploader';

interface Props {
  episodeId?: 'ep1' | 'ep2';
  mode: '7min' | 'full';
  setMode: (m: '7min' | 'full') => void;
  audioSource: 'ambient' | 'voice' | 'none';
  setAudioSource: (a: 'ambient' | 'voice' | 'none') => void;
  resolution: '720p' | '1080p';
  setResolution: (r: '720p' | '1080p') => void;
  fps: number;
  setFps: (f: number) => void;
  showSubtitles: boolean;
  setShowSubtitles: (v: boolean) => void;
  showHud: boolean;
  setShowHud: (v: boolean) => void;
  webcodecsOk: boolean;
  narrationUrl: string;
  onPickAudioFile: (file: File) => void;
  isExporting: boolean;
  startExport: () => void;
  cancelExport: () => void;
  progress: {
    phase: string;
    percent: number;
    currentFrame: number;
    totalFrames: number;
    elapsedSec: number;
    etaSec: number;
    detail: string;
  } | null;
  error: string | null;
  result: { data: ExportResult; url: string } | null;
  links: HostedLink[];
  uploading: { host: string; percent: number } | null;
  uploadError: string | null;
  uploadTo: (host: 'tmpfiles.org' | 'gofile.io') => void;
}

function fmt(sec: number) {
  const s = Math.max(0, Math.floor(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

function mb(bytes: number) {
  return (bytes / 1048576).toFixed(1);
}

const PHASE_FA: Record<string, string> = {
  preparing: 'آماده‌سازی',
  audio_build: 'ساخت باند صوتی',
  encoding_audio: 'رمزگذاری صدا',
  rendering_video: 'رندر فریم‌ها',
  finalizing: 'نهایی‌سازی MP4',
};

function Toggle({
  on,
  onChange,
  label,
  icon,
}: {
  on: boolean;
  onChange: (v: boolean) => void;
  label: string;
  icon?: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!on)}
      className={cn(
        'group flex w-full items-center justify-between gap-3 rounded-xl border px-3 py-2.5 text-right transition-all duration-300',
        on
          ? 'border-amber-400/45 bg-amber-400/10 text-amber-100 shadow-[0_0_24px_-12px_rgba(251,191,36,0.8)]'
          : 'border-slate-700/60 bg-slate-900/40 text-slate-400 hover:border-slate-500/70 hover:text-slate-200',
      )}
    >
      <span className="flex items-center gap-2 text-[13px] font-semibold">
        {icon}
        {label}
      </span>
      <span
        className={cn(
          'relative h-5 w-9 shrink-0 rounded-full transition-colors duration-300',
          on ? 'bg-amber-400/80' : 'bg-slate-700/70',
        )}
      >
        <span
          className={cn(
            'absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-all duration-300',
            on ? 'right-0.5' : 'right-4',
          )}
        />
      </span>
    </button>
  );
}

function SegBtn({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex-1 rounded-lg px-2.5 py-2 text-[12.5px] font-bold transition-all duration-300',
        active
          ? 'bg-gradient-to-b from-amber-300 to-amber-500 text-[#20160a] shadow-[0_6px_22px_-8px_rgba(251,191,36,0.9)]'
          : 'text-slate-400 hover:bg-slate-800/70 hover:text-slate-100',
      )}
    >
      {children}
    </button>
  );
}

export default function ExportPanel(p: Props) {
  const [copied, setCopied] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  const copy = useCallback(async (text: string, key: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      window.setTimeout(() => setCopied(null), 1800);
    } catch {
      /* noop */
    }
  }, []);

  const totalFrames = p.progress?.totalFrames ?? 0;

  return (
    <div className="flex flex-col gap-4">
      {/* ---- انتخاب نسخه ---- */}
      {p.episodeId === 'ep2' ? (
        <section className="rounded-2xl border border-amber-400/30 bg-amber-400/5 p-4">
          <h3 className="mb-1 flex items-center gap-2 text-[13px] font-extrabold text-amber-200">
            <Film className="h-4 w-4" />
            اپیزود ۲ • تسلیم؛ رمزِ موفقیتِ پیامبران
          </h3>
          <p className="text-[11.5px] leading-6 text-slate-400">
            ۱۵ فصلِ المان‌محور روی صدای کاملِ ۱۴:۴۰ (k-WhatsApp Audio 2026-10-03). تصویر هم‌زمان با گفتار و واکنش‌گرا به صدا.
          </p>
        </section>
      ) : (
      <section className="rounded-2xl border border-slate-800/80 bg-[#080c1a]/80 p-4 shadow-[inset_0_1px_0_rgba(255,255,255,0.04)]">
        <h3 className="mb-3 flex items-center gap-2 text-[13px] font-extrabold tracking-tight text-slate-200">
          <Film className="h-4 w-4 text-amber-400" />
          نسخهٔ ویدیو
        </h3>
        <div className="flex gap-2 rounded-xl bg-slate-900/70 p-1">
          <SegBtn active={p.mode === '7min'} onClick={() => p.setMode('7min')}>
            ۷ دقیقه • ۴۲۰ ثانیه
          </SegBtn>
          <SegBtn active={p.mode === 'full'} onClick={() => p.setMode('full')}>
            روایتِ کامل • ۱۸:۴۵
          </SegBtn>
        </div>
        <p className="mt-2 text-[11.5px] leading-6 text-slate-500">
          {p.mode === '7min'
            ? 'تایم‌لاینِ فشردهٔ ۱۲ فصلی با موسیقیِ متنِ تولیدشده در همان لحظه.'
            : 'کلِ فایلِ صوتیِ WhatsApp Ptt با نگاشتِ فصل‌به‌فصلِ تصویر روی روایت.'}
        </p>
      </section>
      )}

      {/* ---- صدا ---- */}
      <section className="rounded-2xl border border-slate-800/80 bg-[#080c1a]/80 p-4">
        <h3 className="mb-3 flex items-center gap-2 text-[13px] font-extrabold text-slate-200">
          <Music className="h-4 w-4 text-sky-400" />
          باندِ صوتیِ خروجی
        </h3>
        <div className="flex gap-2 rounded-xl bg-slate-900/70 p-1">
          {p.mode === '7min' && p.episodeId !== 'ep2' ? (
            <>
              <SegBtn active={p.audioSource === 'ambient'} onClick={() => p.setAudioSource('ambient')}>
                آمبینتِ سینمایی
              </SegBtn>
              <SegBtn active={p.audioSource === 'none'} onClick={() => p.setAudioSource('none')}>
                بی‌صدا
              </SegBtn>
            </>
          ) : (
            <>
              <SegBtn active={p.audioSource === 'voice'} onClick={() => p.setAudioSource('voice')}>
                روایتِ استاد
              </SegBtn>
              <SegBtn active={p.audioSource === 'none'} onClick={() => p.setAudioSource('none')}>
                بی‌صدا
              </SegBtn>
            </>
          )}
        </div>

        {(p.mode === 'full' || p.episodeId === 'ep2') && (
          <div className="mt-3 space-y-2">
            <div className="truncate rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2 text-[11px] text-slate-400 dir-ltr">
              {p.narrationUrl}
            </div>
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="w-full rounded-lg border border-dashed border-slate-700 px-3 py-2 text-[11.5px] font-semibold text-slate-400 transition hover:border-sky-500/60 hover:text-sky-300"
            >
              یا فایلِ صوتیِ دلخواه را از دستگاه انتخاب کنید (ogg / mp3 / m4a)
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="audio/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) p.onPickAudioFile(f);
                e.target.value = '';
              }}
            />
          </div>
        )}
      </section>

      {/* ---- کیفیت ---- */}
      <section className="rounded-2xl border border-slate-800/80 bg-[#080c1a]/80 p-4">
        <h3 className="mb-3 flex items-center gap-2 text-[13px] font-extrabold text-slate-200">
          <Zap className="h-4 w-4 text-emerald-400" />
          کیفیت و کدک
        </h3>
        <div className="mb-2 flex gap-2 rounded-xl bg-slate-900/70 p-1">
          <SegBtn active={p.resolution === '720p'} onClick={() => p.setResolution('720p')}>
            720p • سبک
          </SegBtn>
          <SegBtn active={p.resolution === '1080p'} onClick={() => p.setResolution('1080p')}>
            1080p • سینمایی
          </SegBtn>
        </div>
        <div className="flex gap-2 rounded-xl bg-slate-900/70 p-1">
          {[24, 30, 60].map((f) => (
            <SegBtn key={f} active={p.fps === f} onClick={() => p.setFps(f)}>
              {f} fps
            </SegBtn>
          ))}
        </div>
        <div className="mt-3 grid gap-2">
          <Toggle on={p.showSubtitles} onChange={p.setShowSubtitles} label="زیرنویسِ فارسی" />
          <Toggle on={p.showHud} onChange={p.setShowHud} label="هدرِ فصل و نوارِ زمان" />
        </div>
      </section>

      {/* ---- دکمهٔ ساخت ---- */}
      <section className="rounded-2xl border border-slate-800/80 bg-[#080c1a]/80 p-4">
        {!p.webcodecsOk ? (
          <div className="mb-3 flex items-start gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-[11.5px] leading-6 text-amber-200">
            <XCircle className="mt-0.5 h-4 w-4 shrink-0" />
            <span>
              مرورگرِ شما WebCodecs ندارد؛ برای ساخت MP4 از Chrome یا Edge نسخهٔ جدید استفاده کنید.
            </span>
          </div>
        ) : null}

        {!p.isExporting ? (
          <button
            type="button"
            disabled={!p.webcodecsOk}
            onClick={p.startExport}
            className={cn(
              'relative w-full overflow-hidden rounded-xl px-4 py-4 text-[15px] font-black tracking-tight transition-all duration-300',
              p.webcodecsOk
                ? 'bg-gradient-to-b from-amber-300 via-amber-400 to-orange-500 text-[#1c1305] shadow-[0_18px_44px_-16px_rgba(251,191,36,0.95)] hover:-translate-y-0.5 hover:shadow-[0_26px_60px_-18px_rgba(251,191,36,1)] active:translate-y-0'
                : 'cursor-not-allowed bg-slate-800 text-slate-500',
            )}
          >
            <span className="relative z-10 flex items-center justify-center gap-2">
              <FileVideo className="h-5 w-5" />
              ساختِ MP4 و دانلود
            </span>
            {p.webcodecsOk ? <span className="sheen absolute inset-0 z-0 opacity-60" /> : null}
          </button>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-[12px] font-bold text-slate-300">
              <span className="flex items-center gap-2">
                <LoaderCircle className="h-4 w-4 animate-spin text-amber-400" />
                {PHASE_FA[p.progress?.phase ?? 'preparing']}
              </span>
              <span className="tabular-nums text-amber-300">
                {Math.round(p.progress?.percent ?? 0)}٪
              </span>
            </div>
            <div className="h-2.5 overflow-hidden rounded-full bg-slate-900">
              <div
                className="h-full rounded-full bg-gradient-to-l from-amber-300 via-orange-400 to-rose-400 transition-[width] duration-200"
                style={{ width: `${p.progress?.percent ?? 2}%` }}
              />
            </div>
            <p className="text-[11.5px] leading-6 text-slate-400">{p.progress?.detail}</p>
            <div className="grid grid-cols-3 gap-2 text-center text-[11px] text-slate-400">
              <div className="rounded-lg bg-slate-900/70 py-2">
                <div className="text-[14px] font-black text-slate-100 tabular-nums">
                  {p.progress?.currentFrame ?? 0}
                </div>
                فریم از {totalFrames}
              </div>
              <div className="rounded-lg bg-slate-900/70 py-2">
                <div className="text-[14px] font-black text-slate-100 tabular-nums">
                  {fmt(p.progress?.elapsedSec ?? 0)}
                </div>
                زمانِ سپری
              </div>
              <div className="rounded-lg bg-slate-900/70 py-2">
                <div className="text-[14px] font-black text-emerald-300 tabular-nums">
                  {fmt(p.progress?.etaSec ?? 0)}
                </div>
                باقی‌مانده
              </div>
            </div>
            <button
              type="button"
              onClick={p.cancelExport}
              className="w-full rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-2.5 text-[12.5px] font-bold text-rose-200 transition hover:bg-rose-500/20"
            >
              لغوِ فرایند
            </button>
          </div>
        )}

        {p.error ? (
          <div className="mt-3 flex items-start gap-2 rounded-xl border border-rose-500/35 bg-rose-500/10 p-3 text-[11.5px] leading-6 text-rose-200">
            <XCircle className="mt-0.5 h-4 w-4 shrink-0" />
            <span>{p.error}</span>
          </div>
        ) : null}
      </section>

      {/* ---- نتیجه ---- */}
      {p.result ? (
        <section className="animate-rise rounded-2xl border border-emerald-500/35 bg-gradient-to-b from-emerald-500/12 to-transparent p-4">
          <h3 className="mb-2 flex items-center gap-2 text-[13px] font-extrabold text-emerald-200">
            <CheckCircle2 className="h-4 w-4" />
            فایلِ MP4 آماده شد
          </h3>
          <div className="mb-3 grid grid-cols-2 gap-2 text-[11px] text-slate-400">
            <div className="rounded-lg bg-slate-950/60 px-3 py-2">
              <div className="text-[13px] font-black text-slate-100">{mb(p.result.data.sizeBytes)} MB</div>
              حجمِ فایل
            </div>
            <div className="rounded-lg bg-slate-950/60 px-3 py-2">
              <div className="text-[13px] font-black text-slate-100">
                {p.result.data.width}×{p.result.data.height} • {p.result.data.fps}fps
              </div>
              ابعاد و نرخِ فریم
            </div>
            <div className="col-span-2 truncate rounded-lg bg-slate-950/60 px-3 py-2" title={p.result.data.codecLabel}>
              <div className="truncate text-[12px] font-bold text-slate-200">{p.result.data.codecLabel}</div>
              کدک • مدت {fmt(p.result.data.durationSec)}
            </div>
          </div>

          <a
            href={p.result.url}
            download={p.result.data.filename}
            className="mb-3 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-400 px-4 py-3 text-[14px] font-black text-[#04170f] shadow-[0_16px_40px_-16px_rgba(52,211,153,0.9)] transition hover:-translate-y-0.5 hover:bg-emerald-300"
          >
            <Download className="h-5 w-5" />
            دانلودِ مستقیم از مرورگر
          </a>

          <div className="mb-2 flex items-center gap-2 text-[12.5px] font-extrabold text-slate-200">
            <Upload className="h-4 w-4 text-sky-400" />
            لینکِ عمومیِ دانلود
          </div>
          <p className="mb-3 text-[11.5px] leading-6 text-slate-500">
            فایل از همین مرورگرِ شما روی سرویسِ عمومی آپلود می‌شود و لینکِ دانلود گرفته می‌شود.
          </p>
          <div className="grid gap-2">
            {(['tmpfiles.org', 'gofile.io'] as const).map((host) => {
              const busy = p.uploading?.host === host;
              const link = p.links.find((l) => l.host === host);
              return (
                <div
                  key={host}
                  className={cn(
                    'rounded-xl border p-3 transition-all duration-300',
                    link ? 'border-sky-500/40 bg-sky-500/8' : 'border-slate-800 bg-slate-950/50',
                  )}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="flex items-center gap-2 text-[12.5px] font-black text-slate-200">
                      <Radio className={cn('h-4 w-4', link ? 'text-sky-400' : 'text-slate-500')} />
                      {host}
                    </span>
                    <button
                      type="button"
                      disabled={busy || p.uploading !== null}
                      onClick={() => p.uploadTo(host)}
                      className={cn(
                        'flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[11.5px] font-bold transition',
                        busy
                          ? 'bg-slate-800 text-slate-400'
                          : 'bg-sky-500/90 text-[#04121f] hover:bg-sky-400 disabled:opacity-40',
                      )}
                    >
                      {busy ? (
                        <>
                          <LoaderCircle className="h-3.5 w-3.5 animate-spin" />
                          {Math.round(p.uploading?.percent ?? 0)}٪
                        </>
                      ) : (
                        <>
                          <Upload className="h-3.5 w-3.5" />
                          {link ? 'آپلودِ دوباره' : 'آپلود و گرفتنِ لینک'}
                        </>
                      )}
                    </button>
                  </div>

                  {busy ? (
                    <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-slate-900">
                      <div
                        className="h-full rounded-full bg-sky-400 transition-[width] duration-200"
                        style={{ width: `${p.uploading?.percent ?? 0}%` }}
                      />
                    </div>
                  ) : null}

                  {link ? (
                    <div className="mt-3 space-y-2">
                      {link.directUrl ? (
                        <LinkRow
                          label="لینکِ مستقیمِ MP4"
                          value={link.directUrl}
                          onCopy={copy}
                          copiedKey={`${host}-direct`}
                          copied={copied === `${host}-direct`}
                          primary
                        />
                      ) : null}
                      <LinkRow
                        label="صفحهٔ دانلود"
                        value={link.pageUrl}
                        onCopy={copy}
                        copiedKey={`${host}-page`}
                        copied={copied === `${host}-page`}
                      />
                      <p className="text-[11px] leading-5 text-slate-500">{link.note}</p>
                    </div>
                  ) : null}
                </div>
              );
            })}
          </div>

          {p.uploadError ? (
            <div className="mt-3 flex items-start gap-2 rounded-xl border border-rose-500/35 bg-rose-500/10 p-3 text-[11.5px] leading-6 text-rose-200">
              <XCircle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{p.uploadError}</span>
            </div>
          ) : null}
        </section>
      ) : null}
    </div>
  );
}

function LinkRow({
  label,
  value,
  onCopy,
  copied,
  copiedKey,
  primary,
}: {
  label: string;
  value: string;
  onCopy: (v: string, k: string) => void;
  copied: boolean;
  copiedKey: string;
  primary?: boolean;
}) {
  return (
    <div
      className={cn(
        'rounded-lg border px-3 py-2',
        primary ? 'border-amber-400/40 bg-amber-400/8' : 'border-slate-800 bg-slate-950/70',
      )}
    >
      <div className="mb-1 flex items-center justify-between gap-2">
        <span className={cn('text-[11px] font-bold', primary ? 'text-amber-200' : 'text-slate-400')}>{label}</span>
        <span className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => onCopy(value, copiedKey)}
            className="flex items-center gap-1 rounded-md bg-slate-800/90 px-2 py-1 text-[10.5px] font-bold text-slate-300 transition hover:bg-slate-700 hover:text-white"
          >
            {copied ? <CheckCircle2 className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
            {copied ? 'کپی شد' : 'کپی'}
          </button>
          <a
            href={value}
            target="_blank"
            rel="noreferrer noopener"
            className="flex items-center gap-1 rounded-md bg-slate-800/90 px-2 py-1 text-[10.5px] font-bold text-sky-300 transition hover:bg-sky-500/25"
          >
            <ExternalLink className="h-3 w-3" />
            بازکردن
          </a>
        </span>
      </div>
      <a
        href={value}
        target="_blank"
        rel="noreferrer noopener"
        className="block truncate text-[11px] text-slate-400 underline decoration-dotted underline-offset-4 dir-ltr hover:text-slate-200"
        dir="ltr"
      >
        {value}
      </a>
    </div>
  );
}

export function ExportPanelFooter() {
  return (
    <div className="mt-4 flex items-center gap-2 rounded-xl border border-slate-800/80 bg-slate-950/60 p-3 text-[11px] leading-6 text-slate-500">
      <Sparkles className="h-4 w-4 shrink-0 text-amber-400/70" />
      <span>
        همهٔ رندر، رمزگذاری و آپلود داخلِ مرورگرِ خودتان انجام می‌شود؛ هیچ فایلی روی سرورِ ما نمی‌رود.
      </span>
    </div>
  );
}
