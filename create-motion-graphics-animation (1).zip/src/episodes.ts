/* ------------------------------------------------------------------
   episodes.ts — رابطِ یکسان برای اپیزودهای موشن گرافیک
------------------------------------------------------------------ */
import { drawChapterThumb, drawMotionFrame } from '@/motion/renderer';
import {
  CAPTIONS,
  DURATION_7MIN,
  FULL_TO_VISUAL,
  MOTION_CHAPTERS,
  NARRATION_URL,
  getModeDuration,
  resolveVisualTime,
} from '@/motion/timelineData';
import { drawEp2Frame } from '@/motion2/renderer2';
import { EP2_AUDIO_URL, EP2_CAPTIONS, EP2_CHAPTERS, EP2_DURATION } from '@/motion2/timeline2';

export type EpisodeId = 'ep1' | 'ep2';
export type Ep1Mode = '7min' | 'full';

export interface UiChapter {
  id: number;
  title: string;
  subtitle: string;
  badge: string;
  start: number;
  end: number;
  accent: string;
  bgBottom: string;
  verseAr?: string;
  verseRef?: string;
}

export interface UiCue {
  start: number;
  end: number;
  text: string;
  highlight?: boolean | string;
}

export interface DrawOpts {
  showSubtitles: boolean;
  showHud: boolean;
}

export interface EpisodeInfo {
  id: EpisodeId;
  name: string;
  tagline: string;
  /** مدتِ پخش (ثانیه) */
  duration: number;
  /** طولِ تایم‌لاینِ بصری */
  span: number;
  chapters: UiChapter[];
  captions: UiCue[];
  /** آدرسِ صدای روایت؛ null یعنی موسیقیِ آمبینتِ تولیدی */
  audioUrl: string | null;
  toVisual: (playT: number) => number;
  fromVisual: (v: number) => number;
  draw: (ctx: CanvasRenderingContext2D, t: number, w: number, h: number, e: number, o: DrawOpts) => void;
  thumb: (ctx: CanvasRenderingContext2D, ch: UiChapter, w: number, h: number) => void;
}

/** لینک‌های عمومیِ MP4 که از پیش رندر و آپلود شده‌اند */
export interface PublishedLink {
  host: string;
  url: string;
  direct?: boolean;
}

export const PUBLISHED: Record<EpisodeId, PublishedLink[]> = {
  ep1: [],
  ep2: [
    { host: 'gofile.io', url: 'https://gofile.io/d/PpuKzUzv' },
    { host: 'tmpfiles.org', url: 'https://tmpfiles.org/w7AA00vytPbU/tasleem-motion-graphic-720p.mp4' },
  ],
};

export function chapterAt(chs: UiChapter[], v: number): UiChapter {
  for (const c of chs) if (v >= c.start && v < c.end) return c;
  return v < 0 ? chs[0] : chs[chs.length - 1];
}

export function captionAt(cues: UiCue[], v: number): UiCue | null {
  return cues.find((c) => v >= c.start && v < c.end) ?? null;
}

export function getEpisode(id: EpisodeId, mode: Ep1Mode, narrationOverride?: string): EpisodeInfo {
  if (id === 'ep2') {
    const chapters: UiChapter[] = EP2_CHAPTERS.map((c) => ({
      id: c.id,
      title: c.title,
      subtitle: c.subtitle,
      badge: `فصل ${c.id}`,
      start: c.start,
      end: c.end,
      accent: c.accent,
      bgBottom: c.bgBottom,
    }));
    return {
      id,
      name: 'تسلیم؛ رمزِ موفقیتِ پیامبران',
      tagline: '۱۵ فصل • ۱۴:۴۰ • روی صدای اصلی',
      duration: EP2_DURATION,
      span: EP2_DURATION,
      chapters,
      captions: EP2_CAPTIONS,
      audioUrl: narrationOverride ?? EP2_AUDIO_URL,
      toVisual: (t) => Math.max(0, Math.min(EP2_DURATION, t)),
      fromVisual: (v) => v,
      draw: (ctx, t, w, h, e, o) => drawEp2Frame(ctx, t, w, h, e, o),
      thumb: (ctx, ch, w, h) => {
        ctx.clearRect(0, 0, w, h);
        drawEp2Frame(ctx, ch.start + (ch.end - ch.start) * 0.6, w, h, 0.25, { showSubtitles: false, showHud: false });
      },
    };
  }
  const duration = getModeDuration(mode);
  return {
    id,
    name: 'صدّق بالحُسنی',
    tagline: mode === '7min' ? '۱۲ فصل • ۷ دقیقه • موسیقیِ آمبینت' : '۱۲ فصل • روایتِ کامل ۱۸:۴۵',
    duration,
    span: DURATION_7MIN,
    chapters: MOTION_CHAPTERS,
    captions: CAPTIONS,
    audioUrl: mode === 'full' ? (narrationOverride ?? NARRATION_URL) : null,
    toVisual: (t) => resolveVisualTime(t, mode),
    fromVisual: (v) => (mode === '7min' ? v : v / FULL_TO_VISUAL),
    draw: (ctx, t, w, h, e, o) => drawMotionFrame(ctx, t, w, h, e, { mode, ...o, totalDur: duration }),
    thumb: (ctx, ch, w, h) => {
      const full = MOTION_CHAPTERS.find((c) => c.id === ch.id);
      if (full) drawChapterThumb(ctx, full, w, h);
    },
  };
}
