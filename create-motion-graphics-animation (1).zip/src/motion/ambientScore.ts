import { seeded } from './drawPrimitives';
import { DURATION_7MIN, MOTION_CHAPTERS } from './timelineData';

/* ------------------------------------------------------------------
   ambientScore.ts
   موسیقی متنِ سینماییِ تولیدشده (آمبینت) برای موشن گرافیک ۷ دقیقه‌ای.
   کاملاً قطعی (deterministic) است؛ یعنی هم در پخش زنده و هم در رندر
   آفلاینِ MP4 دقیقاً یک نتیجه شنیده می‌شود.
------------------------------------------------------------------ */

export interface AmbientOptions {
  volume?: number;
  drone?: boolean;
  bells?: boolean;
  pulse?: boolean;
}

const MASTER_DEFAULT = 0.5;

function chordAt(t: number): number[] {
  for (const ch of MOTION_CHAPTERS) {
    if (t >= ch.start && t < ch.end) return ch.chord;
  }
  return MOTION_CHAPTERS[MOTION_CHAPTERS.length - 1].chord;
}

function makeReverb(actx: BaseAudioContext, seconds = 3.2, decay = 2.6): ConvolverNode {
  const rate = actx.sampleRate;
  const len = Math.max(1, Math.floor(rate * seconds));
  const buf = actx.createBuffer(2, len, rate);
  for (let c = 0; c < 2; c++) {
    const data = buf.getChannelData(c);
    for (let i = 0; i < len; i++) {
      const k = i / len;
      data[i] = (Math.random() * 2 - 1) * Math.pow(1 - k, decay);
    }
  }
  const conv = actx.createConvolver();
  conv.buffer = buf;
  return conv;
}

/** یک نُتِ زنگ‌مانند (bell/pluck) با decay نمایی */
function playBell(
  actx: BaseAudioContext,
  dest: AudioNode,
  when: number,
  freq: number,
  gainPeak: number,
  dur = 4.2,
) {
  const osc = actx.createOscillator();
  const osc2 = actx.createOscillator();
  const g = actx.createGain();
  const lp = actx.createBiquadFilter();
  lp.type = 'lowpass';
  lp.frequency.value = 2600;
  osc.type = 'sine';
  osc.frequency.value = freq;
  osc2.type = 'triangle';
  osc2.frequency.value = freq * 2.005;
  const g2 = actx.createGain();
  g2.gain.value = 0.24;
  osc2.connect(g2).connect(lp);
  osc.connect(lp);
  lp.connect(g).connect(dest);
  g.gain.setValueAtTime(0.0001, when);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, gainPeak), when + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, when + dur);
  osc.start(when);
  osc2.start(when);
  osc.stop(when + dur + 0.1);
  osc2.stop(when + dur + 0.1);
}

/** پَدِ آکورد با حملهٔ نرم */
function playPad(
  actx: BaseAudioContext,
  dest: AudioNode,
  when: number,
  freqs: number[],
  dur: number,
  gainPeak = 0.075,
) {
  const g = actx.createGain();
  const lp = actx.createBiquadFilter();
  lp.type = 'lowpass';
  lp.frequency.setValueAtTime(420, when);
  lp.frequency.linearRampToValueAtTime(1250, when + dur * 0.5);
  lp.frequency.linearRampToValueAtTime(500, when + dur);
  lp.Q.value = 0.8;
  g.gain.setValueAtTime(0.0001, when);
  g.gain.linearRampToValueAtTime(gainPeak, when + Math.min(3.2, dur * 0.3));
  g.gain.setValueAtTime(gainPeak, when + dur * 0.72);
  g.gain.linearRampToValueAtTime(0.0001, when + dur);
  lp.connect(g).connect(dest);
  freqs.forEach((f, i) => {
    const o = actx.createOscillator();
    o.type = i % 2 === 0 ? 'sawtooth' : 'triangle';
    o.frequency.value = f;
    o.detune.value = (i - 1) * 7;
    const og = actx.createGain();
    og.gain.value = 0.5 / freqs.length + 0.1;
    o.connect(og).connect(lp);
    o.start(when);
    o.stop(when + dur + 0.2);
  });
}

/** تپشِ نرمِ پایین (مثل ضربان) */
function playThump(actx: BaseAudioContext, dest: AudioNode, when: number, gainPeak = 0.16) {
  const o = actx.createOscillator();
  const g = actx.createGain();
  o.type = 'sine';
  o.frequency.setValueAtTime(120, when);
  o.frequency.exponentialRampToValueAtTime(42, when + 0.22);
  g.gain.setValueAtTime(0.0001, when);
  g.gain.exponentialRampToValueAtTime(gainPeak, when + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, when + 0.5);
  o.connect(g).connect(dest);
  o.start(when);
  o.stop(when + 0.55);
}

/**
 * همهٔ رویدادهای موسیقی در بازهٔ [from, to) را زمان‌بندی می‌کند.
 * `t0` = لحظهٔ واقعیِ معادلِ t=0 در این context (برای پخش زنده).
 */
export function scheduleAmbientRange(
  actx: BaseAudioContext,
  dest: AudioNode,
  from: number,
  to: number,
  t0: number,
  opts: AmbientOptions = {},
) {
  const useBells = opts.bells !== false;
  const usePulse = opts.pulse !== false;

  // پَدها فقط روی فصل‌هایی که «شروعشان» داخل این بازه است (جلوگیری از تکرار)
  for (const ch of MOTION_CHAPTERS) {
    const s = ch.start;
    const e = Math.min(ch.end, DURATION_7MIN);
    if (s < from || s >= to) continue;
    playPad(actx, dest, t0 + s, ch.chord, Math.max(2, e - s) + 0.4, 0.085);
  }

  // تپش‌ها هر ۲ ثانیه
  if (usePulse) {
    const first = Math.ceil(from / 2) * 2;
    for (let t = first; t < to; t += 2) {
      playThump(actx, dest, t0 + t, t % 8 === 0 ? 0.2 : 0.12);
    }
  }

  // زنگ‌ها: روی هر میزانِ ۴ ثانیه‌ای با زمانِ شبه‌تصادفیِ قطعی
  if (useBells) {
    const firstBar = Math.floor(from / 4) * 4;
    for (let bar = firstBar; bar < to; bar += 4) {
      const idx = bar / 4;
      const chord = chordAt(bar + 2);
      const count = 1 + Math.floor(seeded(idx * 3.7) * 3);
      for (let k = 0; k < count; k++) {
        const when = bar + seeded(idx * 11.3 + k * 5.1) * 3.6;
        if (when < from || when >= to) continue;
        const note = chord[(Math.floor(seeded(idx * 7.7 + k * 2.3) * chord.length) + 1) % chord.length];
        const oct = seeded(idx * 13.1 + k) > 0.72 ? 2 : 1;
        const accent = seeded(idx * 17.9 + k * 3) > 0.82 ? 0.2 : 0.12;
        playBell(actx, dest, t0 + when, note * oct, accent, 4.6);
      }
    }
  }
}

/** اگر پخش از وسطِ یک فصل شروع شود، باقی‌ماندهٔ پَدِ همان فصل زمان‌بندی می‌شود */
export function schedulePadTail(
  actx: BaseAudioContext,
  dest: AudioNode,
  songTime: number,
  t0: number,
) {
  for (const ch of MOTION_CHAPTERS) {
    if (songTime > ch.start + 0.05 && songTime < ch.end - 1.5) {
      playPad(actx, dest, t0 + songTime, ch.chord, ch.end - songTime + 0.4, 0.085);
      return;
    }
  }
}

/** رندرِ آفلاینِ کاملِ موسیقی متن (مونو) برای mux کردن در MP4 */
export async function renderAmbientOffline(
  durationSec = DURATION_7MIN,
  sampleRate = 48000,
  opts: AmbientOptions = {},
  onProgress?: (pct: number) => void,
): Promise<Float32Array> {
  // سگمنت‌ها دقیقاً روی مرزِ فصل‌ها برش می‌خورند تا پَدِ هیچ فصلی ناقص نماند
  const bounds = [0, ...MOTION_CHAPTERS.map((c) => Math.min(c.end, durationSec))].filter(
    (v, i, arr) => v <= durationSec && arr.indexOf(v) === i,
  );
  if (bounds[bounds.length - 1] < durationSec) bounds.push(durationSec);

  const out = new Float32Array(Math.ceil(durationSec * sampleRate));
  for (let bi = 0; bi < bounds.length - 1; bi++) {
    const s = bounds[bi];
    const e = bounds[bi + 1];
    const off = new OfflineAudioContext(1, Math.ceil((e - s) * sampleRate), sampleRate);
    const master = off.createGain();
    master.gain.value = opts.volume ?? MASTER_DEFAULT;
    const wet = off.createGain();
    wet.gain.value = 0.34;
    const rev = makeReverb(off, 3.4, 2.4);
    master.connect(off.destination);
    master.connect(rev);
    rev.connect(wet).connect(off.destination);

    if (opts.drone !== false) {
      const root = 55;
      [root, root * 1.5, root * 2].forEach((f, i) => {
        const o = off.createOscillator();
        o.type = i === 2 ? 'triangle' : 'sine';
        o.frequency.value = f;
        const g = off.createGain();
        g.gain.value = i === 2 ? 0.02 : 0.05;
        const lfo = off.createOscillator();
        lfo.frequency.value = 0.05 + i * 0.017;
        const lg = off.createGain();
        lg.gain.value = 0.02;
        lfo.connect(lg).connect(g.gain);
        o.connect(g).connect(master);
        o.start(0);
        lfo.start(0);
        o.stop(e - s);
        lfo.stop(e - s);
      });
    }

    // t0 = -s : زمانِ آهنگ به زمانِ داخلیِ این سگمنت نگاشت می‌شود
    scheduleAmbientRange(off, master, s, e, -s, opts);
    const buf = await off.startRendering();
    out.set(buf.getChannelData(0), Math.floor(s * sampleRate));
    onProgress?.(e / durationSec);
  }
  return out;
}

/** پخش‌کنندهٔ زندهٔ آمبینت برای پیش‌نمایش در مرورگر */
export class AmbientPlayer {
  private actx: AudioContext | null = null;
  private master: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  private droneNodes: OscillatorNode[] = [];
  private timer: number | null = null;
  private offset = 0;
  private scheduledUpTo = 0;
  private volume: number;
  private enabled: boolean;

  constructor(volume = MASTER_DEFAULT, enabled = true) {
    this.volume = volume;
    this.enabled = enabled;
  }

  getAnalyser(): AnalyserNode | null {
    return this.analyser;
  }

  setVolume(v: number) {
    this.volume = v;
    if (this.master) this.master.gain.value = this.enabled ? v : 0;
  }

  setEnabled(on: boolean) {
    this.enabled = on;
    if (this.master) this.master.gain.value = on ? this.volume : 0;
  }

  private ensureCtx(): AudioContext {
    if (!this.actx) {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.actx = new Ctx();
      this.master = this.actx.createGain();
      this.master.gain.value = this.enabled ? this.volume : 0;
      this.analyser = this.actx.createAnalyser();
      this.analyser.fftSize = 256;
      this.analyser.smoothingTimeConstant = 0.8;
      const wet = this.actx.createGain();
      wet.gain.value = 0.3;
      const rev = makeReverb(this.actx, 3.4, 2.4);
      this.master.connect(this.analyser);
      this.analyser.connect(this.actx.destination);
      this.master.connect(rev);
      rev.connect(wet).connect(this.analyser);
    }
    return this.actx;
  }

  private startDrone() {
    if (!this.actx || !this.master) return;
    this.stopDrone();
    const root = 55;
    [root, root * 1.5, root * 2].forEach((f, i) => {
      const o = this.actx!.createOscillator();
      o.type = i === 2 ? 'triangle' : 'sine';
      o.frequency.value = f;
      const g = this.actx!.createGain();
      g.gain.value = 0.0001;
      g.gain.linearRampToValueAtTime(i === 2 ? 0.02 : 0.05, this.actx!.currentTime + 2.5);
      const lfo = this.actx!.createOscillator();
      lfo.frequency.value = 0.05 + i * 0.017;
      const lg = this.actx!.createGain();
      lg.gain.value = 0.02;
      lfo.connect(lg).connect(g.gain);
      o.connect(g).connect(this.master!);
      o.start();
      lfo.start();
      this.droneNodes.push(o, lfo);
    });
  }

  private stopDrone() {
    this.droneNodes.forEach((n) => {
      try {
        n.stop();
      } catch {
        /* noop */
      }
      n.disconnect();
    });
    this.droneNodes = [];
  }

  start(songTime: number) {
    const actx = this.ensureCtx();
    void actx.resume();
    this.offset = actx.currentTime - songTime;
    this.scheduledUpTo = songTime;
    this.startDrone();
    if (this.master) schedulePadTail(actx, this.master, songTime, this.offset);
    this.master?.gain.cancelScheduledValues(actx.currentTime);
    this.master?.gain.setValueAtTime(this.enabled ? this.volume : 0, actx.currentTime);
    if (this.timer !== null) window.clearInterval(this.timer);
    this.timer = window.setInterval(() => this.tick(), 220);
    this.tick();
  }

  private tick() {
    if (!this.actx || !this.master) return;
    const song = this.actx.currentTime - this.offset;
    const horizon = song + 1.6;
    if (this.scheduledUpTo < horizon) {
      const from = Math.max(0, this.scheduledUpTo);
      scheduleAmbientRange(this.actx, this.master, from, Math.min(DURATION_7MIN, horizon), this.offset, {});
      this.scheduledUpTo = Math.max(this.scheduledUpTo, horizon);
    }
    if (song > DURATION_7MIN + 1) this.stop();
  }

  stop() {
    if (this.timer !== null) {
      window.clearInterval(this.timer);
      this.timer = null;
    }
    this.stopDrone();
  }

  dispose() {
    this.stop();
    this.analyser?.disconnect();
    this.master?.disconnect();
    void this.actx?.close();
    this.actx = null;
    this.master = null;
    this.analyser = null;
  }
}
