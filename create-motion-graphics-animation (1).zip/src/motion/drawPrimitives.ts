/* ------------------------------------------------------------------
   drawPrimitives.ts
   هستهٔ مشترک رسم: easingها، رنگ، هندسهٔ اسلامی، ذرات، تایپوگرافی نورانی
------------------------------------------------------------------ */

export const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const easeOutCubic = (t: number) => 1 - Math.pow(1 - clamp01(t), 3);
export const easeInCubic = (t: number) => Math.pow(clamp01(t), 3);
export const easeInOutCubic = (t: number) => {
  const x = clamp01(t);
  return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
};
export const easeOutQuint = (t: number) => 1 - Math.pow(1 - clamp01(t), 5);
export const easeOutBack = (t: number) => {
  const x = clamp01(t);
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};
export const easeOutElastic = (t: number) => {
  const x = clamp01(t);
  if (x === 0 || x === 1) return x;
  const c4 = (2 * Math.PI) / 3;
  return Math.pow(2, -10 * x) * Math.sin((x * 10 - 0.75) * c4) + 1;
};

export function toFaDigits(input: string | number): string {
  const map = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(input).replace(/\d/g, (d) => map[Number(d)]);
}

export function formatTimeFa(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${toFaDigits(String(m).padStart(2, '0'))}:${toFaDigits(String(r).padStart(2, '0'))}`;
}

export function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  const full =
    clean.length === 3
      ? clean
          .split('')
          .map((c) => c + c)
          .join('')
      : clean;
  const n = parseInt(full, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function lerpColor(hexA: string, hexB: string, t: number): string {
  const [r1, g1, b1] = hexToRgb(hexA);
  const [r2, g2, b2] = hexToRgb(hexB);
  const k = clamp01(t);
  return `rgb(${Math.round(lerp(r1, r2, k))}, ${Math.round(lerp(g1, g2, k))}, ${Math.round(
    lerp(b1, b2, k),
  )})`;
}

export function withAlpha(hex: string, alpha: number): string {
  const [r, g, b] = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${clamp01(alpha)})`;
}

/** deterministic pseudo random — same value for same index on every frame */
export function seeded(i: number): number {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453123;
  return x - Math.floor(x);
}

export function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const rr = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
}

export function drawGlowingText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  font: string,
  fill: string,
  glowColor: string,
  glowBlur = 18,
  align: CanvasTextAlign = 'center',
) {
  ctx.save();
  ctx.font = font;
  ctx.textAlign = align;
  ctx.textBaseline = 'middle';
  ctx.shadowColor = glowColor;
  ctx.shadowBlur = glowBlur;
  ctx.fillStyle = fill;
  ctx.fillText(text, x, y);
  ctx.restore();
}

/** kinetic per-character reveal used for verses & big titles */
export function drawCharReveal(
  ctx: CanvasRenderingContext2D,
  text: string,
  cx: number,
  cy: number,
  font: string,
  fill: string,
  glow: string,
  progress: number,
  align: CanvasTextAlign = 'center',
) {
  const p = clamp01(progress);
  if (p <= 0) return;
  ctx.save();
  ctx.font = font;
  ctx.textAlign = align;
  ctx.textBaseline = 'middle';
  const total = ctx.measureText(text).width;
  let x = align === 'center' ? cx - total / 2 : align === 'right' ? cx : cx - total;
  const chars = Array.from(text);
  chars.forEach((ch, i) => {
    const w = ctx.measureText(ch).width;
    const cp = clamp01((p * (chars.length + 3) - i) / 3);
    if (cp > 0) {
      ctx.save();
      ctx.globalAlpha = cp;
      ctx.shadowColor = glow;
      ctx.shadowBlur = 16 * cp;
      ctx.fillStyle = fill;
      ctx.textAlign = 'left';
      ctx.fillText(ch, x, cy + (1 - easeOutBack(cp)) * 14);
      ctx.restore();
    }
    x += w;
  });
  ctx.restore();
}

/* ------------------------------ geometry ------------------------------ */

export function drawSacredMandala(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  radius: number,
  rot: number,
  color: string,
  alpha: number,
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(rot);
  ctx.strokeStyle = withAlpha(color, alpha);
  ctx.lineWidth = 1.4;

  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(0, 0, radius * 0.84, 0, Math.PI * 2);
  ctx.stroke();

  for (let s = 0; s < 2; s++) {
    ctx.save();
    ctx.rotate((s * Math.PI) / 4);
    const side = radius * 1.18;
    ctx.strokeRect(-side / 2, -side / 2, side, side);
    ctx.restore();
  }

  ctx.beginPath();
  for (let i = 0; i < 12; i++) {
    const a = (i * Math.PI * 2) / 12;
    ctx.moveTo(Math.cos(a) * radius * 0.42, Math.sin(a) * radius * 0.42);
    ctx.lineTo(Math.cos(a) * radius * 0.96, Math.sin(a) * radius * 0.96);
  }
  ctx.stroke();

  ctx.beginPath();
  for (let i = 0; i <= 16; i++) {
    const a = (i * Math.PI * 2) / 16;
    const r = i % 2 === 0 ? radius * 0.42 : radius * 0.24;
    const x = Math.cos(a) * r;
    const y = Math.sin(a) * r;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  ctx.stroke();
  ctx.restore();
}

export function drawCosmicParticles(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  timeSec: number,
  accent: string,
  energy: number,
) {
  for (let i = 0; i < 78; i++) {
    const px = seeded(i * 3 + 1) * w;
    const py = ((seeded(i * 3 + 2) * h - timeSec * (3 + seeded(i) * 9)) % h + h) % h;
    const sz = 0.7 + seeded(i * 5) * 2.2;
    const twinkle = 0.22 + 0.58 * (0.5 + 0.5 * Math.sin(timeSec * (1.1 + seeded(i * 7) * 2.6) + i));
    ctx.fillStyle =
      i % 5 === 0
        ? withAlpha(accent, twinkle * (0.7 + energy * 0.5))
        : `rgba(226, 232, 240, ${twinkle * 0.5})`;
    ctx.beginPath();
    ctx.arc(px, py, sz, 0, Math.PI * 2);
    ctx.fill();
  }
}

export function drawAudioAuraRing(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  baseRadius: number,
  timeSec: number,
  energy: number,
  color: string,
) {
  ctx.save();
  const r = baseRadius + energy * 18;
  const grad = ctx.createRadialGradient(cx, cy, r * 0.2, cx, cy, r * 1.45);
  grad.addColorStop(0, withAlpha(color, 0.24 + energy * 0.16));
  grad.addColorStop(0.6, withAlpha(color, 0.07));
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(cx, cy, r * 1.45, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = withAlpha(color, 0.42 + energy * 0.35);
  ctx.lineWidth = 2;
  ctx.beginPath();
  const pts = 72;
  for (let i = 0; i <= pts; i++) {
    const a = (i / pts) * Math.PI * 2;
    const wave =
      Math.sin(a * 6 + timeSec * 3.5) * (3 + energy * 11) +
      Math.cos(a * 10 - timeSec * 2.2) * (2 + energy * 7);
    const rr = r + wave;
    const x = cx + Math.cos(a) * rr;
    const y = cy + Math.sin(a) * rr;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
  ctx.stroke();
  ctx.restore();
}

/** animated dashed orbit ring with travelling light node */
export function drawOrbitRing(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  rot: number,
  color: string,
  alpha: number,
  node = true,
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(rot);
  ctx.strokeStyle = withAlpha(color, alpha);
  ctx.lineWidth = 1.4;
  ctx.setLineDash([7, 9]);
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.stroke();
  ctx.setLineDash([]);
  if (node) {
    ctx.fillStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.arc(r, 0, 4.5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

export function drawKineticPill(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  label: string,
  progress: number,
  accent: string,
  iconText?: string,
  scaleMult = 1,
  fontSize = 20,
) {
  if (progress <= 0.01) return;
  const s = easeOutBack(clamp01(progress)) * scaleMult;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(s, s);
  ctx.globalAlpha = clamp01(progress * 1.5);

  ctx.font = `700 ${fontSize}px "Vazirmatn", sans-serif`;
  const tw = ctx.measureText(label).width;
  const iconSpace = iconText ? fontSize + 14 : 0;
  const padX = 22;
  const w = tw + padX * 2 + iconSpace;
  const h = fontSize + 24;

  ctx.shadowColor = withAlpha(accent, 0.45);
  ctx.shadowBlur = 18;
  drawRoundedRect(ctx, -w / 2, -h / 2, w, h, h / 2);
  ctx.fillStyle = 'rgba(9, 14, 32, 0.86)';
  ctx.fill();
  ctx.shadowBlur = 0;

  ctx.lineWidth = 1.6;
  ctx.strokeStyle = withAlpha(accent, 0.78);
  ctx.stroke();

  ctx.textBaseline = 'middle';
  ctx.textAlign = 'center';
  if (iconText) {
    ctx.fillStyle = accent;
    ctx.fillText(iconText, w / 2 - 22, 1);
    ctx.fillStyle = '#f8fafc';
    ctx.fillText(label, -12, 1);
  } else {
    ctx.fillStyle = '#f8fafc';
    ctx.fillText(label, 0, 1);
  }
  ctx.restore();
}

export function drawNodeBadge(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  glyph: string,
  color: string,
  progress: number,
) {
  const p = easeOutBack(clamp01(progress));
  if (p <= 0.02) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(p, p);
  ctx.globalAlpha = clamp01(progress * 1.4);
  const g = ctx.createRadialGradient(-r * 0.3, -r * 0.3, r * 0.1, 0, 0, r);
  g.addColorStop(0, withAlpha(color, 0.95));
  g.addColorStop(1, withAlpha(color, 0.35));
  ctx.fillStyle = g;
  ctx.shadowColor = withAlpha(color, 0.7);
  ctx.shadowBlur = 22;
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = 'rgba(255,255,255,0.55)';
  ctx.lineWidth = 1.2;
  ctx.stroke();
  ctx.fillStyle = '#08101f';
  ctx.font = `700 ${Math.round(r * 0.95)}px "Vazirmatn", sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(glyph, 0, 1);
  ctx.restore();
}

export function drawProgressRing(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  progress: number,
  color: string,
  width = 6,
) {
  ctx.save();
  ctx.strokeStyle = withAlpha(color, 0.16);
  ctx.lineWidth = width;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.stroke();
  ctx.strokeStyle = color;
  ctx.shadowColor = withAlpha(color, 0.7);
  ctx.shadowBlur = 16;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * clamp01(progress));
  ctx.stroke();
  ctx.restore();
}

export function drawFlowPulse(
  ctx: CanvasRenderingContext2D,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  t: number,
  color: string,
  energy: number,
) {
  ctx.save();
  ctx.strokeStyle = withAlpha(color, 0.22);
  ctx.lineWidth = 1.6;
  ctx.setLineDash([5, 7]);
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();
  ctx.setLineDash([]);
  const p = (t * 0.55) % 1;
  const x = lerp(x1, x2, p);
  const y = lerp(y1, y2, p);
  ctx.fillStyle = color;
  ctx.shadowColor = color;
  ctx.shadowBlur = 12 + energy * 12;
  ctx.beginPath();
  ctx.arc(x, y, 3.4 + energy * 2, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

export function drawVerseCard(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  verseAr: string,
  verseRef: string | undefined,
  accent: string,
  progress: number,
  maxWidth = 900,
) {
  const p = easeOutCubic(clamp01(progress));
  if (p <= 0.01) return;
  ctx.save();
  ctx.globalAlpha = p;
  ctx.translate(cx, cy + (1 - p) * 22);

  ctx.font = '700 40px "Amiri", serif';
  let textWidth = ctx.measureText(verseAr).width;
  let fontSize = 40;
  if (textWidth > maxWidth) {
    fontSize = Math.max(20, Math.floor((40 * maxWidth) / textWidth));
    ctx.font = `700 ${fontSize}px "Amiri", serif`;
    textWidth = ctx.measureText(verseAr).width;
  }
  const boxH = verseRef ? fontSize + 54 : fontSize + 34;
  const boxW = Math.min(maxWidth + 70, textWidth + 74);

  ctx.shadowColor = withAlpha(accent, 0.4);
  ctx.shadowBlur = 34;
  drawRoundedRect(ctx, -boxW / 2, -boxH / 2, boxW, boxH, 20);
  ctx.fillStyle = 'rgba(6, 10, 24, 0.78)';
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = withAlpha(accent, 0.6);
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#fde68a';
  ctx.shadowColor = withAlpha(accent, 0.8);
  ctx.shadowBlur = 20;
  ctx.fillText(verseAr, 0, verseRef ? -boxH / 2 + fontSize * 0.72 : 0);
  ctx.shadowBlur = 0;

  if (verseRef) {
    ctx.font = '500 16px "Vazirmatn", sans-serif';
    ctx.fillStyle = withAlpha(accent, 0.9);
    ctx.fillText(verseRef, 0, boxH / 2 - 20);
  }
  ctx.restore();
}

export function drawTitleBlock(
  ctx: CanvasRenderingContext2D,
  cx: number,
  y: number,
  title: string,
  subtitle: string,
  accent: string,
  progress: number,
) {
  const p = clamp01(progress);
  if (p <= 0) return;
  ctx.save();
  ctx.globalAlpha = easeOutCubic(p);
  const slide = (1 - easeOutQuint(p)) * 46;
  drawGlowingText(
    ctx,
    title,
    cx + slide,
    y,
    '800 40px "Vazirmatn", sans-serif',
    '#f8fafc',
    withAlpha(accent, 0.55),
    22,
  );
  // accent underline sweeping in from the right (RTL)
  ctx.strokeStyle = accent;
  ctx.lineWidth = 3;
  ctx.lineCap = 'round';
  ctx.shadowColor = withAlpha(accent, 0.8);
  ctx.shadowBlur = 14;
  const lineW = 220 * easeOutCubic(clamp01((p - 0.25) / 0.6));
  ctx.beginPath();
  ctx.moveTo(cx + 110, y + 34);
  ctx.lineTo(cx + 110 - lineW, y + 34);
  ctx.stroke();
  ctx.shadowBlur = 0;
  if (subtitle) {
    ctx.globalAlpha = easeOutCubic(clamp01((p - 0.3) / 0.7)) * 0.95;
    drawGlowingText(
      ctx,
      subtitle,
      cx,
      y + 66,
      '500 20px "Vazirmatn", sans-serif',
      '#cbd5e1',
      'rgba(0,0,0,0)',
      0,
    );
  }
  ctx.restore();
}

/** horizontal audio-reactive bar spectrum (decorative element) */
export function drawSpectrumBars(
  ctx: CanvasRenderingContext2D,
  cx: number,
  baseY: number,
  bars: number,
  width: number,
  timeSec: number,
  energy: number,
  color: string,
  alpha = 0.7,
) {
  const gap = 4;
  const bw = Math.max(2, width / bars - gap);
  ctx.save();
  ctx.globalAlpha = alpha;
  for (let i = 0; i < bars; i++) {
    const x = cx - width / 2 + i * (bw + gap);
    const n =
      0.5 +
      0.5 * Math.sin(timeSec * 2.4 + i * 0.55) * Math.cos(timeSec * 1.3 + i * 0.21);
    const h = 6 + n * (26 + energy * 46) * (0.4 + seeded(i) * 0.9);
    ctx.fillStyle = withAlpha(color, 0.35 + n * 0.5);
    drawRoundedRect(ctx, x, baseY - h, bw, h, bw / 2);
    ctx.fill();
  }
  ctx.restore();
}
