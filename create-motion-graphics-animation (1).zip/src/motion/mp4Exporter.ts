import { ArrayBufferTarget, Muxer } from 'mp4-muxer';
import { renderAmbientOffline } from './ambientScore';
import { drawMotionFrame } from './renderer';
import { DURATION_7MIN, NARRATION_URL, getModeDuration } from './timelineData';
import { drawEp2Frame } from '../motion2/renderer2';
import { EP2_AUDIO_URL, EP2_DURATION } from '../motion2/timeline2';

export type ExportMode = '7min' | 'full';
export type AudioSource = 'ambient' | 'voice' | 'none';

export interface ExportProgress {
  phase: 'preparing' | 'audio_build' | 'encoding_audio' | 'rendering_video' | 'finalizing';
  percent: number;
  currentFrame: number;
  totalFrames: number;
  elapsedSec: number;
  etaSec: number;
  detail: string;
}

export interface ExportResult {
  blob: Blob;
  filename: string;
  sizeBytes: number;
  codecLabel: string;
  mimeType: string;
  width: number;
  height: number;
  fps: number;
  durationSec: number;
}

export interface ExportOptions {
  mode: ExportMode;
  episode?: 'ep1' | 'ep2';
  audioSource: AudioSource;
  resolution: '720p' | '1080p';
  fps: number;
  showSubtitles: boolean;
  showHud: boolean;
  narrationUrl?: string;
  signal?: AbortSignal;
  onProgress?: (p: ExportProgress) => void;
  onPreviewCanvas?: (canvas: HTMLCanvasElement) => void;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export function isWebCodecsSupported(): boolean {
  return (
    typeof VideoEncoder !== 'undefined' &&
    typeof AudioEncoder !== 'undefined' &&
    typeof VideoFrame !== 'undefined' &&
    typeof AudioData !== 'undefined'
  );
}

/** اطمینان از آماده بودن فونت‌های فارسی/عربی پیش از رندر فریم‌ها */
export async function ensureFontsReady(): Promise<void> {
  if (!('fonts' in document)) return;
  const specs = [
    '700 40px "Amiri"',
    '400 40px "Amiri"',
    '300 24px "Vazirmatn"',
    '500 24px "Vazirmatn"',
    '600 24px "Vazirmatn"',
    '700 24px "Vazirmatn"',
    '800 24px "Vazirmatn"',
    '900 24px "Vazirmatn"',
  ];
  try {
    await Promise.all(specs.map((s) => document.fonts.load(s, 'صدّق بالحُسنی')));
    await document.fonts.ready;
  } catch {
    /* noop */
  }
}

async function pickVideoConfig(width: number, height: number, fps: number, quality: number) {
  const candidates: Array<{ webCodec: string; muxCodec: 'avc' | 'vp9'; label: string }> = [
    { webCodec: 'avc1.640028', muxCodec: 'avc', label: 'H.264 High' },
    { webCodec: 'avc1.640032', muxCodec: 'avc', label: 'H.264 High L5.0' },
    { webCodec: 'avc1.4d002a', muxCodec: 'avc', label: 'H.264 Main' },
    { webCodec: 'avc1.42E01F', muxCodec: 'avc', label: 'H.264 Baseline' },
    { webCodec: 'vp09.00.10.08', muxCodec: 'vp9', label: 'VP9' },
  ];
  for (const c of candidates) {
    try {
      const cfg: VideoEncoderConfig = {
        codec: c.webCodec,
        width,
        height,
        framerate: fps,
        bitrate: Math.round((width >= 1920 ? 7_000_000 : 3_400_000) * quality),
        latencyMode: 'quality',
        avc: { format: 'avc' },
      } as VideoEncoderConfig;
      const res = await VideoEncoder.isConfigSupported(cfg);
      if (res.supported) return { ...c, config: cfg };
    } catch {
      /* next */
    }
  }
  return null;
}

async function pickAudioConfig() {
  const candidates: Array<{
    webCodec: string;
    muxCodec: 'aac' | 'opus';
    sampleRate: number;
    numberOfChannels: number;
    bitrate: number;
    label: string;
  }> = [
    { webCodec: 'mp4a.40.2', muxCodec: 'aac', sampleRate: 48000, numberOfChannels: 2, bitrate: 128_000, label: 'AAC-Stereo ۴۸kHz' },
    { webCodec: 'mp4a.40.2', muxCodec: 'aac', sampleRate: 44100, numberOfChannels: 2, bitrate: 128_000, label: 'AAC-Stereo ۴۴.۱kHz' },
    { webCodec: 'opus', muxCodec: 'opus', sampleRate: 48000, numberOfChannels: 2, bitrate: 96_000, label: 'Opus' },
  ];
  for (const c of candidates) {
    try {
      const cfg: AudioEncoderConfig = {
        codec: c.webCodec,
        sampleRate: c.sampleRate,
        numberOfChannels: c.numberOfChannels,
        bitrate: c.bitrate,
      };
      const res = await AudioEncoder.isConfigSupported(cfg);
      if (res.supported) return { ...c, config: cfg };
    } catch {
      /* next */
    }
  }
  return null;
}

/** پاکتِ انرژی ۱۰Hz از PCM برای واکنش‌پذیری بصری به صدا */
function buildEnergyEnvelope(pcm: Float32Array, sampleRate: number, durationSec: number): Float32Array {
  const buckets = Math.ceil(durationSec * 10) + 2;
  const out = new Float32Array(buckets);
  const step = Math.floor(sampleRate / 10);
  for (let b = 0; b < buckets; b++) {
    const start = b * step;
    const end = Math.min(pcm.length, start + step);
    if (end <= start) break;
    let sum = 0;
    for (let i = start; i < end; i++) sum += pcm[i] * pcm[i];
    out[b] = Math.min(1, Math.sqrt(sum / (end - start)) * 3.2);
  }
  return out;
}

function syntheticEnvelope(durationSec: number): Float32Array {
  const buckets = Math.ceil(durationSec * 10) + 2;
  const out = new Float32Array(buckets);
  for (let b = 0; b < buckets; b++) {
    const t = b / 10;
    out[b] = 0.18 + 0.12 * Math.sin(t * 1.7) + 0.08 * Math.sin(t * 4.3);
  }
  return out;
}

async function decodeNarration(url: string, durationSec: number, sampleRate: number): Promise<Float32Array> {
  const resp = await fetch(url);
  if (!resp.ok) throw new Error('دریافت فایل صوتی روایت ناموفق بود (HTTP ' + resp.status + ').');
  const bytes = await resp.arrayBuffer();
  const tmp = new AudioContext();
  let decoded: AudioBuffer;
  try {
    decoded = await tmp.decodeAudioData(bytes.slice(0));
  } finally {
    await tmp.close();
  }
  const len = Math.ceil(durationSec * sampleRate);
  if (decoded.sampleRate === sampleRate && decoded.numberOfChannels === 1 && decoded.length >= len) {
    return decoded.getChannelData(0).slice(0, len);
  }
  const off = new OfflineAudioContext(1, len, sampleRate);
  const src = off.createBufferSource();
  src.buffer = decoded;
  src.connect(off.destination);
  src.start(0);
  const rendered = await off.startRendering();
  return rendered.getChannelData(0).slice(0, len);
}

export async function exportMotionToMp4(opts: ExportOptions): Promise<ExportResult> {
  if (!isWebCodecsSupported()) {
    throw new Error(
      'این مرورگر از WebCodecs پشتیبانی نمی‌کند. برای ساخت MP4 از Chrome/Edge جدید استفاده کنید یا «ضبط زنده» را امتحان کنید.',
    );
  }

  const fps = Math.max(12, Math.min(60, Math.round(opts.fps)));
  const width = opts.resolution === '1080p' ? 1920 : 1280;
  const height = opts.resolution === '1080p' ? 1080 : 720;
  const isEp2 = opts.episode === 'ep2';
  const totalDur = isEp2 ? EP2_DURATION : getModeDuration(opts.mode);
  const totalFrames = Math.round(totalDur * fps);
  const t0 = performance.now();
  const report = (p: Omit<ExportProgress, 'elapsedSec' | 'etaSec'>, eta = 0) =>
    opts.onProgress?.({ ...p, elapsedSec: (performance.now() - t0) / 1000, etaSec: eta });

  report({ phase: 'preparing', percent: 1, currentFrame: 0, totalFrames, detail: 'آماده‌سازی فونت‌ها و کدک‌ها…' });
  await ensureFontsReady();

  const video = await pickVideoConfig(width, height, fps, 1);
  if (!video) throw new Error('کدک ویدیویی سازگار (H.264/VP9) در این مرورگر پیدا نشد.');
  const audio = await pickAudioConfig();
  if (!audio) throw new Error('کدک صوتی سازگار (AAC/Opus) در این مرورگر پیدا نشد.');

  /* ---------- ۱. ساخت PCM صدا ---------- */
  report({ phase: 'audio_build', percent: 4, currentFrame: 0, totalFrames, detail: 'ساخت باند صوتی…' });
  let pcm: Float32Array;
  if (opts.audioSource === 'voice') {
    pcm = await decodeNarration(opts.narrationUrl || (isEp2 ? EP2_AUDIO_URL : NARRATION_URL), totalDur, audio.sampleRate);
  } else if (opts.audioSource === 'ambient') {
    pcm = await renderAmbientOffline(totalDur, audio.sampleRate, { volume: 0.55 }, (p) =>
      report({
        phase: 'audio_build',
        percent: 4 + p * 10,
        currentFrame: 0,
        totalFrames,
        detail: 'رندر موسیقی متنِ سینمایی… ' + Math.round(p * 100) + '٪',
      }),
    );
  } else {
    pcm = new Float32Array(Math.ceil(totalDur * audio.sampleRate));
  }
  const envelope =
    opts.audioSource === 'none' ? syntheticEnvelope(totalDur) : buildEnergyEnvelope(pcm, audio.sampleRate, totalDur);

  /* ---------- ۲. راه‌اندازی ماکسر ---------- */
  const target = new ArrayBufferTarget();
  const muxer = new Muxer({
    target,
    video: { codec: video.muxCodec, width, height, frameRate: fps },
    audio: { codec: audio.muxCodec, numberOfChannels: audio.numberOfChannels, sampleRate: audio.sampleRate },
    fastStart: 'in-memory',
    firstTimestampBehavior: 'offset',
  });

  let encError: Error | null = null;
  const onErr = (e: DOMException | Error) => {
    encError = e instanceof Error ? e : new Error(String(e));
  };

  const videoEncoder = new VideoEncoder({ output: (chunk, meta) => muxer.addVideoChunk(chunk, meta), error: onErr });
  videoEncoder.configure(video.config);
  const audioEncoder = new AudioEncoder({ output: (chunk, meta) => muxer.addAudioChunk(chunk, meta), error: onErr });
  audioEncoder.configure(audio.config);

  const abortIfAsked = () => {
    if (opts.signal?.aborted) {
      try {
        videoEncoder.close();
        audioEncoder.close();
      } catch {
        /* noop */
      }
      throw new DOMException('ساخت ویدیو لغو شد.', 'AbortError');
    }
    if (encError) throw encError;
  };

  /* ---------- ۳. رمزگذاری صدا ---------- */
  report({
    phase: 'encoding_audio',
    percent: 16,
    currentFrame: 0,
    totalFrames,
    detail: `رمزگذاری صدا با ${audio.label}…`,
  });
  const chunkFrames = 1024;
  const totalSamples = pcm.length;
  for (let offset = 0; offset < totalSamples; offset += chunkFrames) {
    abortIfAsked();
    const count = Math.min(chunkFrames, totalSamples - offset);
    const planar = new Float32Array(count * audio.numberOfChannels);
    for (let ch = 0; ch < audio.numberOfChannels; ch++) {
      planar.set(pcm.subarray(offset, offset + count), ch * count);
    }
    const data = new AudioData({
      format: 'f32-planar',
      sampleRate: audio.sampleRate,
      numberOfFrames: count,
      numberOfChannels: audio.numberOfChannels,
      timestamp: Math.round((offset / audio.sampleRate) * 1_000_000),
      data: planar,
    });
    audioEncoder.encode(data);
    data.close();
    while (audioEncoder.encodeQueueSize > 20) await sleep(2);
    if (offset % (chunkFrames * 400) === 0) {
      report({
        phase: 'encoding_audio',
        percent: 16 + (offset / totalSamples) * 9,
        currentFrame: 0,
        totalFrames,
        detail: `رمزگذاری صدا… ${Math.round((offset / totalSamples) * 100)}٪`,
      });
    }
  }
  while (audioEncoder.encodeQueueSize > 0) await sleep(4);
  pcm = new Float32Array(0); // آزادسازی حافظه پیش از رندر ویدیو

  /* ---------- ۴. رندر و رمزگذاری فریم‌ها ---------- */
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { alpha: false, desynchronized: false });
  if (!ctx) throw new Error('ایجاد بوم Canvas2D ممکن نشد.');

  let lastReport = performance.now();
  for (let i = 0; i < totalFrames; i++) {
    abortIfAsked();
    const timeSec = i / fps;
    const energy = envelope[Math.min(envelope.length - 1, Math.floor(timeSec * 10))] ?? 0.2;
    if (isEp2) {
      drawEp2Frame(ctx, timeSec, width, height, energy, { showSubtitles: opts.showSubtitles, showHud: opts.showHud });
    } else {
      drawMotionFrame(ctx, timeSec, width, height, energy, {
        mode: opts.mode,
        showSubtitles: opts.showSubtitles,
        showHud: opts.showHud,
        totalDur,
      });
    }

    const frame = new VideoFrame(canvas, {
      timestamp: Math.round((i * 1_000_000) / fps),
      duration: Math.round(1_000_000 / fps),
    });
    videoEncoder.encode(frame, { keyFrame: i % (fps * 2) === 0 });
    frame.close();

    while (videoEncoder.encodeQueueSize > 8) await sleep(3);
    if (i % 6 === 0) await sleep(0);

    const now = performance.now();
    if (now - lastReport > 180) {
      lastReport = now;
      const elapsed = (now - t0) / 1000;
      const pct = 25 + (i / totalFrames) * 70;
      const speed = i / Math.max(0.001, elapsed);
      const eta = speed > 0 ? (totalFrames - i) / speed : 0;
      opts.onPreviewCanvas?.(canvas);
      report(
        {
          phase: 'rendering_video',
          percent: pct,
          currentFrame: i,
          totalFrames,
          detail: `رندر فریم ${i} از ${totalFrames} • ${speed.toFixed(1)} فریم/ثانیه`,
        },
        eta,
      );
    }
  }

  report({ phase: 'finalizing', percent: 96, currentFrame: totalFrames, totalFrames, detail: 'پایانِ رمزگذاری و ساخت MP4…' });
  while (videoEncoder.encodeQueueSize > 0 || audioEncoder.encodeQueueSize > 0) await sleep(6);
  try {
    await videoEncoder.flush();
    await audioEncoder.flush();
  } catch {
    /* noop */
  }
  videoEncoder.close();
  audioEncoder.close();
  muxer.finalize();

  const buf = target.buffer;
  const blob = new Blob([buf], { type: video.muxCodec === 'avc' ? 'video/mp4' : 'video/webm' });
  const name = isEp2
    ? `motion-graphic-tasleem-${opts.resolution}.mp4`
    : opts.mode === '7min'
      ? `motion-graphic-saddeq-bel-hosna-7min-${opts.resolution}.mp4`
      : `motion-graphic-saddeq-bel-hosna-full-${opts.resolution}.mp4`;

  report({ phase: 'finalizing', percent: 100, currentFrame: totalFrames, totalFrames, detail: 'آمادهٔ دانلود و آپلود.' });

  return {
    blob,
    filename: name,
    sizeBytes: blob.size,
    codecLabel: `${video.label} + ${audio.label}`,
    mimeType: blob.type,
    width,
    height,
    fps,
    durationSec: totalDur,
  };
}

/* ------------------------------------------------------------------
   ضبط زنده (fallback برای مرورگرهای بدون WebCodecs)
------------------------------------------------------------------ */
export interface LiveRecordHandle {
  stop: () => void;
}

export function liveRecordSupportedMime(): string | null {
  if (typeof MediaRecorder === 'undefined') return null;
  const list = [
    'video/mp4;codecs=avc1.42E01F,mp4a.40.2',
    'video/mp4',
    'video/webm;codecs=vp9,opus',
    'video/webm;codecs=vp8,opus',
    'video/webm',
  ];
  for (const m of list) {
    try {
      if (MediaRecorder.isTypeSupported(m)) return m;
    } catch {
      /* next */
    }
  }
  return null;
}

/** ضبط بلادرنگِ بوم + صدا؛ خروجی webm/mp4 بسته به مرورگر */
export function startLiveRecording(opts: {
  canvas: HTMLCanvasElement;
  audioStream: MediaStream | null;
  mimeType: string;
  fps: number;
  onChunk?: (sizeBytes: number) => void;
}): { recorder: MediaRecorder; stop: () => Promise<Blob> } {
  const canvasStream = opts.canvas.captureStream(opts.fps);
  const tracks = [...canvasStream.getVideoTracks()];
  if (opts.audioStream) tracks.push(...opts.audioStream.getAudioTracks());
  const stream = new MediaStream(tracks);
  const recorder = new MediaRecorder(stream, {
    mimeType: opts.mimeType,
    videoBitsPerSecond: opts.canvas.width >= 1920 ? 7_000_000 : 3_600_000,
    audioBitsPerSecond: 128_000,
  });
  const chunks: BlobPart[] = [];
  recorder.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) {
      chunks.push(e.data);
      opts.onChunk?.(e.data.size);
    }
  };
  recorder.start(1000);
  const stop = () =>
    new Promise<Blob>((resolve) => {
      recorder.onstop = () => resolve(new Blob(chunks, { type: opts.mimeType.split(';')[0] }));
      recorder.stop();
    });
  return { recorder, stop };
}

export { DURATION_7MIN };
