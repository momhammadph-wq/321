import {
  clamp01,
  drawCosmicParticles,
  drawGlowingText,
  drawRoundedRect,
  drawSacredMandala,
  drawSpectrumBars,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  formatTimeFa,
  lerpColor,
  toFaDigits,
  withAlpha,
} from './drawPrimitives';
import {
  drawSceneCityAbundance,
  drawSceneCosmosTasbih,
  drawSceneDawnTasdiq,
  drawSceneMindGate,
} from './scenesPart1';
import {
  drawSceneBodyAnfus,
  drawSceneMindGym,
  drawSceneSevenSeas,
  drawSceneTenMinutes,
} from './scenesPart2';
import {
  drawSceneCinemaGhayb,
  drawSceneFasanuyassir,
  drawSceneSeedSigns,
  drawSceneStepGuidance,
} from './scenesPart3';
import {
  DURATION_7MIN,
  getCaptionAtTime,
  getChapterAtTime,
  MOTION_CHAPTERS,
  resolveVisualTime,
  type MotionChapter,
  type SceneKey,
} from './timelineData';

export const VIRTUAL_W = 1280;
export const VIRTUAL_H = 720;

export interface RenderOptions {
  mode: '7min' | 'full';
  showSubtitles: boolean;
  showHud: boolean;
  totalDur: number;
}

const SCENES: Record<SceneKey, (ctx: CanvasRenderingContext2D, t: number, g: number, e: number, a: string, b: string) => void> = {
  dawn_tasdiq: drawSceneDawnTasdiq,
  mind_gate: drawSceneMindGate,
  city_abundance: drawSceneCityAbundance,
  cosmos_tasbih: drawSceneCosmosTasbih,
  seven_seas: drawSceneSevenSeas,
  body_anfus: drawSceneBodyAnfus,
  mind_gym: drawSceneMindGym,
  ten_minutes: drawSceneTenMinutes,
  cinema_ghayb: drawSceneCinemaGhayb,
  step_guidance: drawSceneStepGuidance,
  fasanuyassir: drawSceneFasanuyassir,
  seed_signs: drawSceneSeedSigns,
};

function wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  const words = text.split(' ');
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    const test = cur ? `${cur} ${w}` : w;
    if (ctx.measureText(test).width <= maxWidth) cur = test;
    else {
      if (cur) lines.push(cur);
      cur = w;
    }
  }
  if (cur) lines.push(cur);
  return lines.slice(0, 2);
}

/**
 * یک فریم کاملِ موشن گرافیک را روی بوم می‌کشد.
 * @param timeSec زمانِ پخش (در حالت full = زمان روایت)
 */
export function drawMotionFrame(
  ctx: CanvasRenderingContext2D,
  timeSec: number,
  pixelWidth: number,
  pixelHeight: number,
  audioEnergy: number,
  options: RenderOptions,
) {
  const visualT = resolveVisualTime(timeSec, options.mode);
  const totalDur = options.totalDur;
  const chapter: MotionChapter = getChapterAtTime(visualT);
  const chIdx = MOTION_CHAPTERS.findIndex((c) => c.id === chapter.id);
  const nextChapter = MOTION_CHAPTERS[Math.min(MOTION_CHAPTERS.length - 1, chIdx + 1)];
  const timeToEnd = chapter.end - visualT;
  const blend =
    timeToEnd < 1.8 && nextChapter.id !== chapter.id ? easeInOutCubic(1 - timeToEnd / 1.8) : 0;
  const bgTop = lerpColor(chapter.bgTop, nextChapter.bgTop, blend);
  const bgBottom = lerpColor(chapter.bgBottom, nextChapter.bgBottom, blend);
  const accent = blend > 0.5 ? nextChapter.accent : chapter.accent;
  const accent2 = blend > 0.5 ? nextChapter.accentSecondary : chapter.accentSecondary;

  ctx.save();
  ctx.scale(pixelWidth / VIRTUAL_W, pixelHeight / VIRTUAL_H);
  if ('direction' in ctx) ctx.direction = 'rtl';

  /* ۱ — پس‌زمینهٔ ژرف */
  const bg = ctx.createLinearGradient(0, 0, 0, VIRTUAL_H);
  bg.addColorStop(0, bgTop);
  bg.addColorStop(1, bgBottom);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);

  const radial = ctx.createRadialGradient(640, 340, 40, 640, 340, 780);
  radial.addColorStop(0, withAlpha(accent, 0.13 + audioEnergy * 0.09));
  radial.addColorStop(1, 'rgba(3, 6, 18, 0.68)');
  ctx.fillStyle = radial;
  ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);

  /* ۲ — هندسهٔ چرخان و غبار */
  drawSacredMandala(ctx, 640, 352, 316, visualT * 0.042, accent, 0.07);
  drawSacredMandala(ctx, 640, 352, 214, -visualT * 0.058, accent2, 0.06);
  drawCosmicParticles(ctx, VIRTUAL_W, VIRTUAL_H, visualT, accent, audioEnergy);

  /* ۳ — صحنهٔ المان‌محور */
  const localT = visualT - chapter.start;
  const fadeIn = clamp01(localT / 0.7);
  const fadeOut = timeToEnd < 0.55 && nextChapter.id !== chapter.id ? clamp01(timeToEnd / 0.55) : 1;
  ctx.save();
  ctx.globalAlpha = Math.min(fadeIn, fadeOut);
  const draw = SCENES[chapter.sceneKey];
  if (draw) draw(ctx, Math.max(0, localT), visualT, audioEnergy, chapter.accent, chapter.accentSecondary);
  ctx.restore();

  /* ۴ — وینیت */
  const vig = ctx.createRadialGradient(640, 360, 260, 640, 360, 820);
  vig.addColorStop(0, 'rgba(0,0,0,0)');
  vig.addColorStop(1, 'rgba(2, 4, 12, 0.72)');
  ctx.fillStyle = vig;
  ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);

  /* ۵ — کارتِ آغازین */
  if (visualT < 3.0) {
    const alpha = visualT < 2.1 ? 1 : 1 - clamp01((visualT - 2.1) / 0.9);
    const pop = easeOutBack(clamp01(visualT / 0.7));
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = 'rgba(5, 8, 18, 0.74)';
    ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);
    ctx.translate(640, 330);
    ctx.scale(pop, pop);
    drawSacredMandala(ctx, 0, 6, 200, visualT * 0.5, '#fbbf24', 0.18);
    drawGlowingText(
      ctx,
      'صَدَّقَ بِالْحُسْنَىٰ',
      0,
      -54,
      '700 74px "Amiri", serif',
      '#fde68a',
      'rgba(251, 191, 36, 0.7)',
      30,
    );
    drawGlowingText(
      ctx,
      'موشن گرافیکِ المان‌محور • ۷ دقیقه • ۱۲ فصل',
      0,
      26,
      '700 24px "Vazirmatn", sans-serif',
      '#e2e8f0',
      'rgba(56, 189, 248, 0.4)',
      12,
    );
    drawGlowingText(
      ctx,
      'تصدیقِ نیکی‌ها و به تصویر کشیدنِ غیب',
      0,
      74,
      '500 19px "Vazirmatn", sans-serif',
      '#94a3b8',
      'rgba(0,0,0,0)',
      0,
    );
    ctx.restore();
  }

  /* ۶ — تیتراژِ پایانی */
  if (visualT > 407) {
    const cp = easeOutCubic(clamp01((visualT - 407) / 2.4));
    ctx.save();
    ctx.globalAlpha = cp * 0.96;
    ctx.fillStyle = 'rgba(4, 8, 18, 0.86)';
    ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);
    drawSacredMandala(ctx, 640, 316, 224, visualT * 0.14, '#fbbf24', 0.22);
    drawSacredMandala(ctx, 640, 316, 148, -visualT * 0.2, '#4ade80', 0.18);
    const crestVerse = 'وَصَدَّقَ بِالْحُسْنَىٰ ۝ فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ';
    let crestFont = 46;
    ctx.font = `700 ${crestFont}px "Amiri", serif`;
    while (ctx.measureText(crestVerse).width > 1040 && crestFont > 24) {
      crestFont -= 2;
      ctx.font = `700 ${crestFont}px "Amiri", serif`;
    }
    drawGlowingText(
      ctx,
      crestVerse,
      640,
      288,
      `700 ${crestFont}px "Amiri", serif`,
      '#fde68a',
      'rgba(251, 191, 36, 0.65)',
      26,
    );
    drawGlowingText(
      ctx,
      'هر روز با چشمِ بینندهٔ فراوانی آغاز کن',
      640,
      366,
      '700 27px "Vazirmatn", sans-serif',
      '#4ade80',
      'rgba(74, 222, 128, 0.45)',
      16,
    );
    drawGlowingText(
      ctx,
      'موشن گرافیکِ المان‌محور • ساخته‌شده در مرورگر با WebCodecs',
      640,
      424,
      '500 17px "Vazirmatn", sans-serif',
      '#94a3b8',
      'rgba(0,0,0,0)',
      0,
    );
    ctx.restore();
  }

  /* ۷ — HUD بالا */
  if (options.showHud) {
    const topBar = ctx.createLinearGradient(0, 0, 0, 84);
    topBar.addColorStop(0, 'rgba(4, 7, 18, 0.82)');
    topBar.addColorStop(1, 'rgba(4, 7, 18, 0)');
    ctx.fillStyle = topBar;
    ctx.fillRect(0, 0, VIRTUAL_W, 84);

    ctx.save();
    ctx.font = '700 16px "Vazirmatn", sans-serif';
    const badgeLabel = `${chapter.badge}  •  ${chapter.title}`;
    const bw = Math.min(660, ctx.measureText(badgeLabel).width + 48);
    drawRoundedRect(ctx, VIRTUAL_W - bw - 32, 20, bw, 40, 20);
    ctx.fillStyle = 'rgba(10, 16, 34, 0.8)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(chapter.accent, 0.62);
    ctx.lineWidth = 1.4;
    ctx.stroke();
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = chapter.accent;
    ctx.beginPath();
    ctx.arc(VIRTUAL_W - 50, 40, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#f1f5f9';
    ctx.fillText(badgeLabel, VIRTUAL_W - 66, 41);
    ctx.restore();

    ctx.save();
    drawRoundedRect(ctx, 32, 20, 172, 40, 20);
    ctx.fillStyle = 'rgba(10, 16, 34, 0.8)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.32)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.font = '700 15px "Vazirmatn", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#e2e8f0';
    ctx.fillText(`${formatTimeFa(timeSec)} / ${formatTimeFa(totalDur)}`, 118, 41);
    ctx.restore();

    drawSpectrumBars(ctx, 330, 60, 26, 190, visualT, audioEnergy, chapter.accent, 0.5);

    // نوارِ پیشرفت با تقسیمِ فصل‌ها
    const pct = clamp01(timeSec / totalDur);
    ctx.fillStyle = 'rgba(255,255,255,0.09)';
    ctx.fillRect(0, 0, VIRTUAL_W, 5);
    const barG = ctx.createLinearGradient(VIRTUAL_W, 0, 0, 0);
    barG.addColorStop(0, chapter.accent);
    barG.addColorStop(1, chapter.accentSecondary);
    ctx.fillStyle = barG;
    ctx.fillRect(VIRTUAL_W * (1 - pct), 0, VIRTUAL_W * pct, 5);
    MOTION_CHAPTERS.forEach((c) => {
      const x = VIRTUAL_W * (1 - c.start / DURATION_7MIN);
      ctx.fillStyle = 'rgba(2, 6, 16, 0.85)';
      ctx.fillRect(x - 1, 0, 2, 5);
    });
    ctx.font = '600 13px "Vazirmatn", sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(203, 213, 225, 0.75)';
    ctx.fillText(`فصل ${toFaDigits(chapter.id)} از ۱۲`, 32, 76);
  }

  /* ۸ — کپسولِ زیرنویس */
  if (options.showSubtitles) {
    const cue = getCaptionAtTime(visualT);
    if (cue) {
      const cueP = clamp01((visualT - cue.start) / 0.45);
      ctx.save();
      ctx.globalAlpha = easeOutCubic(cueP);
      ctx.translate(0, (1 - easeOutCubic(cueP)) * 18);
      ctx.font = '600 23px "Vazirmatn", sans-serif';
      const lines = wrapText(ctx, cue.text, 940);
      const boxH = lines.length === 2 ? 82 : 54;
      const boxY = VIRTUAL_H - boxH - 24;
      const boxW = Math.min(1060, Math.max(...lines.map((l) => ctx.measureText(l).width)) + 78);
      const boxX = (VIRTUAL_W - boxW) / 2;

      drawRoundedRect(ctx, boxX, boxY, boxW, boxH, 20);
      ctx.fillStyle = 'rgba(5, 9, 22, 0.86)';
      ctx.fill();
      ctx.strokeStyle = withAlpha(chapter.accent, 0.5);
      ctx.lineWidth = 1.4;
      ctx.stroke();
      ctx.fillStyle = chapter.accent;
      ctx.fillRect(boxX + boxW - 4, boxY + 12, 4, boxH - 24);

      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.shadowColor = 'rgba(0,0,0,0.65)';
      ctx.shadowBlur = 10;
      ctx.fillStyle = cue.highlight ? '#fde68a' : '#f8fafc';
      if (lines.length === 1) ctx.fillText(lines[0], 640, boxY + boxH / 2 + 1);
      else {
        ctx.fillText(lines[0], 640, boxY + 25);
        ctx.fillText(lines[1], 640, boxY + 57);
      }
      ctx.restore();
    }
  }

  ctx.restore();
}

/** فریمِ بندانگشتی یک فصل برای ریلِ فصل‌ها */
export function drawChapterThumb(
  ctx: CanvasRenderingContext2D,
  chapter: MotionChapter,
  w: number,
  h: number,
) {
  const t = chapter.start + (chapter.end - chapter.start) * 0.45;
  ctx.save();
  ctx.clearRect(0, 0, w, h);
  drawMotionFrame(ctx, t, w, h, 0.18, {
    mode: '7min',
    showSubtitles: false,
    showHud: false,
    totalDur: DURATION_7MIN,
  });
  ctx.restore();
}
