import {
  clamp01,
  drawAudioAuraRing,
  drawGlowingText,
  drawKineticPill,
  drawNodeBadge,
  drawOrbitRing,
  drawProgressRing,
  drawRoundedRect,
  drawVerseCard,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  easeOutQuint,
  lerp,
  seeded,
  toFaDigits,
  withAlpha,
} from './drawPrimitives';

export type SceneDraw = (
  ctx: CanvasRenderingContext2D,
  t: number,
  g: number,
  energy: number,
  accent: string,
  accent2: string,
) => void;

/* ══════════════════════════════════════════════════════════════════
   فصل ۱ — طلوعِ تصدیق (۰..۳۲)
   ══════════════════════════════════════════════════════════════════ */
export const drawSceneDawnTasdiq: SceneDraw = (ctx, t, g, energy, accent) => {
  const cx = 640;
  const rise = easeOutCubic(clamp01((t - 0.6) / 7));
  const sunY = lerp(540, 300, rise);
  const sunR = 76 + energy * 9;

  const dawn = ctx.createRadialGradient(cx, sunY, 10, cx, sunY, 400);
  dawn.addColorStop(0, 'rgba(251, 191, 36, 0.34)');
  dawn.addColorStop(0.5, 'rgba(251, 146, 60, 0.13)');
  dawn.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = dawn;
  ctx.beginPath();
  ctx.arc(cx, sunY, 400, 0, Math.PI * 2);
  ctx.fill();

  // پرتوهای چرخان
  ctx.save();
  ctx.translate(cx, sunY);
  ctx.rotate(g * 0.16);
  for (let i = 0; i < 18; i++) {
    ctx.save();
    ctx.rotate((i * Math.PI * 2) / 18);
    const len = 130 + Math.sin(g * 2 + i) * 20 + energy * 34;
    const gr = ctx.createLinearGradient(sunR, 0, sunR + len, 0);
    gr.addColorStop(0, 'rgba(253, 224, 71, 0.46)');
    gr.addColorStop(1, 'rgba(253, 224, 71, 0)');
    ctx.fillStyle = gr;
    ctx.beginPath();
    ctx.moveTo(sunR * 0.84, -7);
    ctx.lineTo(sunR + len, 0);
    ctx.lineTo(sunR * 0.84, 7);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }
  ctx.restore();

  drawAudioAuraRing(ctx, cx, sunY, sunR + 16, g, energy, accent);
  const orb = ctx.createRadialGradient(cx - 18, sunY - 22, 8, cx, sunY, sunR);
  orb.addColorStop(0, '#fef9c3');
  orb.addColorStop(0.55, '#fbbf24');
  orb.addColorStop(1, '#ea580c');
  ctx.fillStyle = orb;
  ctx.beginPath();
  ctx.arc(cx, sunY, sunR, 0, Math.PI * 2);
  ctx.fill();

  drawVerseCard(ctx, cx, sunY - 4, 'وَصَدَّقَ بِالْحُسْنَىٰ', undefined, accent, clamp01((t - 1) / 1.6), 520);

  // تپه‌های سپیده‌دم
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(90, 570);
  ctx.quadraticCurveTo(360, 462, 640, 520);
  ctx.quadraticCurveTo(930, 578, 1190, 486);
  ctx.lineTo(1190, 580);
  ctx.lineTo(90, 580);
  ctx.closePath();
  const hill = ctx.createLinearGradient(0, 470, 0, 580);
  hill.addColorStop(0, 'rgba(32, 42, 86, 0.94)');
  hill.addColorStop(1, 'rgba(12, 17, 40, 0.97)');
  ctx.fillStyle = hill;
  ctx.fill();
  ctx.strokeStyle = withAlpha(accent, 0.34);
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();

  // پرندگان
  for (let i = 0; i < 5; i++) {
    const bp = clamp01((t - 6 - i * 0.7) / 8);
    if (bp <= 0) continue;
    const bx = lerp(1180, 180, bp) + seeded(i) * 30;
    const by = 190 + seeded(i * 5) * 90 + Math.sin(g * 3 + i) * 9;
    const flap = Math.sin(g * 7 + i * 2) * 5;
    ctx.strokeStyle = `rgba(226, 232, 240, ${0.5 * (1 - bp * 0.4)})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(bx - 9, by + flap);
    ctx.quadraticCurveTo(bx, by - 4, bx + 9, by + flap);
    ctx.stroke();
  }

  const pills = [
    { x: 268, y: 236, label: 'تصدیقِ نیکی‌ها', icon: '✓', at: 3.0, color: '#fbbf24' },
    { x: 1012, y: 236, label: 'دیدنِ خوبی‌ها', icon: '✦', at: 7.5, color: '#fde047' },
    { x: 214, y: 372, label: 'فراوانیِ هستی', icon: '◈', at: 11.5, color: '#fb923c' },
    { x: 1066, y: 372, label: 'شکرِ داشته‌ها', icon: '♥', at: 15.0, color: '#34d399' },
    { x: 320, y: 486, label: 'شکرِ اولِ صبح', icon: '☀', at: 19.0, color: '#fbbf24' },
    { x: 960, y: 486, label: 'یادِ خدا در روز', icon: '☼', at: 23.0, color: '#38bdf8' },
  ];
  for (const p of pills) {
    const pr = clamp01((t - p.at) / 0.9);
    if (pr <= 0) continue;
    const fy = Math.sin(g * 2 + p.x * 0.01) * 5;
    ctx.save();
    ctx.strokeStyle = withAlpha(p.color, 0.3 * pr);
    ctx.lineWidth = 1.5;
    ctx.setLineDash([5, 7]);
    ctx.beginPath();
    ctx.moveTo(cx, sunY);
    ctx.lineTo(p.x, p.y + fy);
    ctx.stroke();
    ctx.restore();
    drawKineticPill(ctx, p.x, p.y + fy, p.label, pr, p.color, p.icon);
  }

  // کمانِ گردشِ روز
  if (t > 20) {
    const ap = easeInOutCubic((t - 20) / 11);
    ctx.save();
    ctx.strokeStyle = withAlpha(accent, 0.3);
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.arc(cx, 520, 400, Math.PI * 1.14, Math.PI * (1.14 + 0.72 * ap));
    ctx.stroke();
    const ang = Math.PI * (1.14 + 0.72 * ap);
    const dx = cx + Math.cos(ang) * 400;
    const dy = 520 + Math.sin(ang) * 400;
    ctx.fillStyle = '#fde047';
    ctx.shadowColor = accent;
    ctx.shadowBlur = 18;
    ctx.beginPath();
    ctx.arc(dx, dy, 7 + energy * 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
};

/* ══════════════════════════════════════════════════════════════════
   فصل ۲ — دروازهٔ ذهن (۳۲..۶۲)
   ══════════════════════════════════════════════════════════════════ */
export const drawSceneMindGate: SceneDraw = (ctx, t, g, energy, accent, accent2) => {
  const phase = easeInOutCubic(clamp01((t - 17) / 2.4));
  const cx = 640;

  if (phase < 0.995) {
    ctx.save();
    ctx.globalAlpha = 1 - phase;
    ctx.translate(phase * -70, 0);

    // منشورِ ورودی
    const px = 620;
    const py = 330;
    const pr = 96;
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(Math.sin(g * 0.5) * 0.06);
    const grd = ctx.createLinearGradient(-pr, -pr, pr, pr);
    grd.addColorStop(0, 'rgba(56, 189, 248, 0.30)');
    grd.addColorStop(1, 'rgba(148, 163, 184, 0.10)');
    ctx.fillStyle = grd;
    ctx.strokeStyle = withAlpha(accent, 0.85);
    ctx.lineWidth = 2.2;
    ctx.shadowColor = withAlpha(accent, 0.55);
    ctx.shadowBlur = 26;
    ctx.beginPath();
    ctx.moveTo(0, -pr);
    ctx.lineTo(pr * 0.94, pr * 0.72);
    ctx.lineTo(-pr * 0.94, pr * 0.72);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
    ctx.restore();

    drawGlowingText(
      ctx,
      'ورودیِ ذهن',
      px,
      py + 128,
      '800 26px "Vazirmatn", sans-serif',
      '#f8fafc',
      withAlpha(accent, 0.6),
      16,
    );

    // پرتوهای ورودی از راست
    const inputs = ['خبر', 'تصویر', 'کلامِ مردم', 'عدد و رقم', 'حسِ درون'];
    inputs.forEach((label, i) => {
      const appear = clamp01((t - 1.4 - i * 1.5) / 0.9);
      if (appear <= 0) return;
      const y = 180 + i * 74;
      const travel = easeOutCubic(appear);
      const startX = 1234;
      const ex = lerp(startX, px + 92, travel);
      ctx.save();
      ctx.globalAlpha = appear;
      const lg = ctx.createLinearGradient(startX, y, ex, y);
      lg.addColorStop(0, 'rgba(148, 163, 184, 0.05)');
      lg.addColorStop(1, withAlpha(accent, 0.65 + energy * 0.3));
      ctx.strokeStyle = lg;
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(startX, y);
      ctx.lineTo(ex, y);
      ctx.stroke();
      ctx.fillStyle = accent2;
      ctx.shadowColor = accent2;
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.arc(ex, y, 4 + energy * 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.font = '600 17px "Vazirmatn", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#cbd5e1';
      ctx.fillText(label, 1176, y - 24);
      ctx.restore();
    });

    // خروجی‌ها: تصدیق (بالا) و تکذیب (پایین)
    const outP = clamp01((t - 9) / 1.6);
    if (outP > 0) {
      const goodX = lerp(px, 1030, easeOutQuint(outP));
      const badX = lerp(px, 1030, easeOutQuint(clamp01((t - 10.4) / 1.6)));
      ctx.save();
      ctx.globalAlpha = outP;
      ctx.strokeStyle = 'rgba(74, 222, 128, 0.75)';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(px + 20, py - 40);
      ctx.quadraticCurveTo(px + 220, py - 150, goodX, 208);
      ctx.stroke();
      ctx.restore();
      drawKineticPill(ctx, goodX + 90, 208, 'تصدیق → فراوانی', outP, '#4ade80', '✓');

      if (badX > px) {
        ctx.save();
        ctx.globalAlpha = clamp01((t - 10.4) / 1.6);
        ctx.strokeStyle = 'rgba(248, 113, 113, 0.55)';
        ctx.setLineDash([8, 8]);
        ctx.lineWidth = 2.6;
        ctx.beginPath();
        ctx.moveTo(px + 20, py + 46);
        ctx.quadraticCurveTo(px + 220, py + 170, badX, 470);
        ctx.stroke();
        ctx.restore();
        drawKineticPill(ctx, badX + 90, 470, 'تکذیب → محرومیت', clamp01((t - 10.4) / 1.6), '#f87171', '✕');
      }
    }

    // شبکهٔ فیلتر
    ctx.save();
    ctx.globalAlpha = 0.28 + energy * 0.2;
    ctx.strokeStyle = withAlpha(accent, 0.5);
    ctx.lineWidth = 1;
    for (let i = -6; i <= 6; i++) {
      ctx.beginPath();
      ctx.moveTo(px + i * 14, py - 120);
      ctx.lineTo(px + i * 14, py + 120);
      ctx.stroke();
    }
    ctx.restore();
    ctx.restore();
  }

  // فاز ب: چهار دروازهٔ نگهبانی
  if (phase > 0.005) {
    ctx.save();
    ctx.globalAlpha = phase;
    ctx.translate((1 - phase) * 70, 0);

    drawGlowingText(
      ctx,
      'چهار نگهبانِ ورودی',
      cx,
      168,
      '800 30px "Vazirmatn", sans-serif',
      '#f8fafc',
      withAlpha(accent, 0.55),
      18,
    );

    const gates = [
      { label: 'چشم', glyph: '◉', at: 18.5 },
      { label: 'گوش', glyph: '◍', at: 20.2 },
      { label: 'کلام', glyph: '❝', at: 21.9 },
      { label: 'قلب', glyph: '♥', at: 23.6 },
    ];
    gates.forEach((gt, i) => {
      const x = 250 + i * 260;
      const y = 330;
      const p = clamp01((t - gt.at) / 1.1);
      if (p <= 0) return;
      ctx.save();
      ctx.globalAlpha = p;
      // طاقِ دروازه
      ctx.strokeStyle = withAlpha(accent, 0.7);
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.arc(x, y + 62, 56, Math.PI, 0);
      ctx.lineTo(x + 56, y + 62);
      ctx.lineTo(x - 56, y + 62);
      ctx.stroke();
      ctx.fillStyle = 'rgba(8, 14, 32, 0.7)';
      ctx.fill();
      ctx.restore();
      drawNodeBadge(ctx, x, y + 6, 26, gt.glyph, accent2, p);
      drawGlowingText(
        ctx,
        gt.label,
        x,
        y + 112,
        '700 20px "Vazirmatn", sans-serif',
        '#e2e8f0',
        withAlpha(accent, 0.4),
        10,
      );
      if (p > 0.9) {
        const check = clamp01((t - gt.at - 1.1) / 0.5);
        drawGlowingText(ctx, '✓', x, y - 52, `700 ${Math.round(24 * easeOutBack(check))}px "Vazirmatn"`, '#4ade80', 'rgba(74,222,128,0.6)', 14);
      }
    });

    // نوارِ تصمیم
    const dp = clamp01((t - 25.4) / 3);
    if (dp > 0) {
      drawRoundedRect(ctx, cx - 300, 480, 600, 52, 26);
      ctx.fillStyle = 'rgba(7, 12, 28, 0.85)';
      ctx.fill();
      ctx.strokeStyle = withAlpha(accent, 0.6);
      ctx.lineWidth = 1.6;
      ctx.stroke();
      ctx.save();
      drawRoundedRect(ctx, cx - 296, 484, 592 * easeOutCubic(dp), 44, 22);
      ctx.fillStyle = withAlpha('#4ade80', 0.22);
      ctx.fill();
      ctx.restore();
      drawGlowingText(
        ctx,
        'تصدیق کن، نه تکذیب',
        cx,
        507,
        '800 22px "Vazirmatn", sans-serif',
        '#dcfce7',
        'rgba(74,222,128,0.5)',
        12,
      );
    }
    ctx.restore();
  }

  drawProgressRing(ctx, 1180, 560, 26, clamp01(t / 30), accent, 4);
};

/* ══════════════════════════════════════════════════════════════════
   فصل ۳ — شهرِ فراوانی (۶۲..۹۶)
   ══════════════════════════════════════════════════════════════════ */
export const drawSceneCityAbundance: SceneDraw = (ctx, t, g, energy, accent, accent2) => {
  const roadY = 520;
  const buildings = [
    { x: 200, w: 62, h: 150, at: 1.0 },
    { x: 286, w: 78, h: 232, at: 2.2 },
    { x: 388, w: 54, h: 118, at: 3.1 },
    { x: 466, w: 88, h: 292, at: 4.0 },
    { x: 578, w: 60, h: 176, at: 5.2 },
    { x: 662, w: 96, h: 336, at: 6.2 },
    { x: 782, w: 58, h: 142, at: 7.4 },
    { x: 864, w: 82, h: 254, at: 8.3 },
    { x: 970, w: 66, h: 196, at: 9.4 },
    { x: 1060, w: 90, h: 300, at: 10.4 },
  ];

  // زمین و شبکهٔ ایزومتریک
  ctx.save();
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.16)';
  ctx.lineWidth = 1;
  for (let i = 0; i < 14; i++) {
    const y = roadY + 8 + i * 12;
    ctx.beginPath();
    ctx.moveTo(60 - i * 4, y);
    ctx.lineTo(1220 + i * 4, y);
    ctx.stroke();
  }
  ctx.restore();

  buildings.forEach((b, i) => {
    const p = easeOutQuint(clamp01((t - b.at) / 1.6));
    if (p <= 0) return;
    const h = b.h * p;
    const y = roadY - h;
    const grad = ctx.createLinearGradient(b.x, y, b.x + b.w, roadY);
    grad.addColorStop(0, 'rgba(19, 30, 62, 0.96)');
    grad.addColorStop(1, 'rgba(9, 15, 34, 0.98)');
    ctx.fillStyle = grad;
    ctx.fillRect(b.x, y, b.w, h);
    ctx.strokeStyle = withAlpha(accent2, 0.42);
    ctx.lineWidth = 1.4;
    ctx.strokeRect(b.x, y, b.w, h);

    // پنجره‌های روشن
    const cols = Math.floor(b.w / 18);
    const rows = Math.floor(h / 22);
    for (let c = 0; c < cols; c++) {
      for (let r = 0; r < rows; r++) {
        const on = seeded(i * 97 + c * 13 + r * 7) > 0.45;
        const flick = 0.5 + 0.5 * Math.sin(g * 2 + c + r * 2 + i);
        if (!on) continue;
        ctx.fillStyle = withAlpha(accent, 0.18 + flick * 0.5);
        ctx.fillRect(b.x + 7 + c * 18, y + 9 + r * 22, 9, 11);
      }
    }
  });

  // جرثقیل
  const craneP = clamp01((t - 4) / 1.6);
  if (craneP > 0) {
    const cxp = 620;
    ctx.save();
    ctx.globalAlpha = craneP;
    ctx.strokeStyle = withAlpha(accent, 0.85);
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(cxp, roadY);
    ctx.lineTo(cxp, 150);
    ctx.stroke();
    const arm = Math.sin(g * 0.45) * 0.16;
    ctx.translate(cxp, 152);
    ctx.rotate(arm);
    ctx.beginPath();
    ctx.moveTo(-150, 0);
    ctx.lineTo(190, 0);
    ctx.stroke();
    ctx.strokeStyle = withAlpha(accent2, 0.7);
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(150, 0);
    ctx.lineTo(150, 70 + Math.sin(g * 1.6) * 16);
    ctx.stroke();
    ctx.fillStyle = accent2;
    ctx.fillRect(138, 66 + Math.sin(g * 1.6) * 16, 24, 18);
    ctx.restore();
  }

  // جریانِ ثروت روی خیابان
  ctx.strokeStyle = withAlpha(accent2, 0.5);
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(80, roadY);
  ctx.lineTo(1200, roadY);
  ctx.stroke();
  for (let i = 0; i < 16; i++) {
    const fx = 90 + ((i * 74 + g * 130) % 1100);
    ctx.fillStyle = i % 2 === 0 ? accent : accent2;
    ctx.shadowColor = accent;
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(fx, roadY, 4 + energy * 2.4, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.shadowBlur = 0;

  // شمارنده‌های زنده
  const c1 = clamp01((t - 8) / 1.2);
  const c2 = clamp01((t - 12) / 1.2);
  const counter = (x: number, y: number, label: string, value: number, color: string, p: number) => {
    if (p <= 0) return;
    ctx.save();
    ctx.globalAlpha = p;
    drawRoundedRect(ctx, x - 120, y - 40, 240, 80, 16);
    ctx.fillStyle = 'rgba(6, 11, 26, 0.86)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(color, 0.6);
    ctx.lineWidth = 1.5;
    ctx.stroke();
    drawGlowingText(
      ctx,
      toFaDigits(Math.round(value * easeOutCubic(p)).toLocaleString('en-US')),
      x,
      y - 12,
      '800 30px "Vazirmatn", sans-serif',
      color,
      withAlpha(color, 0.6),
      14,
    );
    drawGlowingText(ctx, label, x, y + 22, '500 15px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
    ctx.restore();
  };
  counter(270, 200, 'ساختمانِ در حالِ ساخت', 1284 * c1, accent, c1);
  counter(1010, 200, 'شغلِ تازه', 3476 * c2, '#4ade80', c2);

  const tags = [
    { x: 330, y: 430, label: 'چقدر ثروت!', icon: '﷼', at: 15 },
    { x: 640, y: 392, label: 'جریانِ روزی', icon: '≈', at: 18 },
    { x: 950, y: 430, label: 'فراوانی هست', icon: '✦', at: 21 },
    { x: 640, y: 470, label: 'ورودیِ ذهن کن', icon: '⌾', at: 25 },
  ];
  tags.forEach((tg) => {
    const p = clamp01((t - tg.at) / 1.0);
    if (p > 0)
      drawKineticPill(ctx, tg.x, tg.y + Math.sin(g * 2 + tg.x) * 4, tg.label, p, accent2, tg.icon, 0.95, 18);
  });
};

/* ══════════════════════════════════════════════════════════════════
   فصل ۴ — آفاقِ هستی (۹۶..۱۲۸)
   ══════════════════════════════════════════════════════════════════ */
export const drawSceneCosmosTasbih: SceneDraw = (ctx, t, g, energy, accent, accent2) => {
  const cx = 640;
  const cy = 330;

  // ستاره‌های عمیق
  for (let i = 0; i < 120; i++) {
    const sx = seeded(i * 11 + 3) * 1280;
    const sy = seeded(i * 17 + 5) * 620;
    const tw = 0.25 + 0.75 * (0.5 + 0.5 * Math.sin(g * 1.7 + i));
    ctx.fillStyle = `rgba(226, 232, 240, ${tw * 0.6})`;
    ctx.beginPath();
    ctx.arc(sx, sy, 0.6 + seeded(i) * 1.5, 0, Math.PI * 2);
    ctx.fill();
  }

  // خورشیدِ مرکزی
  const sunR = 44 + energy * 7;
  drawAudioAuraRing(ctx, cx, cy, sunR + 10, g, energy, accent2);
  const sg = ctx.createRadialGradient(cx - 10, cy - 12, 4, cx, cy, sunR);
  sg.addColorStop(0, '#fffbeb');
  sg.addColorStop(0.6, '#fbbf24');
  sg.addColorStop(1, '#b45309');
  ctx.fillStyle = sg;
  ctx.beginPath();
  ctx.arc(cx, cy, sunR, 0, Math.PI * 2);
  ctx.fill();

  // مدارها و سیارات
  const orbits = [
    { r: 118, speed: 0.42, size: 12, color: accent2, label: 'ماه', at: 2 },
    { r: 176, speed: -0.3, size: 9, color: accent, label: 'ستاره', at: 5 },
    { r: 238, speed: 0.22, size: 15, color: '#38bdf8', label: 'دریا', at: 8 },
    { r: 296, speed: -0.16, size: 11, color: '#fb7185', label: 'کوه', at: 11 },
  ];
  orbits.forEach((o) => {
    drawOrbitRing(ctx, cx, cy, o.r, g * o.speed * 0.3, o.color, 0.26, false);
    const a = g * o.speed + o.r;
    const ox = cx + Math.cos(a) * o.r;
    const oy = cy + Math.sin(a) * o.r * 0.46;
    ctx.fillStyle = o.color;
    ctx.shadowColor = o.color;
    ctx.shadowBlur = 18;
    ctx.beginPath();
    ctx.arc(ox, oy, o.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    const lp = clamp01((t - o.at) / 0.9);
    if (lp > 0)
      drawGlowingText(
        ctx,
        o.label,
        ox,
        oy - o.size - 16,
        `700 ${Math.round(15 * easeOutBack(lp))}px "Vazirmatn", sans-serif`,
        '#e2e8f0',
        withAlpha(o.color, 0.5),
        8,
      );
  });

  // معادن و دشت‌ها در پایین
  const ground = clamp01((t - 13) / 2);
  if (ground > 0) {
    ctx.save();
    ctx.globalAlpha = ground;
    ctx.strokeStyle = withAlpha(accent, 0.4);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(120, 566);
    for (let x = 120; x <= 1160; x += 20) {
      ctx.lineTo(x, 566 - Math.sin(x * 0.012) * 26 - Math.sin(x * 0.031 + g) * 6);
    }
    ctx.stroke();
    ctx.restore();
    ['معدن', 'دشت', 'جنگل'].forEach((label, i) => {
      const p = clamp01((t - 14 - i * 1.2) / 0.9);
      if (p > 0) drawKineticPill(ctx, 330 + i * 310, 576, label, p, accent, '◈', 0.85, 17);
    });
  }

  // تایپوگرافی بسم‌الله و حمد
  const bis = clamp01((t - 16.5) / 1.8);
  const ham = clamp01((t - 23) / 1.8);
  ctx.save();
  ctx.globalAlpha = bis;
  drawGlowingText(
    ctx,
    'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
    cx,
    148 - (1 - easeOutCubic(bis)) * 26,
    '700 42px "Amiri", serif',
    '#fde68a',
    withAlpha(accent2, 0.7),
    26,
  );
  ctx.restore();
  ctx.save();
  ctx.globalAlpha = ham;
  drawGlowingText(
    ctx,
    'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
    cx,
    206 - (1 - easeOutCubic(ham)) * 26,
    '700 30px "Amiri", serif',
    '#a7f3d0',
    withAlpha(accent, 0.7),
    22,
  );
  ctx.restore();

  // حلقهٔ تسبیحِ چرخان
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(g * 0.2);
  for (let i = 0; i < 33; i++) {
    const a = (i * Math.PI * 2) / 33;
    const rr = 350;
    const lit = clamp01((t * 2.2 - i * 0.5) % 8);
    ctx.fillStyle = withAlpha(accent, 0.15 + lit * 0.5);
    ctx.beginPath();
    ctx.arc(Math.cos(a) * rr, Math.sin(a) * rr * 0.42, 3 + lit * 2, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
};
