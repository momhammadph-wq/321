import {
  clamp01,
  drawAudioAuraRing,
  drawGlowingText,
  drawKineticPill,
  drawNodeBadge,
  drawProgressRing,
  drawRoundedRect,
  drawVerseCard,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  easeOutQuint,
  lerp,
  seeded,
  toFaDigits,
  withAlpha,
} from './drawPrimitives';
import type { SceneDraw } from './scenesPart1';

/* ══════════════════════════════════════════════════════════════════
   فصل ۵ — هفت دریا و درختانِ قلم (۱۲۸..۱۵۸)
   ══════════════════════════════════════════════════════════════════ */
export const drawSceneSevenSeas: SceneDraw = (ctx, t, g, energy, accent, accent2) => {
  // دریاها: هفت لایهٔ موج
  for (let i = 0; i < 7; i++) {
    const appear = easeOutCubic(clamp01((t - 1 - i * 1.5) / 1.6));
    if (appear <= 0) continue;
    const baseY = 300 + i * 40;
    const amp = 9 + i * 3.4 + energy * 4;
    const y = lerp(baseY + 120, baseY, appear);
    ctx.save();
    ctx.globalAlpha = 0.18 + i * 0.09;
    ctx.beginPath();
    ctx.moveTo(60, y + 40);
    for (let x = 60; x <= 1220; x += 14) {
      const w =
        Math.sin(x * 0.014 + g * (0.9 + i * 0.22) + i) * amp +
        Math.sin(x * 0.031 - g * 0.7 + i * 2) * amp * 0.4;
      ctx.lineTo(x, y + w);
    }
    ctx.lineTo(1220, 620);
    ctx.lineTo(60, 620);
    ctx.closePath();
    const wg = ctx.createLinearGradient(0, y - amp, 0, y + 150);
    wg.addColorStop(0, withAlpha(i % 2 === 0 ? accent : '#38bdf8', 0.85));
    wg.addColorStop(1, 'rgba(3, 12, 26, 0.05)');
    ctx.fillStyle = wg;
    ctx.fill();
    ctx.restore();

    // خطِ روی موج
    ctx.save();
    ctx.globalAlpha = 0.5 * appear;
    ctx.strokeStyle = withAlpha(i % 2 === 0 ? accent : accent2, 0.75);
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    for (let x = 60; x <= 1220; x += 14) {
      const w =
        Math.sin(x * 0.014 + g * (0.9 + i * 0.22) + i) * amp +
        Math.sin(x * 0.031 - g * 0.7 + i * 2) * amp * 0.4;
      if (x === 60) ctx.moveTo(x, y + w);
      else ctx.lineTo(x, y + w);
    }
    ctx.stroke();
    ctx.restore();

    if (i < 3 || i === 6) {
      drawKineticPill(
        ctx,
        i % 2 === 0 ? 200 : 1080,
        y + 12,
        `دریای ${toFaDigits(i + 1)}`,
        appear,
        accent,
        '≈',
        0.8,
        16,
      );
    }
  }

  // قطره‌های مرکب
  for (let i = 0; i < 9; i++) {
    const cycle = ((g * 0.42 + i * 0.13) % 1);
    const dx = 180 + seeded(i * 23) * 920;
    const dy = lerp(120, 520, cycle);
    ctx.save();
    ctx.globalAlpha = 1 - cycle * 0.85;
    ctx.fillStyle = accent2;
    ctx.shadowColor = accent2;
    ctx.shadowBlur = 16;
    ctx.beginPath();
    ctx.ellipse(dx, dy, 5, 8 + cycle * 6, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    if (cycle > 0.86) {
      const rp = (cycle - 0.86) / 0.14;
      ctx.save();
      ctx.globalAlpha = 1 - rp;
      ctx.strokeStyle = withAlpha(accent2, 0.8);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(dx, 522, rp * 46, rp * 13, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  // درختان → قلم‌ها
  for (let i = 0; i < 6; i++) {
    const p = clamp01((t - 13 - i * 1.1) / 1.4);
    if (p <= 0) continue;
    const x = 150 + i * 196;
    const h = 90 * easeOutQuint(p);
    ctx.save();
    ctx.globalAlpha = p;
    ctx.strokeStyle = withAlpha('#a3e635', 0.75);
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x, 300);
    ctx.lineTo(x, 300 - h);
    ctx.stroke();
    for (let b = 0; b < 4; b++) {
      const by = 300 - h + b * 16 + 8;
      const dir = b % 2 === 0 ? 1 : -1;
      ctx.beginPath();
      ctx.moveTo(x, by);
      ctx.quadraticCurveTo(x + dir * 22, by - 12, x + dir * 34, by + 4);
      ctx.stroke();
    }
    // نوکِ قلم
    ctx.fillStyle = accent2;
    ctx.shadowColor = accent2;
    ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.moveTo(x, 300 - h - 18);
    ctx.lineTo(x - 7, 300 - h + 2);
    ctx.lineTo(x + 7, 300 - h + 2);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  // خطوطِ نوشته‌شده در آسمان
  const writeP = clamp01((t - 18) / 8);
  if (writeP > 0) {
    ctx.save();
    ctx.globalAlpha = 0.85;
    for (let l = 0; l < 3; l++) {
      const lp = clamp01((writeP * 3 - l) / 1);
      if (lp <= 0) continue;
      const y = 150 + l * 34;
      const grd = ctx.createLinearGradient(1180, 0, 1180 - 1000 * lp, 0);
      grd.addColorStop(0, withAlpha(accent, 0.9));
      grd.addColorStop(1, withAlpha(accent, 0.05));
      ctx.strokeStyle = grd;
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      for (let x = 0; x < 1000 * lp; x += 8) {
        const yy = y + Math.sin(x * 0.05 + l * 2) * 4;
        if (x === 0) ctx.moveTo(1180 - x, yy);
        else ctx.lineTo(1180 - x, yy);
      }
      ctx.stroke();
    }
    ctx.restore();
  }

  drawVerseCard(ctx, 640, 250, 'وَلَوْ أَنَّمَا فِي الْأَرْضِ مِن شَجَرَةٍ أَقْلَامٌ', undefined, accent, clamp01((t - 21) / 2), 820);

  const inf = clamp01((t - 25) / 1.4);
  if (inf > 0) {
    ctx.save();
    ctx.globalAlpha = inf;
    drawGlowingText(
      ctx,
      '∞',
      640,
      348 + Math.sin(g * 1.6) * 6,
      `800 ${Math.round(66 * easeOutBack(inf))}px "Vazirmatn", sans-serif`,
      '#e0f2fe',
      withAlpha(accent, 0.8),
      30,
    );
    drawGlowingText(
      ctx,
      'نِعْمَت‌ها شُمُردنی نیست',
      640,
      410,
      '700 22px "Vazirmatn", sans-serif',
      '#bae6fd',
      withAlpha(accent2, 0.5),
      12,
    );
    ctx.restore();
  }
};

/* ══════════════════════════════════════════════════════════════════
   فصل ۶ — انفس؛ شگفتیِ درونِ جسم (۱۵۸..۱۹۰)
   ══════════════════════════════════════════════════════════════════ */
export const drawSceneBodyAnfus: SceneDraw = (ctx, t, g, energy, accent, accent2) => {
  const cx = 470;
  const cy = 340;
  const drawP = easeOutCubic(clamp01(t / 3));

  // هالهٔ تنفسی
  const breath = 0.5 + 0.5 * Math.sin(g * 0.85);
  drawAudioAuraRing(ctx, cx, cy, 150 + breath * 12, g, energy * 0.6, accent);

  // سیلوئتِ انسان
  ctx.save();
  ctx.globalAlpha = 0.9;
  ctx.strokeStyle = withAlpha(accent2, 0.85);
  ctx.lineWidth = 2.6;
  ctx.shadowColor = withAlpha(accent2, 0.5);
  ctx.shadowBlur = 20;
  ctx.beginPath();
  // سر
  ctx.arc(cx, cy - 148, 34 * drawP, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  // تن و دست‌ها و پاها
  ctx.moveTo(cx, cy - 114);
  ctx.lineTo(cx, cy + 42);
  ctx.moveTo(cx, cy - 96);
  ctx.quadraticCurveTo(cx - 62, cy - 60, cx - 76, cy + 14);
  ctx.moveTo(cx, cy - 96);
  ctx.quadraticCurveTo(cx + 62, cy - 60, cx + 76, cy + 14);
  ctx.moveTo(cx, cy + 42);
  ctx.quadraticCurveTo(cx - 34, cy + 108, cx - 44, cy + 176);
  ctx.moveTo(cx, cy + 42);
  ctx.quadraticCurveTo(cx + 34, cy + 108, cx + 44, cy + 176);
  ctx.stroke();
  ctx.restore();

  // رگ‌های نورانی
  ctx.save();
  ctx.globalAlpha = clamp01((t - 3) / 2) * 0.6;
  ctx.strokeStyle = withAlpha(accent, 0.55);
  ctx.lineWidth = 1.1;
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * Math.PI * 2 + g * 0.1;
    ctx.beginPath();
    ctx.moveTo(cx, cy - 40);
    ctx.quadraticCurveTo(
      cx + Math.cos(a) * 60,
      cy - 40 + Math.sin(a) * 70,
      cx + Math.cos(a) * 118,
      cy - 40 + Math.sin(a) * 140,
    );
    ctx.stroke();
  }
  ctx.restore();

  // اندام‌ها
  const organs = [
    { x: cx - 14, y: cy - 158, glyph: '◉', label: 'چشم', at: 5, side: -1 },
    { x: cx + 22, y: cy - 146, glyph: '◍', label: 'گوش', at: 6.6, side: 1 },
    { x: cx, y: cy - 74, glyph: '♥', label: 'قلب', at: 8.2, side: -1 },
    { x: cx - 26, y: cy - 22, glyph: '◐', label: 'کبد', at: 10, side: -1 },
    { x: cx + 28, y: cy - 14, glyph: '◑', label: 'کلیه', at: 11.6, side: 1 },
    { x: cx - 76, y: cy + 14, glyph: '✋', label: 'دست', at: 13.2, side: -1 },
    { x: cx + 44, y: cy + 176, glyph: '⌁', label: 'پا', at: 14.8, side: 1 },
  ];
  organs.forEach((o) => {
    const p = clamp01((t - o.at) / 1);
    if (p <= 0) return;
    drawNodeBadge(ctx, o.x, o.y, 17, o.glyph, o.glyph === '♥' ? '#fb7185' : accent, p);
    const lx = o.x + o.side * 130;
    ctx.save();
    ctx.globalAlpha = p;
    ctx.strokeStyle = withAlpha(accent, 0.45 * p);
    ctx.lineWidth = 1.3;
    ctx.setLineDash([4, 5]);
    ctx.beginPath();
    ctx.moveTo(o.x + o.side * 18, o.y);
    ctx.lineTo(lx - o.side * 60, o.y);
    ctx.stroke();
    ctx.restore();
    drawGlowingText(
      ctx,
      o.label,
      lx - o.side * 24,
      o.y,
      `700 ${Math.round(19 * easeOutBack(p))}px "Vazirmatn", sans-serif`,
      '#f1f5f9',
      withAlpha(accent, 0.45),
      10,
      o.side === -1 ? 'right' : 'left',
    );
  });

  // ضربانِ قلب
  const ecgP = clamp01((t - 9) / 2);
  if (ecgP > 0) {
    const beat = (g * 1.25) % 1;
    ctx.save();
    ctx.globalAlpha = 0.9;
    ctx.translate(cx, cy - 74);
    ctx.scale(1 + energy * 0.12 + Math.max(0, 0.18 - beat) * 1.4, 1 + energy * 0.12 + Math.max(0, 0.18 - beat) * 1.4);
    ctx.fillStyle = '#fb7185';
    ctx.shadowColor = '#fb7185';
    ctx.shadowBlur = 26;
    ctx.beginPath();
    ctx.arc(0, 0, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // نوارِ ECG
    ctx.save();
    ctx.strokeStyle = withAlpha('#fb7185', 0.85);
    ctx.lineWidth = 2.4;
    ctx.shadowColor = '#fb7185';
    ctx.shadowBlur = 12;
    ctx.beginPath();
    const w = 380;
    for (let i = 0; i <= w; i += 3) {
      const phase = ((i / w) * 3 + g * 1.1) % 1;
      let v = 0;
      if (phase > 0.42 && phase < 0.5) v = Math.sin((phase - 0.42) * 40) * 34;
      else if (phase > 0.5 && phase < 0.56) v = -14;
      else v = Math.sin(phase * 9) * 3;
      const x = 830 + i - w / 2 + w / 2;
      const y = 200 - v;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.restore();
  }

  // شمارندهٔ نعمت‌ها
  const cp = clamp01((t - 17) / 1.4);
  if (cp > 0) {
    ctx.save();
    ctx.globalAlpha = cp;
    drawRoundedRect(ctx, 800, 300, 400, 128, 18);
    ctx.fillStyle = 'rgba(6, 10, 24, 0.85)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(accent, 0.55);
    ctx.lineWidth = 1.5;
    ctx.stroke();
    drawGlowingText(
      ctx,
      toFaDigits(Math.round(37200000 * easeOutCubic(cp)).toLocaleString('en-US')),
      1000,
      348,
      '800 34px "Vazirmatn", sans-serif',
      accent,
      withAlpha(accent, 0.65),
      16,
    );
    drawGlowingText(
      ctx,
      'سلولِ در حالِ خدمت — بی‌قیمت',
      1000,
      392,
      '500 17px "Vazirmatn", sans-serif',
      '#cbd5e1',
      'rgba(0,0,0,0)',
      0,
    );
    ctx.restore();
  }

  drawVerseCard(
    ctx,
    1000,
    490,
    'وَفِي أَنفُسِكُمْ أَفَلَا تُبْصِرُونَ',
    'سورهٔ ذاریات • آیهٔ ۲۱',
    accent,
    clamp01((t - 21) / 2),
    520,
  );

  drawProgressRing(ctx, 1210, 140, 22, clamp01(t / 32), accent2, 4);
};

/* ══════════════════════════════════════════════════════════════════
   فصل ۷ — باشگاهِ روزانهٔ ذهن (۱۹۰..۲۱۸)
   ══════════════════════════════════════════════════════════════════ */
export const drawSceneMindGym: SceneDraw = (ctx, t, g, energy, accent, accent2) => {
  const cx = 430;
  const cy = 300;
  const lift = Math.abs(Math.sin(g * 1.35));
  const active = clamp01((t - 1.5) / 1.2);

  // هاله
  drawAudioAuraRing(ctx, cx, cy + 30, 120, g, energy, accent);

  // دمبل
  ctx.save();
  ctx.globalAlpha = active;
  const barY = cy - lift * 62;
  ctx.translate(cx, barY);
  ctx.rotate(Math.sin(g * 1.35) * 0.05);
  const barW = 190;
  ctx.fillStyle = 'rgba(148, 163, 184, 0.9)';
  ctx.fillRect(-barW / 2, -6, barW, 12);
  [-1, 1].forEach((s) => {
    ctx.fillStyle = accent;
    ctx.shadowColor = withAlpha(accent, 0.8);
    ctx.shadowBlur = 22;
    drawRoundedRect(ctx, s * (barW / 2) - (s === 1 ? 0 : 30), -34, 30, 68, 8);
    ctx.fill();
    ctx.fillStyle = accent2;
    drawRoundedRect(ctx, s * (barW / 2 + 16) - (s === 1 ? 0 : 20), -24, 20, 48, 6);
    ctx.fill();
  });
  ctx.restore();
  ctx.shadowBlur = 0;

  // شمارشِ تکرار
  const reps = Math.floor(Math.max(0, (t - 2) * 1.35));
  ctx.save();
  ctx.globalAlpha = active;
  drawGlowingText(
    ctx,
    `${toFaDigits(Math.min(30, reps))} تکرار`,
    cx,
    cy + 120,
    '800 30px "Vazirmatn", sans-serif',
    '#f8fafc',
    withAlpha(accent, 0.6),
    18,
  );
  ctx.restore();

  // جرقه‌های تلاش
  for (let i = 0; i < 14; i++) {
    const sp = ((g * 0.9 + i * 0.14) % 1);
    const a = seeded(i * 31) * Math.PI * 2;
    const r = 90 + sp * 90;
    ctx.save();
    ctx.globalAlpha = (1 - sp) * 0.8;
    ctx.fillStyle = i % 3 === 0 ? accent2 : accent;
    ctx.beginPath();
    ctx.arc(cx + Math.cos(a) * r, barY + Math.sin(a) * r * 0.6, 2.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // نمودارِ عضلهٔ شکرگزاری
  const chartP = clamp01((t - 6) / 2.2);
  if (chartP > 0) {
    ctx.save();
    ctx.globalAlpha = chartP;
    const bx = 760;
    const by = 430;
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.35)';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(bx - 20, by);
    ctx.lineTo(bx + 420, by);
    ctx.moveTo(bx - 20, by);
    ctx.lineTo(bx - 20, by - 220);
    ctx.stroke();
    for (let i = 0; i < 14; i++) {
      const p = clamp01((t - 6 - i * 0.5) / 1);
      const h = (40 + i * 13) * easeOutQuint(p);
      const x = bx + i * 30;
      const grd = ctx.createLinearGradient(0, by - h, 0, by);
      grd.addColorStop(0, withAlpha(accent, 0.95));
      grd.addColorStop(1, withAlpha(accent2, 0.25));
      ctx.fillStyle = grd;
      drawRoundedRect(ctx, x, by - h, 20, h, 6);
      ctx.fill();
    }
    drawGlowingText(
      ctx,
      'رشدِ عضلهٔ شکرگزاری در ۳۰ روز',
      bx + 200,
      by + 34,
      '600 18px "Vazirmatn", sans-serif',
      '#cbd5e1',
      withAlpha(accent, 0.35),
      8,
    );
    ctx.restore();
  }

  // تقویمِ هرروزه
  const calP = clamp01((t - 14) / 1.6);
  if (calP > 0) {
    ctx.save();
    ctx.globalAlpha = calP;
    for (let r = 0; r < 2; r++) {
      for (let c = 0; c < 15; c++) {
        const idx = r * 15 + c;
        const p = clamp01((t - 14 - idx * 0.28) / 0.5);
        const x = 1160 - c * 27;
        const y = 170 + r * 30;
        drawRoundedRect(ctx, x, y, 20, 22, 5);
        ctx.fillStyle = p > 0.6 ? withAlpha(accent, 0.25 + 0.65 * easeOutBack(p)) : 'rgba(148,163,184,0.12)';
        ctx.fill();
        ctx.strokeStyle = withAlpha(accent, 0.35);
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    }
    drawGlowingText(
      ctx,
      'هر روز • تعطیلی ندارد',
      970,
      246,
      '700 18px "Vazirmatn", sans-serif',
      '#e2e8f0',
      withAlpha(accent2, 0.5),
      10,
    );
    ctx.restore();
  }

  const tags = [
    { x: 250, y: 470, label: 'ذهن = عضله', icon: '◎', at: 3 },
    { x: 560, y: 500, label: 'هر روز فراوانی ببین', icon: '✦', at: 8 },
    { x: 300, y: 545, label: 'بازگو کن', icon: '❝', at: 12 },
  ];
  tags.forEach((tg) => {
    const p = clamp01((t - tg.at) / 1);
    if (p > 0)
      drawKineticPill(
        ctx,
        tg.x,
        tg.y + Math.sin(g * 2 + tg.x * 0.02) * 4,
        tg.label,
        p,
        accent2,
        tg.icon,
        0.9,
        18,
      );
  });

  drawProgressRing(ctx, 1210, 560, 22, clamp01(t / 28), accent, 4);
  void easeInOutCubic;
};

/* ══════════════════════════════════════════════════════════════════
   فصل ۸ — ده دقیقهٔ صبحگاهی (۲۱۸..۲۴۶)
   ══════════════════════════════════════════════════════════════════ */
export const drawSceneTenMinutes: SceneDraw = (ctx, t, g, energy, accent, accent2) => {
  const cx = 380;
  const cy = 320;
  const R = 132;

  // ساعت
  ctx.save();
  ctx.strokeStyle = 'rgba(148, 163, 184, 0.3)';
  ctx.lineWidth = 10;
  ctx.beginPath();
  ctx.arc(cx, cy, R, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();

  const sweep = easeInOutCubic(clamp01(t / 18));
  ctx.save();
  ctx.strokeStyle = accent;
  ctx.shadowColor = withAlpha(accent, 0.85);
  ctx.shadowBlur = 24;
  ctx.lineWidth = 10;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.arc(cx, cy, R, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * sweep);
  ctx.stroke();
  ctx.restore();

  // عقربه‌ها
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-Math.PI / 2 + Math.PI * 2 * sweep);
  ctx.strokeStyle = '#f8fafc';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(R - 26, 0);
  ctx.stroke();
  ctx.restore();
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(g * 0.6);
  ctx.strokeStyle = withAlpha(accent2, 0.9);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(R - 8, 0);
  ctx.stroke();
  ctx.restore();
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.arc(cx, cy, 6, 0, Math.PI * 2);
  ctx.fill();

  drawGlowingText(
    ctx,
    `${toFaDigits(Math.round(sweep * 10))} دقیقه`,
    cx,
    cy + 8,
    '800 34px "Vazirmatn", sans-serif',
    '#f8fafc',
    withAlpha(accent, 0.55),
    16,
  );
  drawGlowingText(
    ctx,
    'حضورِ آرام',
    cx,
    cy + 52,
    '500 17px "Vazirmatn", sans-serif',
    '#94a3b8',
    'rgba(0,0,0,0)',
    0,
  );

  // دایرهٔ تنفس
  const br = 0.5 + 0.5 * Math.sin(g * 0.7);
  ctx.save();
  ctx.globalAlpha = 0.5 + br * 0.4;
  ctx.strokeStyle = withAlpha(accent2, 0.7);
  ctx.lineWidth = 2;
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(cx, cy, R + 34 + i * 18 + br * 12, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
  drawGlowingText(
    ctx,
    br > 0.5 ? 'دم…' : 'بازدم…',
    cx,
    cy + R + 74,
    '700 20px "Vazirmatn", sans-serif',
    '#bae6fd',
    withAlpha(accent2, 0.5),
    10,
  );

  // دفترچه: سه فراوانی
  const nbP = clamp01((t - 4) / 1.4);
  if (nbP > 0) {
    ctx.save();
    ctx.globalAlpha = nbP;
    const nx = 720;
    const ny = 200;
    ctx.translate(nx, ny);
    ctx.rotate(-0.02);
    ctx.shadowColor = 'rgba(0,0,0,0.55)';
    ctx.shadowBlur = 30;
    drawRoundedRect(ctx, 0, 0, 460, 250, 16);
    ctx.fillStyle = 'rgba(9, 14, 30, 0.94)';
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = withAlpha(accent, 0.5);
    ctx.lineWidth = 1.6;
    ctx.stroke();
    ctx.fillStyle = withAlpha(accent, 0.16);
    ctx.fillRect(0, 0, 460, 46);
    drawGlowingText(
      ctx,
      'سه فراوانیِ امروز',
      nx + 230 - nx,
      23,
      '800 20px "Vazirmatn", sans-serif',
      accent,
      withAlpha(accent, 0.5),
      8,
    );
    const items = ['سلامتیِ تن', 'سقفِ بالای سر', 'یک لبخندِ بی‌دلیل'];
    items.forEach((it, i) => {
      const p = clamp01((t - 7 - i * 2.4) / 0.9);
      if (p <= 0) return;
      const y = 84 + i * 54;
      drawRoundedRect(ctx, 400 - 24, y - 13, 26, 26, 7);
      ctx.strokeStyle = withAlpha(accent, 0.6);
      ctx.lineWidth = 1.6;
      ctx.stroke();
      if (p > 0.55) {
        ctx.strokeStyle = '#4ade80';
        ctx.lineWidth = 3.4;
        ctx.lineCap = 'round';
        const cp = easeOutBack((p - 0.55) / 0.45);
        ctx.beginPath();
        ctx.moveTo(400 - 18, y);
        ctx.lineTo(400 - 13, y + 6 * cp);
        ctx.lineTo(400 - 3, y - 7 * cp);
        ctx.stroke();
      }
      ctx.save();
      ctx.globalAlpha = p;
      const w = 300 * easeOutCubic(p);
      ctx.fillStyle = 'rgba(226, 232, 240, 0.9)';
      drawRoundedRect(ctx, 380 - w, y - 9, w, 18, 9);
      ctx.fill();
      ctx.font = '600 18px "Vazirmatn", sans-serif';
      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#f8fafc';
      ctx.fillText(it, 380, y);
      ctx.restore();
    });
    ctx.restore();
  }

  // فنجان و بخار
  const cupP = clamp01((t - 15) / 1.2);
  if (cupP > 0) {
    ctx.save();
    ctx.globalAlpha = cupP;
    const cxx = 780;
    const cyy = 520;
    ctx.strokeStyle = withAlpha(accent2, 0.85);
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.moveTo(cxx - 30, cyy - 26);
    ctx.lineTo(cxx - 24, cyy + 22);
    ctx.lineTo(cxx + 24, cyy + 22);
    ctx.lineTo(cxx + 30, cyy - 26);
    ctx.closePath();
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(cxx + 38, cyy - 2, 14, -Math.PI / 2, Math.PI / 2);
    ctx.stroke();
    for (let i = 0; i < 3; i++) {
      const sp = ((g * 0.5 + i * 0.33) % 1);
      ctx.globalAlpha = (1 - sp) * 0.55 * cupP;
      ctx.beginPath();
      ctx.moveTo(cxx - 12 + i * 12, cyy - 30);
      ctx.quadraticCurveTo(
        cxx - 12 + i * 12 + Math.sin(sp * 6) * 12,
        cyy - 30 - sp * 46,
        cxx - 12 + i * 12,
        cyy - 30 - sp * 88,
      );
      ctx.strokeStyle = withAlpha(accent2, 0.7);
      ctx.lineWidth = 2;
      ctx.stroke();
    }
    ctx.restore();
  }

  // پیکانِ رفتن به کار
  const goP = clamp01((t - 21) / 1.6);
  if (goP > 0) {
    ctx.save();
    ctx.globalAlpha = goP;
    const startX = 940;
    const endX = lerp(startX, 1150, easeOutQuint(goP));
    ctx.strokeStyle = accent;
    ctx.lineWidth = 3.4;
    ctx.shadowColor = withAlpha(accent, 0.8);
    ctx.shadowBlur = 16 + energy * 14;
    ctx.beginPath();
    ctx.moveTo(startX, 520);
    ctx.lineTo(endX, 520);
    ctx.lineTo(endX - 16, 506);
    ctx.moveTo(endX, 520);
    ctx.lineTo(endX - 16, 534);
    ctx.stroke();
    ctx.restore();
    drawKineticPill(ctx, 1040, 566, 'با ذهنِ آرام برو سرِ کار', goP, accent, '→', 0.9, 17);
  }
};
