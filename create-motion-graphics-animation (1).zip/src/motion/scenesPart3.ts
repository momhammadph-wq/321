import {
  clamp01,
  drawCharReveal,
  drawGlowingText,
  drawKineticPill,
  drawNodeBadge,
  drawProgressRing,
  drawRoundedRect,
  drawVerseCard,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  easeOutQuint,
  lerp,
  seeded,
  toFaDigits,
  withAlpha,
} from './drawPrimitives';
import type { SceneDraw } from './scenesPart1';

/* ══════════════════════════════════════════════════════════════════
   فصل ۹ — سینمای غیب (۲۴۶..۲۸۶)
   ══════════════════════════════════════════════════════════════════ */
export const drawSceneCinemaGhayb: SceneDraw = (ctx, t, g, energy, accent, accent2) => {
  const sx = 640;
  const sy = 300;
  const sw = 620;
  const sh = 330;

  // پردهٔ سینما باز می‌شود
  const curtain = easeInOutCubic(clamp01((t - 1) / 3));
  ctx.save();
  ctx.strokeStyle = withAlpha(accent2, 0.55);
  ctx.lineWidth = 3;
  drawRoundedRect(ctx, sx - sw / 2 - 14, sy - sh / 2 - 14, sw + 28, sh + 28, 12);
  ctx.stroke();
  ctx.fillStyle = 'rgba(4, 7, 18, 0.92)';
  ctx.fill();
  ctx.restore();

  // محتوای روی پرده
  ctx.save();
  ctx.beginPath();
  ctx.rect(sx - sw / 2, sy - sh / 2, sw, sh);
  ctx.clip();
  const inner = ctx.createRadialGradient(sx, sy, 20, sx, sy, sw * 0.62);
  inner.addColorStop(0, withAlpha(accent, 0.2 + energy * 0.12));
  inner.addColorStop(1, 'rgba(3, 6, 16, 0.96)');
  ctx.fillStyle = inner;
  ctx.fillRect(sx - sw / 2, sy - sh / 2, sw, sh);

  // قاب‌های غیبی که یکی‌یکی روشن می‌شوند
  const frames = ['◈', '✦', '☾', '⌘', '❂', '⟡'];
  frames.forEach((fr, i) => {
    const p = clamp01((t - 4 - i * 1.7) / 1.2);
    if (p <= 0) return;
    const col = i % 3;
    const row = Math.floor(i / 3);
    const x = sx - 200 + col * 200;
    const y = sy - 70 + row * 130;
    ctx.save();
    ctx.globalAlpha = p;
    ctx.translate(x, y + (1 - easeOutBack(p)) * 26);
    drawRoundedRect(ctx, -76, -50, 152, 100, 10);
    ctx.fillStyle = withAlpha(accent, 0.1 + 0.1 * Math.sin(g * 2 + i));
    ctx.fill();
    ctx.strokeStyle = withAlpha(accent, 0.7);
    ctx.lineWidth = 1.6;
    ctx.stroke();
    ctx.fillStyle = '#fde68a';
    ctx.shadowColor = withAlpha(accent, 0.9);
    ctx.shadowBlur = 18;
    ctx.font = '700 34px "Vazirmatn", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(fr, 0, 0);
    ctx.restore();
  });

  // اسکن‌لاین
  ctx.globalAlpha = 0.16;
  for (let y = sy - sh / 2; y < sy + sh / 2; y += 4) {
    ctx.fillStyle = '#e2e8f0';
    ctx.fillRect(sx - sw / 2, y, sw, 1);
  }
  ctx.globalAlpha = 1;
  ctx.restore();

  // پرده‌های کناری
  ctx.save();
  [-1, 1].forEach((s) => {
    const w = 46 * (1 - curtain) + 16;
    const grd = ctx.createLinearGradient(sx + s * (sw / 2 + 14), 0, sx + s * (sw / 2 + 14 - s * w), 0);
    grd.addColorStop(0, 'rgba(127, 29, 29, 0.9)');
    grd.addColorStop(1, 'rgba(69, 10, 10, 0.55)');
    ctx.fillStyle = grd;
    ctx.fillRect(
      s === 1 ? sx + sw / 2 + 14 - w : sx - sw / 2 - 14,
      sy - sh / 2 - 14,
      w,
      sh + 28,
    );
  });
  ctx.restore();

  // پروژکتور و مخروطِ نور
  const projP = clamp01((t - 2.5) / 1.6);
  if (projP > 0) {
    ctx.save();
    ctx.globalAlpha = projP;
    const px = 1160;
    const py = 560;
    const beam = ctx.createLinearGradient(px, py, sx + 180, sy + 90);
    beam.addColorStop(0, withAlpha(accent2, 0.55 + energy * 0.2));
    beam.addColorStop(1, withAlpha(accent2, 0.02));
    ctx.fillStyle = beam;
    ctx.beginPath();
    ctx.moveTo(px - 12, py - 8);
    ctx.lineTo(sx + 300, sy + 150);
    ctx.lineTo(sx + 300, sy + 30);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
    drawRoundedRect(ctx, px - 40, py - 24, 74, 44, 8);
    ctx.fill();
    ctx.strokeStyle = withAlpha(accent2, 0.8);
    ctx.lineWidth = 1.8;
    ctx.stroke();
    ctx.fillStyle = accent2;
    ctx.shadowColor = accent2;
    ctx.shadowBlur = 18 + energy * 16;
    ctx.beginPath();
    ctx.arc(px - 40, py - 2, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // حلقهٔ فیلمِ چرخان
  ctx.save();
  ctx.translate(150, 190);
  ctx.rotate(g * 0.9);
  ctx.strokeStyle = withAlpha(accent, 0.75);
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(0, 0, 62, 0, Math.PI * 2);
  ctx.stroke();
  for (let i = 0; i < 8; i++) {
    const a = (i * Math.PI * 2) / 8;
    ctx.beginPath();
    ctx.arc(Math.cos(a) * 42, Math.sin(a) * 42, 11, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
  drawGlowingText(ctx, 'نوارِ روایت', 150, 288, '600 16px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);

  // شمارندهٔ ۱۴۰۰ سال
  const cp = clamp01((t - 20) / 2);
  if (cp > 0) {
    ctx.save();
    ctx.globalAlpha = cp;
    drawRoundedRect(ctx, 76, 360, 300, 132, 16);
    ctx.fillStyle = 'rgba(6, 10, 24, 0.88)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(accent2, 0.6);
    ctx.lineWidth = 1.5;
    ctx.stroke();
    drawGlowingText(
      ctx,
      toFaDigits(Math.round(1400 * easeOutCubic(cp)).toLocaleString('en-US')),
      226,
      410,
      '800 46px "Vazirmatn", sans-serif',
      accent2,
      withAlpha(accent2, 0.7),
      22,
    );
    drawGlowingText(
      ctx,
      'سال گفتار، بی‌تصویر',
      226,
      458,
      '600 17px "Vazirmatn", sans-serif',
      '#cbd5e1',
      'rgba(0,0,0,0)',
      0,
    );
    ctx.restore();
  }

  drawVerseCard(
    ctx,
    sx,
    560,
    'معارف را به تصویر تبدیل کن',
    'جهادِ تبیین',
    accent,
    clamp01((t - 28) / 2),
    560,
  );

  const tags = [
    { x: 1010, y: 180, label: 'هدفِ سال', icon: '◎', at: 8 },
    { x: 1090, y: 250, label: 'بُعدِ غیبی', icon: '✧', at: 12 },
    { x: 1010, y: 320, label: 'به تصویر بکش', icon: '▣', at: 16 },
  ];
  tags.forEach((tg) => {
    const p = clamp01((t - tg.at) / 1);
    if (p > 0)
      drawKineticPill(
        ctx,
        tg.x,
        tg.y + Math.sin(g * 2 + tg.x * 0.02) * 4,
        tg.label,
        p,
        accent,
        tg.icon,
        0.88,
        17,
      );
  });
};

/* ══════════════════════════════════════════════════════════════════
   فصل ۱۰ — هدایتِ قدم‌به‌قدم (۲۸۶..۳۱۸)
   ══════════════════════════════════════════════════════════════════ */
export const drawSceneStepGuidance: SceneDraw = (ctx, t, g, energy, accent, accent2) => {
  // مه که کنار می‌رود
  const fog = 1 - easeInOutCubic(clamp01(t / 12));
  if (fog > 0.01) {
    ctx.save();
    ctx.globalAlpha = fog * 0.55;
    const fg = ctx.createLinearGradient(0, 120, 0, 620);
    fg.addColorStop(0, 'rgba(148, 163, 184, 0.55)');
    fg.addColorStop(1, 'rgba(148, 163, 184, 0)');
    ctx.fillStyle = fg;
    ctx.fillRect(0, 120, 1280, 500);
    ctx.restore();
  }

  // فانوسِ مقصد
  const lanternX = 1080;
  const lanternY = 176;
  ctx.save();
  const lg = ctx.createRadialGradient(lanternX, lanternY, 6, lanternX, lanternY, 190);
  lg.addColorStop(0, withAlpha(accent2, 0.55 + energy * 0.2));
  lg.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = lg;
  ctx.beginPath();
  ctx.arc(lanternX, lanternY, 190, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = accent2;
  ctx.shadowColor = accent2;
  ctx.shadowBlur = 26;
  ctx.beginPath();
  ctx.arc(lanternX, lanternY, 11 + Math.sin(g * 3) * 1.6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  drawGlowingText(ctx, 'مقصد', lanternX, lanternY - 44, '700 18px "Vazirmatn", sans-serif', '#fde68a', withAlpha(accent2, 0.5), 10);

  // پله‌ها در پرسپکتیو
  const steps = 12;
  const walk = clamp01((t - 2) / 24) * steps;
  for (let i = 0; i < steps; i++) {
    const k = i / (steps - 1);
    const x = lerp(190, lanternX - 60, easeOutCubic(k));
    const y = lerp(560, 250, easeOutCubic(k));
    const w = lerp(190, 62, k);
    const h = lerp(30, 12, k);
    const lit = clamp01(walk - i);
    ctx.save();
    ctx.globalAlpha = 0.35 + lit * 0.65;
    drawRoundedRect(ctx, x - w / 2, y, w, h, 4);
    const grd = ctx.createLinearGradient(x, y, x, y + h);
    grd.addColorStop(0, lit > 0.5 ? withAlpha(accent, 0.85) : 'rgba(30, 41, 59, 0.9)');
    grd.addColorStop(1, 'rgba(8, 13, 28, 0.95)');
    ctx.fillStyle = grd;
    ctx.fill();
    ctx.strokeStyle = withAlpha(lit > 0.5 ? accent : '#475569', 0.7);
    ctx.lineWidth = 1.4;
    ctx.stroke();
    if (lit > 0.6) {
      ctx.shadowColor = accent;
      ctx.shadowBlur = 22;
      ctx.strokeStyle = withAlpha(accent, 0.9);
      ctx.stroke();
      ctx.shadowBlur = 0;
    }
    ctx.restore();

    if (lit > 0.75 && i % 3 === 0 && i <= 9) {
      drawGlowingText(
        ctx,
        `قدم ${toFaDigits(i + 1)}`,
        x,
        y - 16,
        '700 15px "Vazirmatn", sans-serif',
        '#e2e8f0',
        withAlpha(accent, 0.45),
        8,
      );
    }
  }

  // نورِ راه‌رونده با دنباله
  const wk = clamp01((t - 2) / 24);
  const wx = lerp(190, lanternX - 60, easeOutCubic(wk));
  const wy = lerp(548, 240, easeOutCubic(wk));
  ctx.save();
  for (let i = 6; i >= 1; i--) {
    const back = clamp01(wk - i * 0.012);
    const bx = lerp(190, lanternX - 60, easeOutCubic(back));
    const by = lerp(548, 240, easeOutCubic(back));
    ctx.globalAlpha = 0.16 * (1 - i / 7);
    ctx.fillStyle = accent;
    ctx.beginPath();
    ctx.arc(bx, by, 12 - i, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
  ctx.fillStyle = '#f8fafc';
  ctx.shadowColor = accent;
  ctx.shadowBlur = 26 + energy * 18;
  ctx.beginPath();
  ctx.arc(wx, wy - 8, 9 + Math.sin(g * 4) * 1.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // نشانه‌ها
  const signs = [
    { x: 300, y: 200, label: 'یک قدم گفته می‌شود', icon: '➊', at: 6 },
    { x: 620, y: 160, label: 'قدمِ بعدی روشن می‌شود', icon: '➋', at: 12 },
    { x: 900, y: 380, label: 'نشانه‌ها می‌آیند', icon: '➌', at: 18 },
    { x: 420, y: 430, label: 'بُعدِ غیبی', icon: '✧', at: 23 },
  ];
  signs.forEach((s) => {
    const p = clamp01((t - s.at) / 1.1);
    if (p > 0)
      drawKineticPill(ctx, s.x, s.y + Math.sin(g * 1.8 + s.x * 0.01) * 5, s.label, p, accent2, s.icon, 0.92, 18);
  });

  drawCharReveal(
    ctx,
    'يَهْدِي بِهِ اللَّهُ مَنِ اتَّبَعَ رِضْوَانَهُ سُبُلَ السَّلَامِ',
    640,
    562,
    '700 26px "Amiri", serif',
    '#fde68a',
    withAlpha(accent, 0.8),
    clamp01((t - 8) / 4),
  );

  drawProgressRing(ctx, 110, 170, 22, wk, accent, 4);
};

/* ══════════════════════════════════════════════════════════════════
   فصل ۱۱ — فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ (۳۱۸..۳۵۶)
   ══════════════════════════════════════════════════════════════════ */
export const drawSceneFasanuyassir: SceneDraw = (ctx, t, g, energy, accent, accent2) => {
  const cx = 640;

  // حروفِ تجزیه‌شده
  const parts = [
    { ar: 'فَـ', fa: 'پس', at: 2.5, x: 1080 },
    { ar: 'سَـ', fa: 'به‌زودی', at: 5.5, x: 880 },
    { ar: 'نُـ', fa: 'ما', at: 8.5, x: 700 },
    { ar: 'يَسِّرُهُ', fa: 'آسانش می‌کنیم', at: 11.5, x: 470 },
    { ar: 'لِلْيُسْرَىٰ', fa: 'برای آسانی', at: 15, x: 230 },
  ];
  parts.forEach((p) => {
    const prog = clamp01((t - p.at) / 1.3);
    if (prog <= 0) return;
    const y = 250 + (1 - easeOutBack(prog)) * 60;
    ctx.save();
    ctx.globalAlpha = prog;
    ctx.shadowColor = withAlpha(accent, 0.8);
    ctx.shadowBlur = 26 + energy * 20;
    drawGlowingText(
      ctx,
      p.ar,
      p.x,
      y,
      '700 62px "Amiri", serif',
      '#fde68a',
      withAlpha(accent, 0.85),
      28,
    );
    ctx.shadowBlur = 0;
    drawRoundedRect(ctx, p.x - 78, y + 44, 156, 38, 19);
    ctx.fillStyle = 'rgba(8, 13, 30, 0.9)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(accent2, 0.65);
    ctx.lineWidth = 1.4;
    ctx.stroke();
    drawGlowingText(
      ctx,
      p.fa,
      p.x,
      y + 63,
      '700 17px "Vazirmatn", sans-serif',
      '#a7f3d0',
      withAlpha(accent2, 0.5),
      8,
    );
    ctx.restore();

    // خطِ اتصال به مرکز
    ctx.save();
    ctx.globalAlpha = prog * 0.35;
    ctx.strokeStyle = withAlpha(accent, 0.8);
    ctx.setLineDash([4, 8]);
    ctx.lineWidth = 1.3;
    ctx.beginPath();
    ctx.moveTo(p.x, y + 92);
    ctx.lineTo(cx, 470);
    ctx.stroke();
    ctx.restore();
  });

  // حلقهٔ تکرار
  const repP = clamp01((t - 19) / 1.6);
  if (repP > 0) {
    ctx.save();
    ctx.globalAlpha = repP;
    ctx.translate(cx, 470);
    for (let i = 0; i < 3; i++) {
      const rr = 74 + i * 30 + Math.sin(g * 1.6 - i * 0.7) * 8 + energy * 16;
      ctx.strokeStyle = withAlpha(i % 2 === 0 ? accent : accent2, 0.55 - i * 0.12);
      ctx.lineWidth = 2.4 - i * 0.5;
      ctx.beginPath();
      ctx.arc(0, 0, rr, g * (0.5 + i * 0.22), g * (0.5 + i * 0.22) + Math.PI * 1.55);
      ctx.stroke();
    }
    drawGlowingText(
      ctx,
      'تکرار',
      0,
      -6,
      `800 ${Math.round(34 + energy * 6)}px "Vazirmatn", sans-serif`,
      '#fffbeb',
      withAlpha(accent, 0.9),
      24,
    );
    drawGlowingText(
      ctx,
      'هر روز • هر روز • هر روز',
      0,
      30,
      '600 16px "Vazirmatn", sans-serif',
      '#fde68a',
      'rgba(0,0,0,0)',
      0,
    );
    ctx.restore();

    // پالس‌های تکرارشونده
    for (let i = 0; i < 5; i++) {
      const ph = ((g * 0.55 + i * 0.2) % 1);
      ctx.save();
      ctx.globalAlpha = (1 - ph) * 0.5 * repP;
      ctx.strokeStyle = withAlpha(accent, 0.9);
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, 470, 130 + ph * 190, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
  }

  // گشایشِ راه (یُسری)
  const openP = clamp01((t - 25) / 5);
  if (openP > 0) {
    ctx.save();
    ctx.globalAlpha = 0.85;
    const gap = 26 + easeOutCubic(openP) * 250;
    const grd = ctx.createLinearGradient(0, 540, 0, 640);
    grd.addColorStop(0, withAlpha(accent2, 0.45));
    grd.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grd;
    ctx.beginPath();
    ctx.moveTo(cx - gap / 2, 560);
    ctx.lineTo(cx - gap / 2 - 240, 660);
    ctx.lineTo(cx + gap / 2 + 240, 660);
    ctx.lineTo(cx + gap / 2, 560);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = withAlpha(accent2, 0.7);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cx - gap / 2, 560);
    ctx.lineTo(cx - gap / 2 - 240, 660);
    ctx.moveTo(cx + gap / 2, 560);
    ctx.lineTo(cx + gap / 2 + 240, 660);
    ctx.stroke();
    ctx.restore();
    drawGlowingText(
      ctx,
      'گشایش',
      cx,
      576,
      `800 ${Math.round(24 * easeOutBack(openP))}px "Vazirmatn", sans-serif`,
      '#d1fae5',
      withAlpha(accent2, 0.7),
      16,
    );
  }

  drawVerseCard(
    ctx,
    cx,
    132,
    'فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ',
    'سورهٔ لیل • آیهٔ ۷',
    accent,
    clamp01(t / 2),
    620,
  );

  const nodes = [
    { x: 200, y: 190, glyph: 'أَعْطَىٰ', label: 'بخشش', at: 30 },
    { x: 1080, y: 190, glyph: 'اتَّقَىٰ', label: 'پرهیز', at: 32 },
  ];
  nodes.forEach((n) => {
    const p = clamp01((t - n.at) / 1.1);
    if (p <= 0) return;
    ctx.save();
    ctx.globalAlpha = p;
    drawRoundedRect(ctx, n.x - 78, n.y - 30, 156, 62, 14);
    ctx.fillStyle = 'rgba(7, 12, 28, 0.9)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(accent, 0.6);
    ctx.lineWidth = 1.5;
    ctx.stroke();
    drawGlowingText(ctx, n.glyph, n.x, n.y - 8, '700 22px "Amiri", serif', '#fde68a', withAlpha(accent, 0.6), 12);
    drawGlowingText(ctx, n.label, n.x, n.y + 18, '600 14px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
    ctx.restore();
  });
};

/* ══════════════════════════════════════════════════════════════════
   فصل ۱۲ — بذر، ریشه و نشانه (۳۵۶..۴۲۰)
   ══════════════════════════════════════════════════════════════════ */
export const drawSceneSeedSigns: SceneDraw = (ctx, t, g, energy, accent, accent2) => {
  const soilY = 400;
  const seedX = 520;

  // لایهٔ خاک
  ctx.save();
  const sg = ctx.createLinearGradient(0, soilY, 0, 660);
  sg.addColorStop(0, 'rgba(56, 36, 20, 0.85)');
  sg.addColorStop(1, 'rgba(20, 14, 10, 0.95)');
  ctx.fillStyle = sg;
  ctx.fillRect(0, soilY, 1280, 320);
  ctx.strokeStyle = withAlpha('#a16207', 0.45);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, soilY);
  for (let x = 0; x <= 1280; x += 24) ctx.lineTo(x, soilY + Math.sin(x * 0.02 + g * 0.3) * 3);
  ctx.stroke();
  // ذرات خاک
  for (let i = 0; i < 60; i++) {
    ctx.fillStyle = `rgba(180, 140, 90, ${0.08 + seeded(i) * 0.16})`;
    ctx.beginPath();
    ctx.arc(seeded(i * 3) * 1280, soilY + 12 + seeded(i * 7) * 240, 1 + seeded(i * 11) * 2.6, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();

  // بذر
  const seedP = easeOutBack(clamp01(t / 1.2));
  ctx.save();
  ctx.translate(seedX, soilY + 70);
  ctx.scale(seedP, seedP);
  ctx.fillStyle = '#fbbf24';
  ctx.shadowColor = '#fbbf24';
  ctx.shadowBlur = 18;
  ctx.beginPath();
  ctx.ellipse(0, 0, 15, 21, 0.35, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  drawGlowingText(
    ctx,
    'بذر',
    seedX - 76,
    soilY + 70,
    '700 17px "Vazirmatn", sans-serif',
    '#fde68a',
    withAlpha(accent2, 0.5),
    8,
    'right',
  );

  // ریشه‌های روینده
  const rootP = clamp01((t - 3) / 14);
  if (rootP > 0) {
    const growRoot = (x: number, y: number, ang: number, len: number, depth: number, seedIdx: number) => {
      if (depth <= 0 || len < 6) return;
      const ex = x + Math.cos(ang) * len * rootP;
      const ey = y + Math.sin(ang) * len * rootP;
      ctx.strokeStyle = withAlpha('#d6b98c', 0.28 + depth * 0.13);
      ctx.lineWidth = Math.max(0.7, depth * 0.7);
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.quadraticCurveTo(x + Math.cos(ang + 0.4) * len * 0.5, y + Math.sin(ang + 0.4) * len * 0.6, ex, ey);
      ctx.stroke();
      if (rootP > 0.6) {
        growRoot(ex, ey, ang - 0.5 - seeded(seedIdx) * 0.4, len * 0.66, depth - 1, seedIdx + 3);
        growRoot(ex, ey, ang + 0.5 + seeded(seedIdx + 1) * 0.4, len * 0.66, depth - 1, seedIdx + 7);
      }
    };
    ctx.save();
    growRoot(seedX, soilY + 84, Math.PI / 2, 74, 4, 1);
    growRoot(seedX - 6, soilY + 80, Math.PI / 2 + 0.5, 58, 3, 11);
    growRoot(seedX + 6, soilY + 80, Math.PI / 2 - 0.5, 58, 3, 21);
    ctx.restore();
    drawGlowingText(
      ctx,
      'در تاریکی ریشه می‌دواند…',
      seedX + 210,
      soilY + 150,
      '600 19px "Vazirmatn", sans-serif',
      '#e7d8bd',
      withAlpha(accent2, 0.35),
      8,
      'left',
    );
  }

  // ساقه و جوانه
  const sprout = clamp01((t - 16) / 6);
  if (sprout > 0) {
    const topY = lerp(soilY, soilY - 170, easeOutQuint(sprout));
    ctx.save();
    ctx.strokeStyle = accent;
    ctx.shadowColor = withAlpha(accent, 0.9);
    ctx.shadowBlur = 20;
    ctx.lineWidth = 5;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(seedX, soilY);
    ctx.quadraticCurveTo(seedX + Math.sin(g * 1.1) * 8, (soilY + topY) / 2, seedX + Math.sin(g * 1.1) * 12, topY);
    ctx.stroke();
    ctx.restore();

    // برگ‌ها
    const leaves = [
      { at: 0.35, dir: -1 },
      { at: 0.55, dir: 1 },
      { at: 0.78, dir: -1 },
    ];
    leaves.forEach((lv, i) => {
      const lp = clamp01((sprout - lv.at) / 0.25);
      if (lp <= 0) return;
      const ly = lerp(soilY, topY, lv.at);
      const lx = seedX + Math.sin(g * 1.1) * 12 * lv.at;
      ctx.save();
      ctx.translate(lx, ly);
      ctx.scale(easeOutBack(lp), easeOutBack(lp));
      ctx.rotate(lv.dir * (0.5 + Math.sin(g * 1.4 + i) * 0.08));
      const lg = ctx.createLinearGradient(0, 0, lv.dir * 66, 0);
      lg.addColorStop(0, withAlpha(accent, 0.95));
      lg.addColorStop(1, withAlpha('#16a34a', 0.6));
      ctx.fillStyle = lg;
      ctx.shadowColor = withAlpha(accent, 0.7);
      ctx.shadowBlur = 18;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(lv.dir * 40, -26, lv.dir * 66, 0);
      ctx.quadraticCurveTo(lv.dir * 40, 20, 0, 0);
      ctx.fill();
      ctx.restore();
    });

    // نورِ شکفتن
    const bloom = clamp01((sprout - 0.85) / 0.15);
    if (bloom > 0) {
      const bg2 = ctx.createRadialGradient(seedX, topY, 4, seedX, topY, 190);
      bg2.addColorStop(0, withAlpha(accent, 0.5 + energy * 0.2));
      bg2.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = bg2;
      ctx.beginPath();
      ctx.arc(seedX, topY, 190, 0, Math.PI * 2);
      ctx.fill();
    }

    drawKineticPill(ctx, seedX + 250, topY + 6, 'برگِ سبز = نشانه', sprout, accent, '✓', 1, 19);
  }

  // جمعیتِ بی‌توجه در برابرِ بیننده
  const crowdP = clamp01((t - 30) / 2);
  if (crowdP > 0) {
    ctx.save();
    ctx.globalAlpha = crowdP;
    for (let i = 0; i < 9; i++) {
      const x = 830 + i * 44;
      const y = 560 - (i % 3) * 14;
      ctx.fillStyle = 'rgba(71, 85, 105, 0.5)';
      ctx.beginPath();
      ctx.arc(x, y - 26, 9, 0, Math.PI * 2);
      ctx.fill();
      drawRoundedRect(ctx, x - 11, y - 16, 22, 40, 9);
      ctx.fill();
    }
    // بیننده
    const ox = 1206;
    ctx.fillStyle = accent2;
    ctx.shadowColor = withAlpha(accent2, 0.9);
    ctx.shadowBlur = 22;
    ctx.beginPath();
    ctx.arc(ox, 500, 12, 0, Math.PI * 2);
    ctx.fill();
    drawRoundedRect(ctx, ox - 14, 514, 28, 52, 10);
    ctx.fill();
    ctx.shadowBlur = 0;
    // خطِ دید
    ctx.strokeStyle = withAlpha(accent2, 0.7);
    ctx.setLineDash([6, 6]);
    ctx.lineWidth = 1.8;
    ctx.beginPath();
    ctx.moveTo(ox - 10, 498);
    ctx.lineTo(seedX + 40, soilY - 150);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
    drawNodeBadge(ctx, ox, 470, 15, '◉', accent2, crowdP);
    drawGlowingText(
      ctx,
      'من و تو می‌بینیم',
      ox - 10,
      576,
      '700 17px "Vazirmatn", sans-serif',
      '#fde68a',
      withAlpha(accent2, 0.5),
      10,
      'right',
    );
  }

  // ایستادنِ هرروزه
  const standP = clamp01((t - 46) / 2);
  if (standP > 0) {
    ctx.save();
    ctx.globalAlpha = standP;
    drawRoundedRect(ctx, 130, 150, 340, 92, 16);
    ctx.fillStyle = 'rgba(6, 12, 22, 0.86)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(accent, 0.6);
    ctx.lineWidth = 1.6;
    ctx.stroke();
    drawGlowingText(
      ctx,
      'هر روز از اولِ صبح بایست',
      300,
      182,
      '800 21px "Vazirmatn", sans-serif',
      '#f8fafc',
      withAlpha(accent, 0.55),
      12,
    );
    drawGlowingText(
      ctx,
      '۱ • ۲ • ۳ … تا پایانِ عمر',
      300,
      216,
      '600 16px "Vazirmatn", sans-serif',
      '#a7f3d0',
      'rgba(0,0,0,0)',
      0,
    );
    ctx.restore();
  }

  drawProgressRing(ctx, 110, 300, 22, clamp01(t / 64), accent, 4);
};
