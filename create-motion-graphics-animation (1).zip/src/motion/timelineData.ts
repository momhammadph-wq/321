/* ------------------------------------------------------------------
   timelineData.ts
   تایم‌لاین المان‌محور ۷ دقیقه‌ای (۴۲۰ ثانیه) + حالت روایت کامل
------------------------------------------------------------------ */

export type SceneKey =
  | 'dawn_tasdiq'
  | 'mind_gate'
  | 'city_abundance'
  | 'cosmos_tasbih'
  | 'seven_seas'
  | 'body_anfus'
  | 'mind_gym'
  | 'ten_minutes'
  | 'cinema_ghayb'
  | 'step_guidance'
  | 'fasanuyassir'
  | 'seed_signs';

export interface MotionChapter {
  id: number;
  sceneKey: SceneKey;
  title: string;
  subtitle: string;
  badge: string;
  /** زمان شروع/پایان روی تایم‌لاین بصری ۷ دقیقه‌ای */
  start: number;
  end: number;
  bgTop: string;
  bgBottom: string;
  accent: string;
  accentSecondary: string;
  verseAr?: string;
  verseRef?: string;
  /** آکورد موسیقی متنِ تولیدشده برای همین فصل */
  chord: number[];
}

export interface CaptionCue {
  start: number;
  end: number;
  text: string;
  highlight?: string;
}

/** فایل صوتی روایت (WhatsApp Ptt 2026-11-04) — ۱۸:۴۵ */
export const NARRATION_URL =
  'https://raw.githubusercontent.com/momhammadph-wq/321/main/01-WhatsApp%20Ptt%202026-11-04%20at%2012.00.55.ogg';

export const DURATION_7MIN = 420;
export const DURATION_FULL = 1125.38;

export const MOTION_CHAPTERS: MotionChapter[] = [
  {
    id: 1,
    sceneKey: 'dawn_tasdiq',
    title: 'طلوعِ تصدیق',
    subtitle: 'شکرِ اولِ صبح و دیدنِ نیکی‌ها از آغازِ روز',
    badge: 'فصل ۱',
    start: 0,
    end: 32,
    bgTop: '#10122e',
    bgBottom: '#2d1a3c',
    accent: '#fbbf24',
    accentSecondary: '#fb923c',
    verseAr: 'وَصَدَّقَ بِالْحُسْنَىٰ',
    verseRef: 'سورهٔ لیل • آیهٔ ۶',
    chord: [110, 164.81, 220, 329.63],
  },
  {
    id: 2,
    sceneKey: 'mind_gate',
    title: 'دروازهٔ ذهن',
    subtitle: 'نگهبانی از ورودی‌ها؛ تصدیق نه تکذیب',
    badge: 'فصل ۲',
    start: 32,
    end: 62,
    bgTop: '#08182e',
    bgBottom: '#122c4a',
    accent: '#38bdf8',
    accentSecondary: '#fbbf24',
    chord: [98, 146.83, 196, 293.66],
  },
  {
    id: 3,
    sceneKey: 'city_abundance',
    title: 'شهرِ فراوانی',
    subtitle: 'جریانِ ثروت، ساخت‌وساز و اشتغالِ مردم',
    badge: 'فصل ۳',
    start: 62,
    end: 96,
    bgTop: '#071c33',
    bgBottom: '#0e2a44',
    accent: '#fcd34d',
    accentSecondary: '#22d3ee',
    chord: [87.31, 130.81, 174.61, 261.63],
  },
  {
    id: 4,
    sceneKey: 'cosmos_tasbih',
    title: 'آفاقِ هستی',
    subtitle: 'تسبیحِ خورشید و ماه و ستاره؛ بسم‌الله و الحمدلله',
    badge: 'فصل ۴',
    start: 96,
    end: 128,
    bgTop: '#04152b',
    bgBottom: '#0a3436',
    accent: '#34d399',
    accentSecondary: '#fcd34d',
    verseAr: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ۝ الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
    verseRef: 'سورهٔ حمد • آیات ۱ و ۲',
    chord: [73.42, 110, 146.83, 220],
  },
  {
    id: 5,
    sceneKey: 'seven_seas',
    title: 'هفت دریا و درختانِ قلم',
    subtitle: 'بی‌کرانِ نعمت‌ها که شمرده نمی‌شود',
    badge: 'فصل ۵',
    start: 128,
    end: 158,
    bgTop: '#061a2b',
    bgBottom: '#0d2b45',
    accent: '#22d3ee',
    accentSecondary: '#f472b6',
    verseAr: 'وَلَوْ أَنَّمَا فِي الْأَرْضِ مِن شَجَرَةٍ أَقْلَامٌ وَالْبَحْرُ يَمُدُّهُ مِن بَعْدِهِ سَبْعَةُ أَبْحُرٍ',
    verseRef: 'سورهٔ لقمان • آیهٔ ۲۷',
    chord: [82.41, 123.47, 164.81, 246.94],
  },
  {
    id: 6,
    sceneKey: 'body_anfus',
    title: 'انفس؛ شگفتیِ درونِ جسم',
    subtitle: 'چشم و گوش و قلب و رگ‌ها؛ نعمت‌های بی‌قیمت',
    badge: 'فصل ۶',
    start: 158,
    end: 190,
    bgTop: '#1c0c26',
    bgBottom: '#12213f',
    accent: '#fb7185',
    accentSecondary: '#38bdf8',
    verseAr: 'وَفِي أَنفُسِكُمْ أَفَلَا تُبْصِرُونَ',
    verseRef: 'سورهٔ ذاریات • آیهٔ ۲۱',
    chord: [98, 146.83, 220, 293.66],
  },
  {
    id: 7,
    sceneKey: 'mind_gym',
    title: 'باشگاهِ روزانهٔ ذهن',
    subtitle: 'ورزشِ هرروزه با دیدنِ فراوانی‌ها',
    badge: 'فصل ۷',
    start: 190,
    end: 218,
    bgTop: '#171036',
    bgBottom: '#251a52',
    accent: '#a78bfa',
    accentSecondary: '#fbbf24',
    chord: [110, 164.81, 220, 261.63],
  },
  {
    id: 8,
    sceneKey: 'ten_minutes',
    title: 'ده دقیقهٔ صبحگاهی',
    subtitle: 'حضورِ آرام، نوشتنِ سه فراوانی و رفتن به کار',
    badge: 'فصل ۸',
    start: 218,
    end: 246,
    bgTop: '#1b1330',
    bgBottom: '#0d2436',
    accent: '#2dd4bf',
    accentSecondary: '#fde047',
    chord: [87.31, 130.81, 196, 261.63],
  },
  {
    id: 9,
    sceneKey: 'cinema_ghayb',
    title: 'سینمای غیب',
    subtitle: 'هدفِ سال: به تصویر کشیدنِ بُعدِ غیبی',
    badge: 'فصل ۹',
    start: 246,
    end: 286,
    bgTop: '#0b0c24',
    bgBottom: '#231642',
    accent: '#f59e0b',
    accentSecondary: '#c084fc',
    verseAr: 'يَهْدِي بِهِ اللَّهُ مَنِ اتَّبَعَ رِضْوَانَهُ سُبُلَ السَّلَامِ',
    verseRef: 'سورهٔ مائده • آیهٔ ۱۶',
    chord: [73.42, 110, 164.81, 220],
  },
  {
    id: 10,
    sceneKey: 'step_guidance',
    title: 'هدایتِ قدم‌به‌قدم',
    subtitle: 'هر روز یک قدم؛ قدمِ بعدی روشن می‌شود',
    badge: 'فصل ۱۰',
    start: 286,
    end: 318,
    bgTop: '#071b24',
    bgBottom: '#0c353b',
    accent: '#2dd4bf',
    accentSecondary: '#fbbf24',
    chord: [82.41, 123.47, 164.81, 246.94],
  },
  {
    id: 11,
    sceneKey: 'fasanuyassir',
    title: 'فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ',
    subtitle: 'فَـ یعنی پس، سَـ یعنی به‌زودی؛ با تکرارِ هرروزه',
    badge: 'فصل ۱۱',
    start: 318,
    end: 356,
    bgTop: '#150f2c',
    bgBottom: '#2b1c3f',
    accent: '#fbbf24',
    accentSecondary: '#34d399',
    verseAr: 'فَأَمَّا مَنْ أَعْطَىٰ وَاتَّقَىٰ ۝ وَصَدَّقَ بِالْحُسْنَىٰ ۝ فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ',
    verseRef: 'سورهٔ لیل • آیات ۵ تا ۷',
    chord: [110, 164.81, 220, 329.63],
  },
  {
    id: 12,
    sceneKey: 'seed_signs',
    title: 'بذر، ریشه و نشانه',
    subtitle: 'روییدنِ برگِ سبز؛ نشانه‌هایی که فقط بیننده می‌بیند',
    badge: 'فصل ۱۲',
    start: 356,
    end: 420,
    bgTop: '#081c18',
    bgBottom: '#123a26',
    accent: '#4ade80',
    accentSecondary: '#fbbf24',
    verseAr: 'فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ',
    verseRef: 'سورهٔ لیل • آیهٔ ۷',
    chord: [98, 146.81, 196, 293.66],
  },
];

export const CAPTIONS: CaptionCue[] = [
  { start: 0, end: 7.5, text: 'موشن گرافیک «صدّق بالحُسنی» • المان‌محور، ۷ دقیقه', highlight: 'صدّق بالحُسنی' },
  { start: 7.5, end: 15, text: 'صدّق بالحُسنی یعنی تصدیق کنی نیکی‌ها و خوبی‌ها را.' },
  { start: 15, end: 23, text: 'یعنی هر چه فراوانی و داشته است را ببینی و شکرگزاری کنی.' },
  { start: 23, end: 32, text: 'از اولِ صبح که برمی‌خیزی، روز را با شکرِ خدا آغاز کن.' },

  { start: 32, end: 39.5, text: 'ورودیِ ذهنت دروازه دارد؛ نگهبانِ آن خودت هستی.' },
  { start: 39.5, end: 47, text: 'تصدیق کن، نه تکذیب! هر چه را می‌بینی با فیلترِ نیکی ببین.' },
  { start: 47, end: 54.5, text: 'چشمِ تو دوربین است؛ هر چه را ورودی کنی همان را زندگی می‌کنی.' },
  { start: 54.5, end: 62, text: 'ذهن دنبالِ نشانه‌های همان چیزی می‌گردد که باور کرده‌ای.' },

  { start: 62, end: 70, text: 'در شهر هر روز ساختمان‌های تازه بالا می‌رود.' },
  { start: 70, end: 78.5, text: 'چقدر پول، چقدر ثروت، چقدر فراوانی در جریان است!' },
  { start: 78.5, end: 87, text: 'برای مردم شغل و اشتغال ساخته می‌شود؛ روزی‌ها جاری است.' },
  { start: 87, end: 96, text: 'این جریانِ ثروت را ورودیِ ذهن کن و بگو: فراوانی هست.' },

  { start: 96, end: 104, text: 'خورشید و ماه و ستاره‌ها، همه در تسبیحِ خدایند.' },
  { start: 104, end: 112, text: 'دریاها و کوه‌ها و معادن و دشت‌ها، همه نعمت‌اند.' },
  { start: 112, end: 120, text: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ؛ به نامِ خدایِ همهٔ نعمت‌ها.' },
  { start: 120, end: 128, text: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ؛ شکرِ خدایِ همهٔ عالم‌ها.' },

  { start: 128, end: 135.5, text: 'فراوانی‌ها را نمی‌توانی بشماری؛ آیه داریم که نمی‌توانی!' },
  { start: 135.5, end: 143, text: 'اگر هفت دریا مرکب شود و درختانِ زمین قلم…' },
  { start: 143, end: 150.5, text: 'که کلماتِ خدا را بنویسند، پیش از پایان تمام می‌شوند.' },
  { start: 150.5, end: 158, text: 'پس هر روز از بی‌کرانِ نعمت‌ها بگو و بنویس.' },

  { start: 158, end: 166, text: 'اول از درونِ جسمِ خودت ببین: چشم و گوش و قلب.' },
  { start: 166, end: 174, text: 'رگ‌ها، کلیه، کبد، دست‌ها و پاها؛ بی‌قیمت و گران‌بها.' },
  { start: 174, end: 182, text: 'تا نعمت‌های بیرونِ بدن را ببینی، اول درون را بشمار.' },
  { start: 182, end: 190, text: 'این شگفتیِ انفس است؛ نشانه‌ها در درونِ خودت هم هست.' },

  { start: 190, end: 197, text: 'ذهن هم مثلِ بدن ورزشِ هرروزه می‌خواهد.' },
  { start: 197, end: 204, text: 'انگار دمبل می‌زنی؛ هر روز فراوانی‌ها را ببین و بازگو کن.' },
  { start: 204, end: 211, text: 'تکرارِ روزانه، عضلهٔ شکرگزاری را قوی می‌کند.' },
  { start: 211, end: 218, text: 'باشگاهِ ذهن تعطیلی ندارد؛ هر روز، هر روز.' },

  { start: 218, end: 225, text: 'صبح که بیدار می‌شوی، ده دقیقه وقت بگذار.' },
  { start: 225, end: 232, text: 'آرام بنشین، نفس بکش و سه فراوانیِ امروز را بنویس.' },
  { start: 232, end: 239, text: 'با ذهنِ آرام برو سرِ کار.' },
  { start: 239, end: 246, text: 'در محلِ کار هم فراوانی‌ها را ببین و شکرش را بگو.' },

  { start: 246, end: 254, text: 'یک هدف در سال داشته باش؛ مثلاً به تصویر کشیدنِ غیب.' },
  { start: 254, end: 262, text: 'چیزی که با چشمِ سر دیده نمی‌شود.' },
  { start: 262, end: 270, text: 'تا امروز گفتار و منبر بوده؛ کسی غیب را به سینما نبرده است.' },
  { start: 270, end: 278, text: 'اگر بُعدِ غیبی را به تصویر بکشی، کاری کرده‌ای که در ۱۴۰۰ سال نشده.' },
  { start: 278, end: 286, text: 'معارف را به تصویر تبدیل کن؛ این جهادِ تبیین است.' },

  { start: 286, end: 294, text: 'هر روز یک قدم به تو گفته می‌شود.' },
  { start: 294, end: 302, text: 'قدمِ بعدی روشن می‌شود و تو هدایت می‌شوی.' },
  { start: 302, end: 310, text: 'یَهْدِي بِهِ اللَّهُ مَنِ اتَّبَعَ رِضْوَانَهُ سُبُلَ السَّلَامِ.' },
  { start: 310, end: 318, text: 'نشانه‌ها می‌آیند؛ همه‌چیز بُعدِ مادی نیست، بُعدِ غیبی است.' },

  { start: 318, end: 326, text: 'فَأَمَّا مَنْ أَعْطَىٰ وَاتَّقَىٰ وَصَدَّقَ بِالْحُسْنَىٰ.' },
  { start: 326, end: 334, text: 'فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ؛ پس به‌زودی او را برای آسانی آماده می‌کنیم.' },
  { start: 334, end: 342, text: 'فَـ یعنی پس، سَـ یعنی به‌زودی؛ یک‌دفعه نمی‌شود.' },
  { start: 342, end: 350, text: 'هی تکرار کن، تکرار کن، تا آسانی راه بیفتد.' },
  { start: 350, end: 356, text: 'هر روز کار کنیم، با آسانی‌ها آسان می‌شویم.' },

  { start: 356, end: 364, text: 'ریشه زدن مثلِ دانه زیرِ خاک دیده نمی‌شود.' },
  { start: 364, end: 372, text: 'در تاریکی هی ریشه می‌دواند، می‌دواند…' },
  { start: 372, end: 380, text: 'تا بعد برگِ سبز از خاک بیرون می‌زند.' },
  { start: 380, end: 388, text: 'اگر دیدی برگ سبز داد یا تکان خورد، این نشانه است.' },
  { start: 388, end: 396, text: 'این‌ها دستِ خداست؛ چه کسی می‌بیند؟ من و تو.' },
  { start: 396, end: 404, text: 'بقیه در جمعیت نمی‌بینند؛ تو بینندهٔ غیب باش.' },
  { start: 404, end: 412, text: 'هر روز، هر روز، از اولِ صبح‌ها بایست…' },
  {
    start: 412,
    end: 420,
    text: 'وَصَدَّقَ بِالْحُسْنَىٰ ۝ فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ',
    highlight: 'فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ',
  },
];

export function getChapterAtTime(t: number): MotionChapter {
  for (const ch of MOTION_CHAPTERS) {
    if (t >= ch.start && t < ch.end) return ch;
  }
  return t < 0 ? MOTION_CHAPTERS[0] : MOTION_CHAPTERS[MOTION_CHAPTERS.length - 1];
}

export function getChapterIndexAtTime(t: number): number {
  const ch = getChapterAtTime(t);
  return MOTION_CHAPTERS.findIndex((c) => c.id === ch.id);
}

/** نسبتِ زمانِ روایتِ کامل به تایم‌لاین بصری ۷ دقیقه‌ای */
export const FULL_TO_VISUAL = DURATION_7MIN / DURATION_FULL;

/**
 * تبدیل زمانِ پخشِ روایتِ کامل (۰..۱۱۲۵) به زمانِ بصری (۰..۴۲۰).
 * چون همهٔ فصل‌ها با یک نسبت فشرده می‌شوند، نگاشت خطی و فصل‌به‌فصل یکسان است.
 */
export function mapFullTimeToVisualTime(fullSec: number): number {
  return Math.max(0, Math.min(DURATION_7MIN, fullSec * FULL_TO_VISUAL));
}

/** زمان بصری (۰..۴۲۰) از روی زمان پخش و حالت */
export function resolveVisualTime(playTime: number, mode: '7min' | 'full'): number {
  return mode === '7min' ? Math.min(DURATION_7MIN, playTime) : mapFullTimeToVisualTime(playTime);
}

export function getCaptionAtTime(visualT: number): CaptionCue | null {
  return CAPTIONS.find((c) => visualT >= c.start && visualT < c.end) ?? null;
}

export function getModeDuration(mode: '7min' | 'full'): number {
  return mode === '7min' ? DURATION_7MIN : DURATION_FULL;
}
