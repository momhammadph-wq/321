/* ------------------------------------------------------------------
   uploader.ts
   آپلودِ فایل MP4 ساخته‌شده روی سرویس‌های عمومیِ اشتراک فایل
   (tmpfiles.org و gofile.io) تا لینکِ دانلودِ مستقیم بگیرید.
------------------------------------------------------------------ */

export interface HostedLink {
  host: 'tmpfiles.org' | 'gofile.io';
  /** صفحهٔ دانلود */
  pageUrl: string;
  /** لینکِ مستقیمِ فایل (در صورت وجود) */
  directUrl: string | null;
  note: string;
}

export type UploadProgress = (percent: number, loadedMB: number, totalMB: number) => void;

function postForm(url: string, file: Blob, filename: string, onProgress?: UploadProgress, headers?: Record<string, string>) {
  return new Promise<{ status: number; text: string }>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const form = new FormData();
    form.append('file', file, filename);
    xhr.open('POST', url, true);
    Object.entries(headers ?? {}).forEach(([k, v]) => xhr.setRequestHeader(k, v));
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable)
        onProgress?.((e.loaded / e.total) * 100, e.loaded / 1048576, e.total / 1048576);
    };
    xhr.onload = () => resolve({ status: xhr.status, text: xhr.responseText });
    xhr.onerror = () => reject(new Error('خطای شبکه در ارسال فایل (CORS یا قطعی اینترنت).'));
    xhr.ontimeout = () => reject(new Error('زمانِ ارسال فایل به پایان رسید.'));
    xhr.timeout = 15 * 60 * 1000;
    xhr.send(form);
  });
}

/** tmpfiles.org — لینکِ مستقیم با افزودن /dl/ ساخته می‌شود و ۶۰ دقیقه اعتبار دارد */
export async function uploadToTmpfiles(
  blob: Blob,
  filename: string,
  onProgress?: UploadProgress,
): Promise<HostedLink> {
  const res = await postForm('https://tmpfiles.org/api/v1/upload', blob, filename, onProgress);
  let json: { status?: string; data?: { url?: string } } = {};
  try {
    json = JSON.parse(res.text);
  } catch {
    /* noop */
  }
  if (res.status !== 200 || json.status !== 'success' || !json.data?.url) {
    throw new Error(`tmpfiles.org پاسخ نداد (کد ${res.status}). دوباره تلاش کنید یا از gofile.io استفاده کنید.`);
  }
  const page = json.data.url;
  return {
    host: 'tmpfiles.org',
    pageUrl: page,
    // tmpfiles لینکِ مستقیم را هنگامِ بازدید از صفحه به‌صورتِ امضاشده و زمان‌دار می‌سازد
    directUrl: null,
    note: 'صفحه را باز کنید و دکمهٔ Download را بزنید (فایل حدوداً ۶۰ دقیقه نگه‌داری می‌شود).',
  };
}

async function gofileGuestToken(): Promise<string | null> {
  try {
    const r = await fetch('https://api.gofile.io/accounts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
    const j = (await r.json()) as { status?: string; data?: { token?: string } };
    return j.data?.token ?? null;
  } catch {
    return null;
  }
}

/** gofile.io — لینکِ دائمی‌تر همراه با صفحهٔ دانلود */
export async function uploadToGofile(
  blob: Blob,
  filename: string,
  onProgress?: UploadProgress,
): Promise<HostedLink> {
  const serversRes = await fetch('https://api.gofile.io/servers');
  const serversJson = (await serversRes.json()) as { data?: { servers?: Array<{ name: string }> } };
  const server = serversJson.data?.servers?.[0]?.name;
  if (!server) throw new Error('gofile.io سرورِ آپلودی در اختیار نگذاشت.');

  const token = await gofileGuestToken();
  const url = `https://${server}.gofile.io/contents/uploadfile`;
  const headers: Record<string, string> = {};
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await postForm(url, blob, filename, onProgress, headers);
  let json: {
    status?: string;
    data?: { downloadPage?: string; directLink?: string; code?: string };
  } = {};
  try {
    json = JSON.parse(res.text);
  } catch {
    /* noop */
  }
  if (json.status !== 'ok' || !json.data?.downloadPage) {
    throw new Error(
      `gofile.io آپلود را نپذیرفت (${json.status ?? 'HTTP ' + res.status}). از tmpfiles.org استفاده کنید.`,
    );
  }
  return {
    host: 'gofile.io',
    pageUrl: json.data.downloadPage,
    directUrl: json.data.directLink ?? null,
    note: json.data.code
      ? `کدِ دسترسی پوشه: ${json.data.code} — فایل‌های بلااستفاده پس از مدتی پاک می‌شوند.`
      : 'صفحهٔ دانلودِ gofile.',
  };
}
