/* ------------------------------------------------------------------
   fx.ts — افکت‌های تکمیلی اپیزود ۲ (تسلیم)
   همهٔ متن‌ها کامل رسم می‌شوند (نه حرف‌به‌حرف) تا اتصال حروف فارسی حفظ شود.
------------------------------------------------------------------ */
import {
  clamp01,
  drawRoundedRect,
  easeOutBack,
  easeOutCubic,
  seeded,
  withAlpha,
} from '../motion/drawPrimitives';

/** آشکارسازی متن با پردهٔ نوری از راست به چپ (سازگار با RTL و اتصال حروف) */
export function drawWipeText(
  ctx: CanvasRenderingContext2D,
  text: string,
  cx: number,
  cy: number,
  font: string,
  fill: string,
  glow: string,
  progress: number,
  glowBlur = 22,
) {
  const p = clamp01(progress);
  if (p <= 0) return;
  ctx.save();
  ctx.font = font;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const w = ctx.measureText(text).width + 40;
  const size = Number(/(\d+)px/.exec(font)?.[1] ?? 30);
  const h = size * 2;
  const right = cx + w / 2;
  const revealW = w * easeOutCubic(p);
  ctx.beginPath();
  ctx.rect(right - revealW, cy - h / 2, revealW, h);
  ctx.clip();
  ctx.shadowColor = glow;
  ctx.shadowBlur = glowBlur;
  ctx.fillStyle = fill;
  ctx.fillText(text, cx, cy);
  ctx.restore();
  // لبهٔ نورانیِ پرده
  if (p < 1) {
    const ex = right - revealW;
    ctx.save();
    const g = ctx.createLinearGradient(ex - 18, 0, ex + 18, 0);
    g.addColorStop(0, 'rgba(255,255,255,0)');
    g.addColorStop(0.5, withAlpha('#fde68a', 0.85));
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.fillRect(ex - 18, cy - h / 2, 36, h);
    ctx.restore();
  }
}

/** متن با پاپ‌شدنِ نرم (مقیاس + محوشدن) */
export function drawPopText(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  font: string,
  fill: string,
  glow: string,
  progress: number,
  blur = 18,
) {
  const p = clamp01(progress);
  if (p <= 0) return;
  ctx.save();
  ctx.translate(x, y);
  const s = easeOutBack(p);
  ctx.scale(s, s);
  ctx.globalAlpha *= clamp01(p * 1.6);
  ctx.font = font;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = glow;
  ctx.shadowBlur = blur;
  ctx.fillStyle = fill;
  ctx.fillText(text, 0, 0);
  ctx.restore();
}

/** شعله‌های رویه‌ای */
export function drawFlames(
  ctx: CanvasRenderingContext2D,
  cx: number,
  baseY: number,
  width: number,
  height: number,
  t: number,
  intensity: number,
  coolMix = 0,
) {
  const n = 22;
  for (let i = 0; i < n; i++) {
    const k = i / (n - 1);
    const x = cx - width / 2 + k * width;
    const center = 1 - Math.abs(k - 0.5) * 2;
    const flick = 0.6 + 0.4 * Math.sin(t * (6 + seeded(i) * 5) + i * 1.7);
    const h = height * (0.35 + center * 0.75) * flick * intensity;
    if (h < 2) continue;
    const g = ctx.createLinearGradient(x, baseY, x, baseY - h);
    if (coolMix < 0.5) {
      g.addColorStop(0, `rgba(251, 146, 60, ${0.85 * (1 - coolMix)})`);
      g.addColorStop(0.5, `rgba(250, 204, 21, ${0.6 * (1 - coolMix)})`);
      g.addColorStop(1, 'rgba(254, 240, 138, 0)');
    } else {
      g.addColorStop(0, `rgba(74, 222, 128, ${0.7 * coolMix})`);
      g.addColorStop(0.5, `rgba(134, 239, 172, ${0.45 * coolMix})`);
      g.addColorStop(1, 'rgba(220, 252, 231, 0)');
    }
    ctx.fillStyle = g;
    const w = (width / n) * 1.9;
    ctx.beginPath();
    ctx.moveTo(x - w / 2, baseY);
    ctx.quadraticCurveTo(x - w * 0.6, baseY - h * 0.5, x + Math.sin(t * 3 + i) * 6, baseY - h);
    ctx.quadraticCurveTo(x + w * 0.6, baseY - h * 0.5, x + w / 2, baseY);
    ctx.closePath();
    ctx.fill();
  }
}

/** گل رویه‌ای */
export function drawFlower(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  color: string,
  rot: number,
  p: number,
) {
  const s = easeOutBack(clamp01(p));
  if (s <= 0.02) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(s, s);
  ctx.fillStyle = withAlpha(color, 0.9);
  ctx.shadowColor = withAlpha(color, 0.7);
  ctx.shadowBlur = 12;
  for (let i = 0; i < 6; i++) {
    ctx.rotate(Math.PI / 3);
    ctx.beginPath();
    ctx.ellipse(r * 0.6, 0, r * 0.6, r * 0.28, 0, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.shadowBlur = 0;
  ctx.fillStyle = '#fde68a';
  ctx.beginPath();
  ctx.arc(0, 0, r * 0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/** کارت شیشه‌ای */
export function drawGlassCard(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  accent: string,
  alpha = 1,
) {
  ctx.save();
  ctx.globalAlpha *= alpha;
  ctx.shadowColor = withAlpha(accent, 0.35);
  ctx.shadowBlur = 26;
  drawRoundedRect(ctx, x, y, w, h, 18);
  ctx.fillStyle = 'rgba(7, 11, 26, 0.84)';
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = withAlpha(accent, 0.55);
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.restore();
}

/** سیلوئتِ ساده انسان */
export function drawFigure(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  s: number,
  color: string,
  glow = 0,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.fillStyle = color;
  if (glow > 0) {
    ctx.shadowColor = color;
    ctx.shadowBlur = glow;
  }
  ctx.beginPath();
  ctx.arc(0, -46, 13, 0, Math.PI * 2);
  ctx.fill();
  drawRoundedRect(ctx, -15, -30, 30, 58, 12);
  ctx.fill();
  ctx.restore();
}

/** ستارهٔ هشت‌پر */
export function drawStar8(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  color: string,
  rot: number,
  fill = true,
) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.beginPath();
  for (let i = 0; i < 16; i++) {
    const a = (i * Math.PI) / 8;
    const rr = i % 2 === 0 ? r : r * 0.55;
    const px = Math.cos(a) * rr;
    const py = Math.sin(a) * rr;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
  if (fill) {
    ctx.fillStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = 18;
    ctx.fill();
  } else {
    ctx.strokeStyle = color;
    ctx.lineWidth = 1.6;
    ctx.stroke();
  }
  ctx.restore();
}

/** امواج رادیویی از یک نقطه */
export function drawRadioWaves(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  t: number,
  color: string,
  maxR: number,
  dir: 1 | -1 = 1,
  count = 5,
) {
  for (let i = 0; i < count; i++) {
    const ph = (t * 0.6 + i / count) % 1;
    const r = (dir === 1 ? ph : 1 - ph) * maxR;
    ctx.save();
    ctx.globalAlpha *= (1 - ph) * 0.8;
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(x, y, Math.max(1, r), 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
}
