import {
  clamp01,
  drawCosmicParticles,
  drawGlowingText,
  drawRoundedRect,
  drawSacredMandala,
  drawSpectrumBars,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  formatTimeFa,
  lerpColor,
  toFaDigits,
  withAlpha,
} from '../motion/drawPrimitives';
import type { Scene2 } from './scenesA';
import { sceneIbrahimFire, sceneIbrahimIdols, sceneProphetsOrbit, sceneTasleemKey } from './scenesA';
import {
  sceneAllKnowing,
  sceneEnergyWater,
  sceneHeartGps,
  sceneMindBrain,
  sceneMindRadio,
  sceneSadaqa,
  sceneSelfIdol,
  sceneSignsReturn,
  sceneSixSteps,
} from './scenesB';
import { sceneGhaybVision, sceneSteadfast } from './scenesC';
import {
  EP2_CHAPTERS,
  EP2_DURATION,
  getEp2Caption,
  getEp2Chapter,
  type Ep2SceneKey,
} from './timeline2';

const VW = 1280;
const VH = 720;

const SCENES: Record<Ep2SceneKey, Scene2> = {
  tasleem_key: sceneTasleemKey,
  prophets_orbit: sceneProphetsOrbit,
  ibrahim_idols: sceneIbrahimIdols,
  ibrahim_fire: sceneIbrahimFire,
  self_idol: sceneSelfIdol,
  mind_radio: sceneMindRadio,
  mind_brain: sceneMindBrain,
  signs_return: sceneSignsReturn,
  energy_water: sceneEnergyWater,
  six_steps: sceneSixSteps,
  heart_gps: sceneHeartGps,
  all_knowing: sceneAllKnowing,
  sadaqa: sceneSadaqa,
  ghayb_vision: sceneGhaybVision,
  steadfast: sceneSteadfast,
};

export interface Ep2RenderOptions {
  showSubtitles: boolean;
  showHud: boolean;
}

function wrap(ctx: CanvasRenderingContext2D, text: string, max: number): string[] {
  const words = text.split(' ');
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    const test = cur ? `${cur} ${w}` : w;
    if (ctx.measureText(test).width <= max) cur = test;
    else {
      if (cur) lines.push(cur);
      cur = w;
    }
  }
  if (cur) lines.push(cur);
  return lines.slice(0, 2);
}

export function drawEp2Frame(
  ctx: CanvasRenderingContext2D,
  t: number,
  pw: number,
  ph: number,
  energy: number,
  opts: Ep2RenderOptions,
) {
  const ch = getEp2Chapter(t);
  const idx = EP2_CHAPTERS.findIndex((c) => c.id === ch.id);
  const next = EP2_CHAPTERS[Math.min(EP2_CHAPTERS.length - 1, idx + 1)];
  const toEnd = ch.end - t;
  const blend = toEnd < 2 && next.id !== ch.id ? easeInOutCubic(1 - toEnd / 2) : 0;
  const accent = blend > 0.5 ? next.accent : ch.accent;
  const accent2 = blend > 0.5 ? next.accentSecondary : ch.accentSecondary;

  ctx.save();
  ctx.scale(pw / VW, ph / VH);
  if ('direction' in ctx) ctx.direction = 'rtl';

  const bg = ctx.createLinearGradient(0, 0, 0, VH);
  bg.addColorStop(0, lerpColor(ch.bgTop, next.bgTop, blend));
  bg.addColorStop(1, lerpColor(ch.bgBottom, next.bgBottom, blend));
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, VW, VH);

  const rad = ctx.createRadialGradient(640, 340, 40, 640, 340, 780);
  rad.addColorStop(0, withAlpha(accent, 0.12 + energy * 0.1));
  rad.addColorStop(1, 'rgba(3, 6, 18, 0.66)');
  ctx.fillStyle = rad;
  ctx.fillRect(0, 0, VW, VH);

  drawSacredMandala(ctx, 640, 352, 320, t * 0.035, accent, 0.065);
  drawSacredMandala(ctx, 640, 352, 210, -t * 0.05, accent2, 0.055);
  drawCosmicParticles(ctx, VW, VH, t, accent, energy);

  // صحنه
  const local = Math.max(0, t - ch.start);
  const fadeIn = clamp01(local / 0.8);
  const fadeOut = toEnd < 0.7 && next.id !== ch.id ? clamp01(toEnd / 0.7) : 1;
  ctx.save();
  ctx.globalAlpha = Math.min(fadeIn, fadeOut);
  SCENES[ch.sceneKey](ctx, local, ch.end - ch.start, t, energy, ch.accent, ch.accentSecondary);
  ctx.restore();

  // فلشِ انتقالِ فصل
  if (local < 0.6 && idx > 0) {
    ctx.save();
    ctx.globalAlpha = (1 - local / 0.6) * 0.35;
    ctx.fillStyle = ch.accent;
    ctx.fillRect(0, 0, VW, VH);
    ctx.restore();
  }

  const vig = ctx.createRadialGradient(640, 360, 260, 640, 360, 820);
  vig.addColorStop(0, 'rgba(0,0,0,0)');
  vig.addColorStop(1, 'rgba(2, 4, 12, 0.72)');
  ctx.fillStyle = vig;
  ctx.fillRect(0, 0, VW, VH);

  // کارتِ آغاز
  if (t < 4) {
    const al = t < 3 ? 1 : 1 - clamp01((t - 3) / 1);
    const pop = easeOutBack(clamp01(t / 0.8));
    ctx.save();
    ctx.globalAlpha = al;
    ctx.fillStyle = 'rgba(5, 8, 18, 0.8)';
    ctx.fillRect(0, 0, VW, VH);
    ctx.translate(640, 330);
    ctx.scale(pop, pop);
    drawSacredMandala(ctx, 0, 0, 210, t * 0.5, '#fbbf24', 0.2);
    drawGlowingText(ctx, 'تسلیم', 0, -52, '900 86px "Vazirmatn", sans-serif', '#fde68a', 'rgba(251,191,36,0.7)', 34);
    drawGlowingText(ctx, 'رمزِ موفقیتِ پیامبران', 0, 26, '700 28px "Vazirmatn", sans-serif', '#e2e8f0', 'rgba(56,189,248,0.4)', 12);
    drawGlowingText(ctx, 'موشن گرافیکِ المان‌محور • ۱۵ فصل • ۱۴:۴۰', 0, 74, '500 19px "Vazirmatn", sans-serif', '#94a3b8', 'rgba(0,0,0,0)', 0);
    ctx.restore();
  }

  // تیتراژِ پایانی
  if (t > EP2_DURATION - 11) {
    const cp = easeOutCubic(clamp01((t - (EP2_DURATION - 11)) / 2.5));
    ctx.save();
    ctx.globalAlpha = cp * 0.96;
    ctx.fillStyle = 'rgba(4, 8, 18, 0.86)';
    ctx.fillRect(0, 0, VW, VH);
    drawSacredMandala(ctx, 640, 300, 230, t * 0.14, '#fbbf24', 0.22);
    drawSacredMandala(ctx, 640, 300, 150, -t * 0.2, '#4ade80', 0.18);
    drawGlowingText(ctx, 'تسلیم ← هدایت ← گشایش', 640, 250, '900 50px "Vazirmatn", sans-serif', '#fde68a', 'rgba(251,191,36,0.65)', 28);
    drawGlowingText(ctx, 'وَصَدَّقَ بِالْحُسْنَىٰ ۝ فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ', 640, 330, '700 38px "Amiri", serif', '#bbf7d0', 'rgba(74,222,128,0.5)', 20);
    drawGlowingText(ctx, 'شش گام: تسلیم • ورودیِ ذهن • فرکانس • سیستمِ جهان • هدایت • تصدیق', 640, 400, '600 20px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
    ctx.restore();
  }

  // HUD
  if (opts.showHud) {
    const top = ctx.createLinearGradient(0, 0, 0, 84);
    top.addColorStop(0, 'rgba(4, 7, 18, 0.82)');
    top.addColorStop(1, 'rgba(4, 7, 18, 0)');
    ctx.fillStyle = top;
    ctx.fillRect(0, 0, VW, 84);

    ctx.save();
    ctx.font = '700 16px "Vazirmatn", sans-serif';
    const label = `فصل ${toFaDigits(ch.id)}  •  ${ch.title}`;
    const bw = Math.min(640, ctx.measureText(label).width + 50);
    drawRoundedRect(ctx, VW - bw - 32, 20, bw, 40, 20);
    ctx.fillStyle = 'rgba(10, 16, 34, 0.8)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(ch.accent, 0.62);
    ctx.lineWidth = 1.4;
    ctx.stroke();
    ctx.fillStyle = ch.accent;
    ctx.beginPath();
    ctx.arc(VW - 50, 40, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#f1f5f9';
    ctx.fillText(label, VW - 66, 41);
    ctx.restore();

    ctx.save();
    drawRoundedRect(ctx, 32, 20, 172, 40, 20);
    ctx.fillStyle = 'rgba(10, 16, 34, 0.8)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.32)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.font = '700 15px "Vazirmatn", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#e2e8f0';
    ctx.fillText(`${formatTimeFa(t)} / ${formatTimeFa(EP2_DURATION)}`, 118, 41);
    ctx.restore();

    drawSpectrumBars(ctx, 330, 60, 26, 190, t, energy, ch.accent, 0.5);

    const pct = clamp01(t / EP2_DURATION);
    ctx.fillStyle = 'rgba(255,255,255,0.09)';
    ctx.fillRect(0, 0, VW, 5);
    const bar = ctx.createLinearGradient(VW, 0, 0, 0);
    bar.addColorStop(0, ch.accent);
    bar.addColorStop(1, ch.accentSecondary);
    ctx.fillStyle = bar;
    ctx.fillRect(VW * (1 - pct), 0, VW * pct, 5);
    EP2_CHAPTERS.forEach((c) => {
      ctx.fillStyle = 'rgba(2, 6, 16, 0.85)';
      ctx.fillRect(VW * (1 - c.start / EP2_DURATION) - 1, 0, 2, 5);
    });
    ctx.font = '600 13px "Vazirmatn", sans-serif';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(203, 213, 225, 0.75)';
    ctx.fillText(`فصل ${toFaDigits(ch.id)} از ${toFaDigits(EP2_CHAPTERS.length)}`, 32, 76);
  }

  // زیرنویس
  if (opts.showSubtitles) {
    const cue = getEp2Caption(t);
    if (cue) {
      const cp = clamp01((t - cue.start) / 0.45);
      ctx.save();
      ctx.globalAlpha = easeOutCubic(cp);
      ctx.translate(0, (1 - easeOutCubic(cp)) * 18);
      ctx.font = '600 23px "Vazirmatn", sans-serif';
      const lines = wrap(ctx, cue.text, 940);
      const boxH = lines.length === 2 ? 82 : 54;
      const boxY = VH - boxH - 24;
      const boxW = Math.min(1060, Math.max(...lines.map((l) => ctx.measureText(l).width)) + 78);
      const boxX = (VW - boxW) / 2;
      drawRoundedRect(ctx, boxX, boxY, boxW, boxH, 20);
      ctx.fillStyle = 'rgba(5, 9, 22, 0.86)';
      ctx.fill();
      ctx.strokeStyle = withAlpha(ch.accent, 0.5);
      ctx.lineWidth = 1.4;
      ctx.stroke();
      ctx.fillStyle = ch.accent;
      ctx.fillRect(boxX + boxW - 4, boxY + 12, 4, boxH - 24);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.shadowColor = 'rgba(0,0,0,0.65)';
      ctx.shadowBlur = 10;
      ctx.fillStyle = cue.highlight ? '#fde68a' : '#f8fafc';
      if (lines.length === 1) ctx.fillText(lines[0], 640, boxY + boxH / 2 + 1);
      else {
        ctx.fillText(lines[0], 640, boxY + 25);
        ctx.fillText(lines[1], 640, boxY + 57);
      }
      ctx.restore();
    }
  }
  ctx.restore();
}
