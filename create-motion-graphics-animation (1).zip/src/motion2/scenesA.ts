import {
  clamp01,
  drawAudioAuraRing,
  drawGlowingText,
  drawKineticPill,
  drawNodeBadge,
  drawOrbitRing,
  drawRoundedRect,
  drawVerseCard,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  easeOutQuint,
  lerp,
  seeded,
  withAlpha,
} from '../motion/drawPrimitives';
import { drawFigure, drawFlames, drawFlower, drawGlassCard, drawPopText, drawStar8, drawWipeText } from './fx';

/** t = زمانِ محلی، d = طولِ فصل، g = زمانِ کل، e = انرژیِ صدا */
export type Scene2 = (
  ctx: CanvasRenderingContext2D,
  t: number,
  d: number,
  g: number,
  e: number,
  a: string,
  b: string,
) => void;

/* ══════════ ۱ — دروازهٔ تسلیم: کلید و قفل ══════════ */
export const sceneTasleemKey: Scene2 = (ctx, t, d, g, e, a, b) => {
  const cx = 640;
  const cy = 330;
  // درِ طاق‌دار
  const doorP = easeOutCubic(clamp01((t - 0.5) / 2.5));
  const open = easeInOutCubic(clamp01((t - d * 0.45) / 4));
  ctx.save();
  ctx.globalAlpha = doorP;
  const dw = 230;
  const dh = 300;
  // نورِ پشتِ در
  const lg = ctx.createRadialGradient(cx, cy, 10, cx, cy, 260);
  lg.addColorStop(0, withAlpha(a, 0.15 + open * 0.55 + e * 0.1));
  lg.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = lg;
  ctx.fillRect(cx - 300, cy - 260, 600, 520);
  // قاب
  ctx.strokeStyle = withAlpha(a, 0.85);
  ctx.lineWidth = 3;
  ctx.shadowColor = withAlpha(a, 0.6);
  ctx.shadowBlur = 20;
  ctx.beginPath();
  ctx.moveTo(cx - dw / 2, cy + dh / 2);
  ctx.lineTo(cx - dw / 2, cy - dh / 2 + dw / 2);
  ctx.arc(cx, cy - dh / 2 + dw / 2, dw / 2, Math.PI, 0);
  ctx.lineTo(cx + dw / 2, cy + dh / 2);
  ctx.stroke();
  ctx.shadowBlur = 0;
  // لنگه‌ها
  [-1, 1].forEach((s) => {
    const leafW = (dw / 2 - 6) * (1 - open * 0.92);
    ctx.fillStyle = 'rgba(14, 20, 44, 0.95)';
    ctx.strokeStyle = withAlpha(a, 0.45);
    ctx.lineWidth = 1.4;
    const x0 = s === -1 ? cx - dw / 2 + 4 : cx + dw / 2 - 4 - leafW;
    drawRoundedRect(ctx, x0, cy - dh / 2 + 40, leafW, dh - 44, 6);
    ctx.fill();
    ctx.stroke();
    // نقشِ هندسی روی لنگه
    if (leafW > 30) {
      drawStar8(ctx, x0 + leafW / 2, cy - 10, Math.min(28, leafW * 0.3), withAlpha(a, 0.5), g * 0.2, false);
    }
  });
  ctx.restore();

  // کلیدِ نورانی که به قفل می‌رسد
  const keyP = easeOutQuint(clamp01((t - 3) / (d * 0.35)));
  const kx = lerp(1120, cx + 6, keyP);
  const ky = lerp(560, cy + 20, keyP) + Math.sin(g * 2) * (1 - keyP) * 10;
  if (t > 3 && open < 0.98) {
    ctx.save();
    ctx.translate(kx, ky);
    ctx.rotate(lerp(-0.6, 0, keyP) + open * Math.PI * 0.5);
    ctx.strokeStyle = b;
    ctx.fillStyle = b;
    ctx.shadowColor = b;
    ctx.shadowBlur = 22 + e * 14;
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(46, 0, 18, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(28, 0);
    ctx.lineTo(-30, 0);
    ctx.stroke();
    ctx.fillRect(-30, 0, 8, 14);
    ctx.fillRect(-14, 0, 8, 10);
    ctx.restore();
  }

  // تیتر
  drawWipeText(ctx, 'تسلیم', cx, 136, '800 64px "Vazirmatn", sans-serif', '#fef3c7', withAlpha(a, 0.8), clamp01((t - 1) / 2.2), 30);
  drawPopText(ctx, 'کلیدِ گشایشِ زندگی', cx, 194, '600 22px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', clamp01((t - 2.6) / 1));

  // پرتوهای پس از باز شدن
  if (open > 0.05) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.globalAlpha = open * 0.7;
    for (let i = 0; i < 14; i++) {
      const ang = -Math.PI / 2 + (i - 6.5) * 0.12;
      const len = 260 + Math.sin(g * 2 + i) * 30;
      const gr = ctx.createLinearGradient(0, 0, Math.cos(ang) * len, Math.sin(ang) * len);
      gr.addColorStop(0, withAlpha(a, 0.5));
      gr.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.strokeStyle = gr;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(0, 60);
      ctx.lineTo(Math.cos(ang + Math.PI) * -len, Math.sin(ang + Math.PI) * -len + 60);
      ctx.stroke();
    }
    ctx.restore();
    drawPopText(ctx, 'اسلام = تسلیم', cx, cy + 10, '800 34px "Vazirmatn", sans-serif', '#ffffff', withAlpha(a, 0.9), clamp01((open - 0.4) / 0.4), 26);
  }

  const pills = [
    { x: 250, y: 260, l: 'رمزِ موفقیتِ پیامبران', i: '✦', at: 6 },
    { x: 1030, y: 260, l: 'رها کردنِ منیّت', i: '◈', at: 10 },
    { x: 250, y: 430, l: 'اعتماد به خواستِ خدا', i: '♥', at: 14 },
    { x: 1030, y: 430, l: 'آغازِ گشایش', i: '☀', at: 18 },
  ];
  pills.forEach((p) => {
    const pr = clamp01((t - p.at) / 1);
    if (pr > 0) drawKineticPill(ctx, p.x, p.y + Math.sin(g * 2 + p.x) * 5, p.l, pr, a, p.i, 0.95, 19);
  });
};

/* ══════════ ۲ — منظومهٔ پیامبران ══════════ */
const PROPHETS = [
  { n: 'یونس', s: 'از دلِ نهنگ' },
  { n: 'یوسف', s: 'از چاه تا عزّت' },
  { n: 'ابراهیم', s: 'از آتش تا گلستان' },
  { n: 'موسی', s: 'شکافتنِ دریا' },
  { n: 'عیسی', s: 'کلمةُ الله' },
  { n: 'محمد ﷺ', s: 'خاتمِ پیامبران' },
];
export const sceneProphetsOrbit: Scene2 = (ctx, t, d, g, e, a, b) => {
  const cx = 640;
  const cy = 340;
  drawAudioAuraRing(ctx, cx, cy, 70, g, e, a);
  ctx.save();
  const core = ctx.createRadialGradient(cx - 10, cy - 10, 5, cx, cy, 64);
  core.addColorStop(0, '#fffbeb');
  core.addColorStop(0.6, a);
  core.addColorStop(1, withAlpha(a, 0.3));
  ctx.fillStyle = core;
  ctx.beginPath();
  ctx.arc(cx, cy, 62 + e * 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  drawGlowingText(ctx, 'تسلیم', cx, cy + 2, '800 30px "Vazirmatn", sans-serif', '#1c1305', 'rgba(255,255,255,0.6)', 6);

  drawOrbitRing(ctx, cx, cy, 200, g * 0.05, a, 0.25, false);
  drawOrbitRing(ctx, cx, cy, 250, -g * 0.04, b, 0.15, false);

  const spin = g * 0.06;
  PROPHETS.forEach((p, i) => {
    const appear = clamp01((t - 2 - i * (d * 0.1)) / 1.4);
    if (appear <= 0) return;
    const ang = spin + (i / PROPHETS.length) * Math.PI * 2 - Math.PI / 2;
    const r = 225;
    const x = cx + Math.cos(ang) * r * 1.45;
    const y = cy + Math.sin(ang) * r * 0.78;
    // پرتو به هسته
    ctx.save();
    ctx.globalAlpha = appear;
    const lg = ctx.createLinearGradient(x, y, cx, cy);
    lg.addColorStop(0, withAlpha(b, 0.6));
    lg.addColorStop(1, withAlpha(a, 0.05));
    ctx.strokeStyle = lg;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(cx, cy);
    ctx.stroke();
    // پالسِ روی پرتو
    const ph = (g * 0.5 + i * 0.17) % 1;
    ctx.fillStyle = '#fef3c7';
    ctx.shadowColor = a;
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(lerp(x, cx, ph), lerp(y, cy, ph), 3.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    drawStar8(ctx, x, y - 30, 12 * easeOutBack(appear), b, g * 0.4 + i, true);
    drawGlassCard(ctx, x - 82, y - 12, 164, 58, b, appear);
    ctx.save();
    ctx.globalAlpha = appear;
    drawGlowingText(ctx, p.n, x, y + 8, '800 20px "Vazirmatn", sans-serif', '#fef3c7', withAlpha(b, 0.5), 8);
    drawGlowingText(ctx, p.s, x, y + 32, '500 13px "Vazirmatn", sans-serif', '#94a3b8', 'rgba(0,0,0,0)', 0);
    ctx.restore();
  });

  const fin = clamp01((t - d * 0.78) / 2);
  if (fin > 0) {
    drawGlassCard(ctx, cx - 250, 92, 500, 44, a, fin);
    ctx.save();
    ctx.globalAlpha = fin;
    drawGlowingText(ctx, 'جایی که تسلیم شدند، موفقیت آغاز شد', cx, 114, '700 20px "Vazirmatn", sans-serif', '#fde68a', withAlpha(a, 0.5), 10);
    ctx.restore();
  }
};

/* ══════════ ۳ — ابراهیمِ حنیف؛ بت‌شکن ══════════ */
export const sceneIbrahimIdols: Scene2 = (ctx, t, d, g, e, a, b) => {
  const baseY = 520;
  const idols = [180, 330, 480, 800, 950, 1100];
  const smashAt = idols.map((_, i) => d * 0.3 + i * (d * 0.07));
  // زمین
  ctx.strokeStyle = withAlpha(a, 0.35);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(80, baseY);
  ctx.lineTo(1200, baseY);
  ctx.stroke();

  idols.forEach((x, i) => {
    const appear = easeOutQuint(clamp01((t - 0.6 - i * 0.4) / 1.2));
    if (appear <= 0) return;
    const h = (130 + seeded(i) * 70) * appear;
    const smash = clamp01((t - smashAt[i]) / 1.6);
    if (smash < 1) {
      ctx.save();
      ctx.globalAlpha = 1 - smash;
      const shake = smash > 0 ? Math.sin(g * 60) * 3 * (1 - smash) : 0;
      // بدنهٔ بت
      ctx.fillStyle = 'rgba(71, 85, 105, 0.85)';
      ctx.strokeStyle = 'rgba(148, 163, 184, 0.5)';
      ctx.lineWidth = 1.5;
      drawRoundedRect(ctx, x - 30 + shake, baseY - h, 60, h, 8);
      ctx.fill();
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(x + shake, baseY - h - 18, 20, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      // ترک‌ها
      if (smash > 0) {
        ctx.strokeStyle = withAlpha('#fde68a', 0.9);
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(x - 6, baseY - h);
        ctx.lineTo(x + 8, baseY - h * 0.6);
        ctx.lineTo(x - 10, baseY - h * 0.3);
        ctx.lineTo(x + 4, baseY);
        ctx.stroke();
      }
      ctx.restore();
    }
    // تکه‌ها
    if (smash > 0) {
      for (let k = 0; k < 10; k++) {
        const vx = (seeded(i * 31 + k) - 0.5) * 260;
        const vy = -seeded(i * 17 + k) * 220;
        const tt = smash * 1.3;
        const px = x + vx * tt;
        const py = Math.min(baseY - 4, baseY - h * 0.5 + vy * tt + 300 * tt * tt);
        ctx.save();
        ctx.globalAlpha = 1 - smash * 0.7;
        ctx.fillStyle = 'rgba(148, 163, 184, 0.8)';
        ctx.translate(px, py);
        ctx.rotate(tt * 6 + k);
        ctx.fillRect(-5, -4, 10, 8);
        ctx.restore();
      }
      // موجِ ضربه
      if (smash < 0.6) {
        ctx.save();
        ctx.globalAlpha = (0.6 - smash) * 1.4;
        ctx.strokeStyle = b;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(x, baseY - h * 0.5, smash * 160, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      }
    }
  });

  // ابراهیم در مرکز با نور
  const fig = clamp01((t - 1.5) / 1.5);
  ctx.save();
  ctx.globalAlpha = fig;
  const halo = ctx.createRadialGradient(640, baseY - 70, 5, 640, baseY - 70, 160);
  halo.addColorStop(0, withAlpha(a, 0.55 + e * 0.2));
  halo.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = halo;
  ctx.beginPath();
  ctx.arc(640, baseY - 70, 160, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  ctx.save();
  ctx.globalAlpha = fig;
  drawFigure(ctx, 640, baseY - 30, 1.5, '#fef3c7', 24);
  ctx.restore();

  // تبر
  const axeP = clamp01((t - d * 0.25) / 1);
  if (axeP > 0) {
    ctx.save();
    ctx.globalAlpha = axeP;
    ctx.translate(690, baseY - 120);
    ctx.rotate(-0.6 + Math.sin(g * 3) * 0.25);
    ctx.strokeStyle = b;
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -80);
    ctx.stroke();
    ctx.fillStyle = b;
    ctx.shadowColor = b;
    ctx.shadowBlur = 18;
    ctx.beginPath();
    ctx.moveTo(-4, -80);
    ctx.lineTo(30, -92);
    ctx.lineTo(30, -58);
    ctx.lineTo(-4, -66);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  drawWipeText(ctx, 'ابراهیم؛ نخستین مُسلِم', 640, 132, '800 40px "Vazirmatn", sans-serif', '#fef3c7', withAlpha(a, 0.7), clamp01((t - 0.8) / 2));
  const tags = [
    { l: 'حنیف', at: d * 0.12, x: 400 },
    { l: 'موحّد', at: d * 0.17, x: 640 },
    { l: 'بت‌شکن', at: d * 0.22, x: 880 },
  ];
  tags.forEach((tg) => {
    const p = clamp01((t - tg.at) / 1);
    if (p > 0) drawKineticPill(ctx, tg.x, 196, tg.l, p, b, '✦', 1, 20);
  });
  drawVerseCard(ctx, 640, 560, 'إِذْ قَالَ لَهُ رَبُّهُ أَسْلِمْ ۖ قَالَ أَسْلَمْتُ لِرَبِّ الْعَالَمِينَ', 'سورهٔ بقره • آیهٔ ۱۳۱', a, clamp01((t - d * 0.72) / 2), 760);
};

/* ══════════ ۴ — همراهان؛ و ابراهیمِ تنها در آتش ══════════ */
export const sceneIbrahimFire: Scene2 = (ctx, t, d, g, e, a, b) => {
  const phase2 = easeInOutCubic(clamp01((t - d * 0.32) / 2.5));
  // فاز ۱: جفت‌های همراه
  if (phase2 < 0.99) {
    ctx.save();
    ctx.globalAlpha = 1 - phase2;
    const pairs = [
      { p: 'موسی', c: 'هارون', y: 220 },
      { p: 'عیسی', c: 'حواریون', y: 330 },
      { p: 'پیامبر ﷺ', c: 'علی ؏', y: 440 },
    ];
    pairs.forEach((pr, i) => {
      const ap = clamp01((t - 1 - i * 2.4) / 1.2);
      if (ap <= 0) return;
      const lx = 820;
      const rx = 460;
      drawNodeBadge(ctx, lx, pr.y, 26, '✦', a, ap);
      drawNodeBadge(ctx, rx, pr.y, 22, '◆', b, ap);
      ctx.save();
      ctx.globalAlpha = ap;
      ctx.strokeStyle = withAlpha(a, 0.6);
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 6]);
      ctx.lineDashOffset = -g * 30;
      ctx.beginPath();
      ctx.moveTo(lx - 30, pr.y);
      ctx.lineTo(rx + 26, pr.y);
      ctx.stroke();
      ctx.setLineDash([]);
      drawGlowingText(ctx, pr.p, lx + 50, pr.y, '800 22px "Vazirmatn", sans-serif', '#f8fafc', withAlpha(a, 0.5), 10, 'left');
      drawGlowingText(ctx, pr.c, rx - 44, pr.y, '700 20px "Vazirmatn", sans-serif', '#cbd5e1', withAlpha(b, 0.4), 8, 'right');
      ctx.restore();
    });
    const alone = clamp01((t - 8.5) / 1.4);
    if (alone > 0) drawKineticPill(ctx, 640, 540, 'امّا ابراهیم… تنها بود', alone, '#fb923c', '!', 1.05, 21);
    ctx.restore();
  }
  if (phase2 <= 0.01) return;

  // فاز ۲: آتش → گلستان
  ctx.save();
  ctx.globalAlpha = phase2;
  const cool = easeInOutCubic(clamp01((t - d * 0.62) / 6));
  const fireY = 520;
  // منجنیق/قوسِ پرتاب
  const throwP = clamp01((t - d * 0.38) / 3);
  const fx = lerp(1150, 640, easeOutCubic(throwP));
  const fy = fireY - 90 - Math.sin(throwP * Math.PI) * 220;
  if (throwP < 1) {
    ctx.strokeStyle = withAlpha('#fb923c', 0.4);
    ctx.setLineDash([4, 8]);
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let k = 0; k <= 20; k++) {
      const q = k / 20;
      const xx = lerp(1150, 640, easeOutCubic(q));
      const yy = fireY - 90 - Math.sin(q * Math.PI) * 220;
      if (k === 0) ctx.moveTo(xx, yy);
      else ctx.lineTo(xx, yy);
    }
    ctx.stroke();
    ctx.setLineDash([]);
  }
  // شعله‌ها
  drawFlames(ctx, 640, fireY, 640, 230, g, 0.4 + (1 - cool) * 0.8 + e * 0.2, cool);
  // گل‌ها
  for (let i = 0; i < 18; i++) {
    const fpx = 360 + seeded(i * 7) * 560;
    const fpy = fireY - 10 - seeded(i * 3) * 150;
    const cols = ['#f472b6', '#fde047', '#a78bfa', '#fb7185', '#34d399'];
    drawFlower(ctx, fpx, fpy, 12 + seeded(i) * 8, cols[i % cols.length], g * 0.3 + i, clamp01((cool - seeded(i * 5) * 0.5) * 2));
  }
  // ابراهیم
  drawFigure(ctx, fx, fy, 1.2, cool > 0.3 ? '#dcfce7' : '#fef3c7', 22);
  ctx.restore();

  ctx.save();
  ctx.globalAlpha = phase2;
  drawWipeText(ctx, 'حَسْبِيَ اللَّه', 640, 140, '700 40px "Amiri", serif', '#fde68a', withAlpha('#fb923c', 0.8), clamp01((t - d * 0.45) / 2));
  ctx.restore();
  drawVerseCard(ctx, 640, 210, 'يَا نَارُ كُونِي بَرْدًا وَسَلَامًا عَلَىٰ إِبْرَاهِيمَ', 'سورهٔ انبیاء • آیهٔ ۶۹', '#4ade80', clamp01((t - d * 0.66) / 2), 700);
};
