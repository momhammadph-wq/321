import {
  clamp01,
  drawAudioAuraRing,
  drawGlowingText,
  drawKineticPill,
  drawNodeBadge,
  drawRoundedRect,
  drawSpectrumBars,
  drawVerseCard,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  easeOutQuint,
  lerp,
  seeded,
  toFaDigits,
  withAlpha,
} from '../motion/drawPrimitives';
import { drawFigure, drawGlassCard, drawPopText, drawRadioWaves, drawStar8, drawWipeText } from './fx';
import type { Scene2 } from './scenesA';

/* ══════════ ۵ — بتِ منیّت؛ تخریب و بازسازیِ فونداسیون ══════════ */
export const sceneSelfIdol: Scene2 = (ctx, t, d, g, _e, a, b) => {
  const cx = 640;
  // سه محیط: اداره، محلِ کار، خانه
  const places = [
    { l: 'اداره', g: '▤', x: 300 },
    { l: 'محلِ کار', g: '⚙', x: 640 },
    { l: 'خانه', g: '⌂', x: 980 },
  ];
  const ph1 = 1 - easeInOutCubic(clamp01((t - d * 0.3) / 2.5));
  if (ph1 > 0.01) {
    ctx.save();
    ctx.globalAlpha = ph1;
    drawWipeText(ctx, 'همه‌جا تسلیم باش', cx, 150, '800 40px "Vazirmatn", sans-serif', '#fef3c7', withAlpha(a, 0.7), clamp01(t / 2));
    places.forEach((p, i) => {
      const ap = clamp01((t - 1.5 - i * 1.8) / 1.2);
      if (ap <= 0) return;
      drawGlassCard(ctx, p.x - 120, 250, 240, 200, a, ap);
      ctx.save();
      ctx.globalAlpha *= ap;
      drawPopText(ctx, p.g, p.x, 320, '700 56px "Vazirmatn", sans-serif', a, withAlpha(a, 0.7), ap, 20);
      drawGlowingText(ctx, p.l, p.x, 400, '800 24px "Vazirmatn", sans-serif', '#f1f5f9', withAlpha(a, 0.4), 8);
      ctx.restore();
      const chk = clamp01((t - 3 - i * 1.8) / 0.8);
      if (chk > 0) drawNodeBadge(ctx, p.x + 100, 262, 16, '✓', '#4ade80', chk);
    });
    ctx.restore();
  }
  if (ph1 >= 0.99) return;

  // فاز ۲: بتِ «من» ترک می‌خورد؛ ساختمان روی فونداسیونِ نو
  ctx.save();
  ctx.globalAlpha = 1 - ph1;
  const lt = t - d * 0.3;
  const crack = clamp01((lt - 4) / 5);
  const ix = 400;
  const baseY = 520;
  // بت «من»
  if (crack < 1) {
    ctx.save();
    ctx.globalAlpha *= 1 - clamp01((crack - 0.7) / 0.3);
    const shake = crack > 0 ? Math.sin(g * 50) * 3 * crack : 0;
    ctx.fillStyle = 'rgba(100, 116, 139, 0.85)';
    ctx.strokeStyle = 'rgba(203, 213, 225, 0.4)';
    ctx.lineWidth = 2;
    drawRoundedRect(ctx, ix - 80 + shake, baseY - 260, 160, 260, 14);
    ctx.fill();
    ctx.stroke();
    drawGlowingText(ctx, 'مَن', ix + shake, baseY - 140, '900 64px "Vazirmatn", sans-serif', '#e2e8f0', 'rgba(0,0,0,0.6)', 10);
    if (crack > 0) {
      ctx.strokeStyle = withAlpha('#fde68a', 0.95);
      ctx.lineWidth = 2.4;
      ctx.shadowColor = '#fde68a';
      ctx.shadowBlur = 14;
      ctx.beginPath();
      const segs = 6;
      ctx.moveTo(ix - 4, baseY - 260);
      for (let k = 1; k <= segs * crack; k++) {
        ctx.lineTo(ix + (k % 2 ? 22 : -18), baseY - 260 + (k / segs) * 260);
      }
      ctx.stroke();
    }
    ctx.restore();
  }
  drawPopText(ctx, 'بتِ منیّت را بشکن', ix, 190, '800 28px "Vazirmatn", sans-serif', '#fecaca', 'rgba(248,113,113,0.6)', clamp01((lt - 1) / 1), 16);

  // فونداسیون و ساختمانِ نو
  const bx = 880;
  const found = easeOutQuint(clamp01((lt - 8) / 2));
  if (found > 0) {
    ctx.fillStyle = withAlpha(a, 0.85);
    ctx.shadowColor = withAlpha(a, 0.7);
    ctx.shadowBlur = 18;
    ctx.fillRect(bx - 170 * found, baseY - 8, 340 * found, 22);
    ctx.shadowBlur = 0;
    drawGlowingText(ctx, 'فونداسیونِ تسلیم', bx, baseY + 40, '700 18px "Vazirmatn", sans-serif', a, withAlpha(a, 0.4), 6);
  }
  const floors = 6;
  for (let f = 0; f < floors; f++) {
    const fp = easeOutBack(clamp01((lt - 10 - f * 1.6) / 1.1));
    if (fp <= 0) continue;
    const y = baseY - 8 - (f + 1) * 52;
    const w = 280 - f * 22;
    ctx.save();
    ctx.translate(bx, y + 26);
    ctx.scale(1, fp);
    drawRoundedRect(ctx, -w / 2, -26, w, 48, 6);
    ctx.fillStyle = 'rgba(15, 23, 42, 0.92)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(b, 0.7);
    ctx.lineWidth = 1.5;
    ctx.stroke();
    for (let wdw = 0; wdw < Math.floor(w / 34); wdw++) {
      const lit = 0.4 + 0.6 * (0.5 + 0.5 * Math.sin(g * 2 + wdw + f));
      ctx.fillStyle = withAlpha(b, 0.25 + lit * 0.5);
      ctx.fillRect(-w / 2 + 10 + wdw * 34, -14, 18, 22);
    }
    ctx.restore();
  }
  const labels = ['خودت را بپذیر', 'دیگران را بپذیر', 'زندگی‌ات را دوباره بساز'];
  labels.forEach((l, i) => {
    const p = clamp01((lt - 12 - i * 4) / 1);
    if (p > 0) drawKineticPill(ctx, 640, 270 + i * 64, l, p, b, '✦', 0.9, 18);
  });
  ctx.restore();
};

/* ══════════ ۶ — ذهن مثل دستگاهِ فرستنده؛ ورودی ← پردازش ← خروجی ══════════ */
export const sceneMindRadio: Scene2 = (ctx, t, d, g, e, a, _b) => {
  const y = 330;
  const boxes = [
    { x: 1030, l: 'ورودیِ خوب', s: 'دیدن، شنیدن، باور', c: '#38bdf8' },
    { x: 640, l: 'پردازشِ ذهن', s: 'هدایت', c: a },
    { x: 250, l: 'خروجیِ خوب', s: 'روزی و نعمت', c: '#4ade80' },
  ];
  boxes.forEach((bx, i) => {
    const ap = clamp01((t - 1 - i * 3) / 1.2);
    if (ap <= 0) return;
    drawGlassCard(ctx, bx.x - 130, y - 80, 260, 160, bx.c, ap);
    ctx.save();
    ctx.globalAlpha *= ap;
    drawGlowingText(ctx, bx.l, bx.x, y - 18, '800 26px "Vazirmatn", sans-serif', '#f8fafc', withAlpha(bx.c, 0.6), 12);
    drawGlowingText(ctx, bx.s, bx.x, y + 26, '500 17px "Vazirmatn", sans-serif', '#94a3b8', 'rgba(0,0,0,0)', 0);
    ctx.restore();
  });
  // جریان بین جعبه‌ها
  [
    [900, 770],
    [510, 380],
  ].forEach(([x1, x2], i) => {
    const ap = clamp01((t - 3 - i * 3) / 1);
    if (ap <= 0) return;
    ctx.save();
    ctx.globalAlpha = ap;
    ctx.strokeStyle = withAlpha(a, 0.5);
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x1, y);
    ctx.lineTo(x2, y);
    ctx.lineTo(x2 + 14, y - 10);
    ctx.moveTo(x2, y);
    ctx.lineTo(x2 + 14, y + 10);
    ctx.stroke();
    for (let k = 0; k < 4; k++) {
      const ph = (g * 0.7 + k / 4) % 1;
      ctx.fillStyle = '#fef3c7';
      ctx.shadowColor = a;
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.arc(lerp(x1, x2, ph), y, 4, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  });
  // دکلِ فرستنده بالای پردازش
  const ant = clamp01((t - 9) / 1.5);
  if (ant > 0) {
    ctx.save();
    ctx.globalAlpha = ant;
    ctx.strokeStyle = a;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(620, y - 82);
    ctx.lineTo(640, y - 170);
    ctx.lineTo(660, y - 82);
    ctx.moveTo(628, y - 120);
    ctx.lineTo(652, y - 120);
    ctx.stroke();
    drawRadioWaves(ctx, 640, y - 172, g, withAlpha(a, 0.8), 120 + e * 40);
    ctx.restore();
  }
  drawWipeText(ctx, 'ذهن، دستگاهِ ارسالِ فرکانس', 640, 130, '800 36px "Vazirmatn", sans-serif', '#fef3c7', withAlpha(a, 0.7), clamp01((t - 0.5) / 2));
  // ساختار سورهٔ حمد
  const fat = clamp01((t - d * 0.55) / 1.6);
  if (fat > 0) {
    const segs = [
      { l: 'آیاتِ ستایش', s: 'ورودی', c: '#38bdf8' },
      { l: 'اهدنا…', s: 'هدایت', c: a },
      { l: 'نعمت / غضب', s: 'خروجی', c: '#4ade80' },
    ];
    segs.forEach((s, i) => {
      const p = clamp01((t - d * 0.55 - i * 2) / 1);
      if (p <= 0) return;
      const x = 900 - i * 260;
      drawGlassCard(ctx, x - 110, 470, 220, 70, s.c, p);
      ctx.save();
      ctx.globalAlpha *= p;
      drawGlowingText(ctx, s.l, x, 494, '700 18px "Vazirmatn", sans-serif', '#f1f5f9', 'rgba(0,0,0,0)', 0);
      drawGlowingText(ctx, s.s, x, 520, '600 15px "Vazirmatn", sans-serif', s.c, 'rgba(0,0,0,0)', 0);
      ctx.restore();
    });
    drawPopText(ctx, 'الگوی سورهٔ حمد', 640, 438, '700 18px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', fat);
  }
  drawSpectrumBars(ctx, 640, 590, 40, 420, g, e, a, 0.5);
};

/* ══════════ ۷ — مغز فیزیکی، ذهن متافیزیکی؛ ایمان به غیب ══════════ */
export const sceneMindBrain: Scene2 = (ctx, t, d, g, e, a, b) => {
  // مغز (راست)
  const bx = 900;
  const by = 330;
  const bp = clamp01((t - 0.8) / 1.5);
  ctx.save();
  ctx.globalAlpha = bp;
  ctx.strokeStyle = withAlpha('#f9a8d4', 0.85);
  ctx.lineWidth = 3;
  ctx.shadowColor = '#f472b6';
  ctx.shadowBlur = 16;
  ctx.beginPath();
  ctx.ellipse(bx, by, 130, 95, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.lineWidth = 2;
  for (let i = 0; i < 6; i++) {
    ctx.beginPath();
    const yy = by - 60 + i * 24;
    ctx.moveTo(bx - 110, yy);
    for (let x = -110; x <= 110; x += 12) ctx.lineTo(bx + x, yy + Math.sin(x * 0.08 + i) * 8);
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.moveTo(bx, by - 95);
  ctx.lineTo(bx, by + 95);
  ctx.stroke();
  ctx.restore();
  drawPopText(ctx, 'مغز • فیزیکی • دیده می‌شود', bx, by + 140, '700 19px "Vazirmatn", sans-serif', '#fbcfe8', 'rgba(0,0,0,0)', clamp01((t - 2.5) / 1));

  // ذهن (چپ) — ابری نورانی بدون مرز
  const mx = 380;
  const mp = clamp01((t - 5) / 2);
  if (mp > 0) {
    ctx.save();
    ctx.globalAlpha = mp;
    for (let i = 0; i < 40; i++) {
      const ang = seeded(i) * Math.PI * 2 + g * (0.1 + seeded(i * 3) * 0.3);
      const r = 30 + seeded(i * 7) * 120 + Math.sin(g + i) * 10;
      ctx.fillStyle = withAlpha(i % 3 ? a : b, 0.2 + seeded(i * 9) * 0.5);
      ctx.beginPath();
      ctx.arc(mx + Math.cos(ang) * r, by + Math.sin(ang) * r * 0.75, 2 + seeded(i * 11) * 4, 0, Math.PI * 2);
      ctx.fill();
    }
    drawAudioAuraRing(ctx, mx, by, 70, g, e, a);
    ctx.restore();
    drawPopText(ctx, 'ذهن • متافیزیکی • دیده نمی‌شود', mx, by + 140, '700 19px "Vazirmatn", sans-serif', '#fde68a', 'rgba(0,0,0,0)', clamp01((t - 6.5) / 1));
  }
  // علامتِ «≠»
  drawPopText(ctx, '≠', 640, by, '800 72px "Vazirmatn", sans-serif', '#e2e8f0', withAlpha(a, 0.6), clamp01((t - 8) / 1), 20);
  drawWipeText(ctx, 'ذهن، مغز نیست', 640, 130, '800 40px "Vazirmatn", sans-serif', '#fef3c7', withAlpha(a, 0.7), clamp01(t / 2));
  // ایمان به غیب
  const words = ['باور', 'ایمان', 'یقین'];
  words.forEach((w, i) => {
    const p = clamp01((t - d * 0.45 - i * 2.2) / 1);
    if (p > 0) drawKineticPill(ctx, mx - 120 + i * 120, 196, w, p, a, '✦', 0.9, 18);
  });
  drawVerseCard(ctx, 640, 560, 'الَّذِينَ يُؤْمِنُونَ بِالْغَيْبِ', 'سورهٔ بقره • آیهٔ ۳', a, clamp01((t - d * 0.6) / 2), 600);
};

/* ══════════ ۸ — نشانه‌ها برمی‌گردند (رادیو، کودک، تلفن، رهگذر) ══════════ */
export const sceneSignsReturn: Scene2 = (ctx, t, d, g, e, a, b) => {
  const cx = 640;
  const cy = 330;
  // تو در مرکز؛ فرکانس می‌رود و برمی‌گردد
  drawFigure(ctx, cx, cy + 60, 1.4, '#fef3c7', 20 + e * 20);
  drawRadioWaves(ctx, cx, cy, g, withAlpha(a, 0.6), 300, 1, 4);
  drawRadioWaves(ctx, cx, cy, g + 0.37, withAlpha(b, 0.55), 300, -1, 3);
  const signs = [
    { l: 'رادیوی ماشین', g: '📻', ang: -2.5 },
    { l: 'حرفِ یک کودک', g: '✿', ang: -0.6 },
    { l: 'زنگِ تلفن', g: '☎', ang: 0.6 },
    { l: 'رهگذرِ سرِ راه', g: '⛰', ang: 2.5 },
  ];
  signs.forEach((s, i) => {
    const ap = clamp01((t - 2 - i * (d * 0.16)) / 1.2);
    if (ap <= 0) return;
    const x = cx + Math.cos(s.ang) * 380;
    const y = cy + Math.sin(s.ang) * 190;
    // پرتو برگشت
    const ph = (g * 0.6 + i * 0.25) % 1;
    ctx.save();
    ctx.globalAlpha = ap;
    ctx.strokeStyle = withAlpha(b, 0.35);
    ctx.setLineDash([5, 7]);
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(cx, cy);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = b;
    ctx.shadowColor = b;
    ctx.shadowBlur = 14;
    ctx.beginPath();
    ctx.arc(lerp(x, cx, ph), lerp(y, cy, ph), 4.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    drawGlassCard(ctx, x - 100, y - 40, 200, 80, b, ap);
    ctx.save();
    ctx.globalAlpha *= ap;
    drawGlowingText(ctx, s.g, x, y - 12, '700 26px "Vazirmatn", sans-serif', b, withAlpha(b, 0.6), 10);
    drawGlowingText(ctx, s.l, x, y + 20, '700 17px "Vazirmatn", sans-serif', '#f1f5f9', 'rgba(0,0,0,0)', 0);
    ctx.restore();
  });
  drawWipeText(ctx, 'جهان پاسخ می‌دهد', cx, 112, '800 38px "Vazirmatn", sans-serif', '#fef3c7', withAlpha(a, 0.7), clamp01(t / 2));
  const ans = clamp01((t - d * 0.7) / 1.4);
  if (ans > 0) drawKineticPill(ctx, cx, 575, 'جوابِ سؤالت، از جایی که فکرش را نمی‌کنی', ans, a, '✓', 1, 19);
};

/* ══════════ ۹ — آب شکلِ ظرف را می‌گیرد؛ همه‌چیز انرژی و نور ══════════ */
export const sceneEnergyWater: Scene2 = (ctx, t, d, g, _e, a, b) => {
  const shapes = ['cyl', 'rect', 'tri'] as const;
  const xs = [1000, 640, 280];
  const labels = ['استوانه', 'مستطیل', 'مثلث'];
  shapes.forEach((sh, i) => {
    const ap = clamp01((t - 1 - i * 2.5) / 1.2);
    if (ap <= 0) return;
    const x = xs[i];
    const top = 230;
    const bot = 470;
    const fill = easeInOutCubic(clamp01((t - 2 - i * 2.5) / 4));
    ctx.save();
    ctx.globalAlpha = ap;
    ctx.beginPath();
    if (sh === 'cyl') {
      ctx.moveTo(x - 80, top);
      ctx.lineTo(x - 80, bot);
      ctx.ellipse(x, bot, 80, 20, 0, Math.PI, 0, true);
      ctx.lineTo(x + 80, top);
    } else if (sh === 'rect') {
      ctx.rect(x - 110, top, 220, bot - top);
    } else {
      ctx.moveTo(x, top);
      ctx.lineTo(x + 120, bot);
      ctx.lineTo(x - 120, bot);
      ctx.closePath();
    }
    ctx.save();
    ctx.clip();
    const lvl = bot - (bot - top) * fill * 0.9;
    const wg = ctx.createLinearGradient(0, lvl, 0, bot);
    wg.addColorStop(0, withAlpha(b, 0.85));
    wg.addColorStop(1, withAlpha(a, 0.5));
    ctx.fillStyle = wg;
    ctx.beginPath();
    ctx.moveTo(x - 130, bot + 30);
    for (let xx = -130; xx <= 130; xx += 8) ctx.lineTo(x + xx, lvl + Math.sin(xx * 0.06 + g * 3) * 5);
    ctx.lineTo(x + 130, bot + 30);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
    ctx.strokeStyle = withAlpha('#e0f2fe', 0.7);
    ctx.lineWidth = 2.4;
    ctx.stroke();
    ctx.restore();
    drawPopText(ctx, labels[i], x, 520, '700 20px "Vazirmatn", sans-serif', '#e0f2fe', 'rgba(0,0,0,0)', ap);
  });
  // جریانِ ریزان از بالا
  for (let k = 0; k < 30; k++) {
    const ph = (g * 0.8 + seeded(k)) % 1;
    const x = 280 + (k % 3) * 360 + (seeded(k * 3) - 0.5) * 30;
    ctx.fillStyle = withAlpha(b, (1 - ph) * 0.7);
    ctx.beginPath();
    ctx.arc(x, 150 + ph * 90, 2.5, 0, Math.PI * 2);
    ctx.fill();
  }
  drawWipeText(ctx, 'همه‌چیز انرژی است، نور است، جریان است', 640, 120, '800 32px "Vazirmatn", sans-serif', '#e0f2fe', withAlpha(b, 0.7), clamp01(t / 2.2));
  const fin = clamp01((t - d * 0.6) / 1.4);
  if (fin > 0) drawKineticPill(ctx, 640, 580, 'ظرفِ ذهنت، شکلِ زندگی‌ات را می‌سازد', fin, a, '◈', 1, 19);
};

/* ══════════ ۱۰ — پلکانِ شش گام ══════════ */
export const STEPS6 = [
  { n: 'تسلیم', c: '#fbbf24' },
  { n: 'ورودیِ ذهن', c: '#38bdf8' },
  { n: 'ارسالِ فرکانس', c: '#a78bfa' },
  { n: 'سیستمِ قانونمندِ جهان', c: '#22d3ee' },
  { n: 'هدایت و نشانه', c: '#4ade80' },
  { n: 'صدّق بالحُسنی', c: '#f472b6' },
];
export const sceneSixSteps: Scene2 = (ctx, t, d, g, e, a) => {
  const stepDur = (d * 0.8) / 6;
  STEPS6.forEach((s, i) => {
    const p = clamp01((t - 1 - i * stepDur) / 1.4);
    const x = 1110 - i * 168;
    const h = 70 + i * 52;
    const y = 540 - h;
    const active = t >= 1 + i * stepDur && t < 1 + (i + 1) * stepDur;
    const eb = easeOutQuint(p);
    if (eb <= 0) return;
    ctx.save();
    ctx.globalAlpha = 0.35 + p * 0.65;
    const gr = ctx.createLinearGradient(0, y, 0, 540);
    gr.addColorStop(0, withAlpha(s.c, active ? 0.95 : 0.6));
    gr.addColorStop(1, withAlpha(s.c, 0.1));
    ctx.fillStyle = gr;
    drawRoundedRect(ctx, x - 74, 540 - h * eb, 148, h * eb, 10);
    ctx.fill();
    if (active) {
      ctx.shadowColor = s.c;
      ctx.shadowBlur = 30 + e * 20;
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 2;
      ctx.stroke();
    }
    ctx.restore();
    drawPopText(ctx, `گام ${toFaDigits(i + 1)}`, x, 540 - h * eb + 26, '800 18px "Vazirmatn", sans-serif', '#0b1020', 'rgba(255,255,255,0.4)', p, 4);
    ctx.save();
    ctx.globalAlpha = p;
    const words = s.n.split(' ');
    const lines = s.n.length > 12 ? [words.slice(0, Math.ceil(words.length / 2)).join(' '), words.slice(Math.ceil(words.length / 2)).join(' ')] : [s.n];
    lines.forEach((ln, k) =>
      drawGlowingText(ctx, ln, x, 566 + k * 22, `700 ${active ? 17 : 15}px "Vazirmatn", sans-serif`, active ? '#fff' : '#cbd5e1', withAlpha(s.c, active ? 0.7 : 0), 10),
    );
    ctx.restore();
  });
  // ستاره‌ای که از پله بالا می‌رود
  const cur = Math.min(5, Math.max(0, Math.floor((t - 1) / stepDur)));
  const frac = clamp01(((t - 1) % stepDur) / 1.2);
  const fromX = 1110 - Math.max(0, cur - 1) * 168;
  const toX = 1110 - cur * 168;
  const fromY = 540 - (70 + Math.max(0, cur - 1) * 52) - 26;
  const toY = 540 - (70 + cur * 52) - 26;
  const sx = lerp(fromX, toX, easeOutCubic(frac));
  const sy = lerp(fromY, toY, easeOutCubic(frac)) - Math.sin(frac * Math.PI) * 40 - 30;
  drawStar8(ctx, sx, sy, 14 + e * 4, STEPS6[cur].c, g, true);
  drawWipeText(ctx, 'شش گامِ تسلیم تا گشایش', 640, 112, '800 38px "Vazirmatn", sans-serif', '#fef3c7', withAlpha(a, 0.7), clamp01(t / 2));
};

/* ══════════ ۱۱ — دلِ با خدا، GPSِ هدایت ══════════ */
export const sceneHeartGps: Scene2 = (ctx, t, d, g, e, a, b) => {
  // نقشهٔ جاده‌ای پرپیچ
  const path: Array<[number, number]> = [];
  for (let i = 0; i <= 60; i++) {
    const k = i / 60;
    path.push([1180 - k * 1080, 470 - Math.sin(k * Math.PI * 2.2) * 120 - k * 80]);
  }
  const prog = easeInOutCubic(clamp01((t - 2) / (d * 0.75)));
  ctx.save();
  ctx.strokeStyle = 'rgba(148, 163, 184, 0.25)';
  ctx.lineWidth = 16;
  ctx.lineCap = 'round';
  ctx.beginPath();
  path.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
  ctx.stroke();
  ctx.strokeStyle = withAlpha(a, 0.9);
  ctx.lineWidth = 5;
  ctx.shadowColor = a;
  ctx.shadowBlur = 14;
  ctx.beginPath();
  const upto = Math.floor(prog * 60);
  for (let i = 0; i <= upto; i++) (i ? ctx.lineTo(...path[i]) : ctx.moveTo(...path[i]));
  ctx.stroke();
  ctx.restore();
  // تابلوهای نشانه کنار راه
  [12, 26, 40, 54].forEach((idx, i) => {
    const p = clamp01((prog * 60 - idx + 3) / 3);
    if (p <= 0) return;
    const [x, y] = path[idx];
    drawNodeBadge(ctx, x, y - 46, 18, '✦', b, p);
    ctx.save();
    ctx.globalAlpha = p;
    ctx.strokeStyle = withAlpha(b, 0.6);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x, y - 28);
    ctx.lineTo(x, y - 6);
    ctx.stroke();
    ctx.restore();
    void i;
  });
  // قلبِ راهنما روی مسیر
  const hi = Math.min(60, Math.floor(prog * 60));
  const [hx, hy] = path[hi];
  const beat = 1 + Math.max(0, 0.2 - ((g * 1.2) % 1)) * 1.5 + e * 0.15;
  ctx.save();
  ctx.translate(hx, hy - 4);
  ctx.scale(beat, beat);
  ctx.fillStyle = '#fb7185';
  ctx.shadowColor = '#fb7185';
  ctx.shadowBlur = 24;
  ctx.beginPath();
  ctx.moveTo(0, 10);
  ctx.bezierCurveTo(-22, -6, -12, -24, 0, -12);
  ctx.bezierCurveTo(12, -24, 22, -6, 0, 10);
  ctx.fill();
  ctx.restore();

  // GPS خط‌خورده
  const gp = clamp01((t - 4) / 1.2);
  if (gp > 0) {
    drawGlassCard(ctx, 90, 150, 230, 90, '#f87171', gp);
    ctx.save();
    ctx.globalAlpha = gp;
    drawGlowingText(ctx, 'GPS', 205, 195, '800 34px "Vazirmatn", sans-serif', '#94a3b8', 'rgba(0,0,0,0)', 0);
    const strike = clamp01((t - 5.5) / 0.8);
    ctx.strokeStyle = '#f87171';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(130, 195);
    ctx.lineTo(130 + 150 * strike, 195);
    ctx.stroke();
    ctx.restore();
  }
  drawWipeText(ctx, 'دلت با خدا باشد؛ نشانه‌ها راه را نشان می‌دهند', 700, 112, '800 30px "Vazirmatn", sans-serif', '#fef3c7', withAlpha(a, 0.7), clamp01(t / 2.2));
  const fin = clamp01((t - d * 0.55) / 1.2);
  if (fin > 0) drawKineticPill(ctx, 860, 210, 'با پیکان، با قاطر… هدایت می‌رسی', fin, b, '→', 0.95, 18);
};

/* ══════════ ۱۲ — علمِ بی‌کرانِ خدا؛ حتی بالِ پشه ══════════ */
export const sceneAllKnowing: Scene2 = (ctx, t, d, g, _e, a, b) => {
  const cx = 640;
  const cy = 330;
  // شبکهٔ کیهانیِ نقاط به هم وصل
  const nodes = 46;
  const pts: Array<[number, number]> = [];
  for (let i = 0; i < nodes; i++) {
    const ang = seeded(i) * Math.PI * 2 + g * 0.03 * (i % 2 ? 1 : -1);
    const r = 60 + seeded(i * 5) * 300;
    pts.push([cx + Math.cos(ang) * r * 1.5, cy + Math.sin(ang) * r * 0.75]);
  }
  const net = clamp01((t - 0.5) / 3);
  ctx.save();
  ctx.globalAlpha = net;
  for (let i = 0; i < nodes; i++) {
    for (let j = i + 1; j < nodes; j++) {
      const dx = pts[i][0] - pts[j][0];
      const dy = pts[i][1] - pts[j][1];
      const dist = Math.hypot(dx, dy);
      if (dist < 130) {
        ctx.strokeStyle = withAlpha(a, (1 - dist / 130) * 0.35);
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(...pts[i]);
        ctx.lineTo(...pts[j]);
        ctx.stroke();
      }
    }
    ctx.fillStyle = withAlpha(i % 4 ? a : b, 0.8);
    ctx.beginPath();
    ctx.arc(pts[i][0], pts[i][1], 2.6, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
  // پشه با بال‌زدن، در ذره‌بینِ نور
  const mp = clamp01((t - 4) / 1.5);
  if (mp > 0) {
    ctx.save();
    ctx.globalAlpha = mp;
    const lens = ctx.createRadialGradient(cx, cy, 10, cx, cy, 120);
    lens.addColorStop(0, withAlpha(b, 0.3));
    lens.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = lens;
    ctx.beginPath();
    ctx.arc(cx, cy, 120, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = withAlpha(b, 0.7);
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(cx, cy, 110, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = '#e2e8f0';
    ctx.beginPath();
    ctx.ellipse(cx, cy, 26, 7, 0, 0, Math.PI * 2);
    ctx.fill();
    const flap = Math.sin(g * 40) * 0.6;
    [-1, 1].forEach((s) => {
      ctx.save();
      ctx.translate(cx - 4, cy - 4);
      ctx.rotate(s * (0.5 + flap));
      ctx.fillStyle = withAlpha('#bae6fd', 0.55);
      ctx.beginPath();
      ctx.ellipse(0, -s * 26, 9, 26, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });
    ctx.restore();
  }
  drawWipeText(ctx, 'خدا حتی بال‌زدنِ یک پشه را می‌داند', cx, 112, '800 34px "Vazirmatn", sans-serif', '#fef3c7', withAlpha(a, 0.7), clamp01(t / 2));
  drawVerseCard(ctx, cx, 560, 'وَلَٰكِنَّ أَكْثَرَهُمْ لَا يَعْلَمُونَ', 'بیشترِ مردم نمی‌دانند', a, clamp01((t - d * 0.45) / 2), 560);
};

/* ══════════ ۱۳ — پیامِ خدا را تصدیق کن؛ صدّق بالحُسنی ══════════ */
export const sceneSadaqa: Scene2 = (ctx, t, d, g, e, a, b) => {
  const cx = 640;
  const cy = 320;
  // پاکتِ پیام از بالا فرود می‌آید
  const fall = easeOutBack(clamp01((t - 1) / 2.4));
  const ey = lerp(-80, cy - 20, fall);
  const openP = easeOutCubic(clamp01((t - 4) / 1.6));
  ctx.save();
  ctx.translate(cx, ey);
  ctx.rotate((1 - fall) * 0.4);
  ctx.shadowColor = withAlpha(a, 0.6);
  ctx.shadowBlur = 30 + e * 20;
  drawRoundedRect(ctx, -130, -80, 260, 160, 14);
  ctx.fillStyle = 'rgba(253, 230, 138, 0.95)';
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.strokeStyle = '#b45309';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-130, -80);
  ctx.lineTo(0, -80 + 90 * (1 - openP) - 60 * openP);
  ctx.lineTo(130, -80);
  ctx.stroke();
  drawStar8(ctx, 0, 10, 22, '#b45309', g * 0.5, true);
  ctx.restore();
  // نامه بیرون می‌آید
  if (openP > 0) {
    const ly = lerp(ey, ey - 150, openP);
    drawGlassCard(ctx, cx - 210, ly - 50, 420, 100, a, openP);
    ctx.save();
    ctx.globalAlpha = openP;
    drawGlowingText(ctx, 'این نشانه از سوی خداست', cx, ly - 12, '800 24px "Vazirmatn", sans-serif', '#fef3c7', withAlpha(a, 0.6), 10);
    drawGlowingText(ctx, 'دست‌مریزاد خدا، پیامت رسید', cx, ly + 22, '600 18px "Vazirmatn", sans-serif', '#cbd5e1', 'rgba(0,0,0,0)', 0);
    ctx.restore();
  }
  // دسته‌گلِ شکر
  const thanks = ['تأیید کن', 'تصدیق کن', 'شکر کن', 'چه زیباست!'];
  thanks.forEach((w, i) => {
    const p = clamp01((t - d * 0.3 - i * 2.4) / 1);
    if (p <= 0) return;
    const ang = -Math.PI / 2 + (i - 1.5) * 0.9;
    const x = cx + Math.cos(ang + Math.PI) * -330;
    const y = cy + 120 + Math.sin(ang) * -60;
    drawKineticPill(ctx, x, y, w, p, i % 2 ? b : a, '✓', 1, 20);
  });
  drawVerseCard(ctx, cx, 560, 'وَصَدَّقَ بِالْحُسْنَىٰ ۝ فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ', 'سورهٔ لیل • آیات ۶ و ۷', a, clamp01((t - d * 0.5) / 2), 700);
  void easeOutQuint;
};
