import {
  clamp01,
  drawAudioAuraRing,
  drawGlowingText,
  drawKineticPill,
  drawSacredMandala,
  drawVerseCard,
  easeInOutCubic,
  easeOutCubic,
  lerp,
  seeded,
  toFaDigits,
  withAlpha,
} from '../motion/drawPrimitives';
import { drawFigure, drawGlassCard, drawPopText, drawStar8, drawWipeText } from './fx';
import type { Scene2 } from './scenesA';
import { STEPS6 } from './scenesB';

/* ══════════ ۱۴ — تصویرِ غیب: تصور، شکر، لبخند ══════════ */
export const sceneGhaybVision: Scene2 = (ctx, t, d, g, e, a, b) => {
  const cx = 640;
  const cy = 330;
  // چشمِ بصیرت
  const open = easeInOutCubic(clamp01((t - 1) / 3));
  const ew = 300;
  const eh = 120 * open + 4;
  ctx.save();
  ctx.shadowColor = withAlpha(a, 0.7);
  ctx.shadowBlur = 24 + e * 20;
  ctx.strokeStyle = a;
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(cx - ew / 2, cy);
  ctx.quadraticCurveTo(cx, cy - eh, cx + ew / 2, cy);
  ctx.quadraticCurveTo(cx, cy + eh, cx - ew / 2, cy);
  ctx.closePath();
  ctx.stroke();
  ctx.save();
  ctx.clip();
  const iris = ctx.createRadialGradient(cx, cy, 4, cx, cy, 70);
  iris.addColorStop(0, '#fffbeb');
  iris.addColorStop(0.35, b);
  iris.addColorStop(1, withAlpha(a, 0.3));
  ctx.fillStyle = iris;
  ctx.beginPath();
  ctx.arc(cx + Math.sin(g * 0.7) * 20, cy, 62, 0, Math.PI * 2);
  ctx.fill();
  drawSacredMandala(ctx, cx + Math.sin(g * 0.7) * 20, cy, 56, g * 0.6, '#ffffff', 0.5);
  ctx.restore();
  ctx.restore();

  // تصاویرِ ذهنی که از چشم بیرون می‌آیند
  const visions = ['تصورِ روشن', 'شکرِ پیشاپیش', 'لبخند', 'کارِ غیبی', 'بشارت'];
  visions.forEach((v, i) => {
    const p = clamp01((t - 4 - i * (d * 0.12)) / 1.2);
    if (p <= 0) return;
    const ang = -Math.PI + (i / (visions.length - 1)) * Math.PI;
    const r = lerp(60, 290, easeOutCubic(p));
    const x = cx + Math.cos(ang) * r * 1.3;
    const y = cy + Math.sin(ang) * r * 0.55 - 6;
    drawKineticPill(ctx, x, y, v, p, i % 2 ? b : a, '✦', 0.95, 19);
  });
  drawWipeText(ctx, 'غیب را با چشمِ دل ببین', cx, 112, '800 38px "Vazirmatn", sans-serif', '#fef3c7', withAlpha(a, 0.7), clamp01(t / 2));
  const fin = clamp01((t - d * 0.65) / 1.4);
  if (fin > 0) {
    drawGlassCard(ctx, cx - 270, 520, 540, 56, a, fin);
    ctx.save();
    ctx.globalAlpha = fin;
    drawGlowingText(ctx, 'شکرِ خدا پیش از رسیدن؛ لبخند پیش از دیدن', cx, 548, '700 20px "Vazirmatn", sans-serif', '#fde68a', withAlpha(a, 0.5), 10);
    ctx.restore();
  }
};

/* ══════════ ۱۵ — پایداری؛ سنّتِ پیشینیان ══════════ */
export const sceneSteadfast: Scene2 = (ctx, t, d, g, e, a, b) => {
  const cx = 640;
  // مسیرِ پیشینیان: ردپاهای نورانی
  const names = ['ابراهیم', 'موسی', 'عیسی', 'محمد ﷺ', 'تو'];
  const pathY = (k: number) => 470 - Math.sin(k * Math.PI) * 60;
  names.forEach((n, i) => {
    const k = i / (names.length - 1);
    const x = 1130 - k * 980;
    const y = pathY(k);
    const p = clamp01((t - 1 - i * 3) / 1.2);
    if (p <= 0) return;
    const isYou = i === names.length - 1;
    drawFigure(ctx, x, y, isYou ? 1.25 : 1, isYou ? '#fef3c7' : withAlpha(a, 0.85), isYou ? 26 + e * 20 : 14);
    drawPopText(ctx, n, x, y + 48, `${isYou ? 800 : 700} ${isYou ? 22 : 18}px "Vazirmatn", sans-serif`, isYou ? '#fde68a' : '#e2e8f0', withAlpha(a, 0.5), p, 8);
    if (i > 0) {
      const pk = (i - 1) / (names.length - 1);
      const px = 1130 - pk * 980;
      ctx.save();
      ctx.globalAlpha = p;
      ctx.strokeStyle = withAlpha(b, 0.55);
      ctx.lineWidth = 2.4;
      ctx.setLineDash([3, 10]);
      ctx.lineDashOffset = -g * 20;
      ctx.beginPath();
      ctx.moveTo(px - 24, pathY(pk) - 30);
      ctx.quadraticCurveTo((px + x) / 2, Math.min(pathY(pk), y) - 90, x + 24, y - 30);
      ctx.stroke();
      ctx.restore();
    }
  });
  // ستون‌های شش گام (کوچک) بالای صحنه
  STEPS6.forEach((s, i) => {
    const p = clamp01((t - d * 0.35 - i * 1.2) / 1);
    if (p <= 0) return;
    const x = 1060 - i * 168;
    drawGlassCard(ctx, x - 76, 188, 152, 54, s.c, p);
    ctx.save();
    ctx.globalAlpha = p;
    drawGlowingText(ctx, `${toFaDigits(i + 1)}. ${s.n}`, x, 215, '700 14px "Vazirmatn", sans-serif', '#f1f5f9', withAlpha(s.c, 0.6), 6);
    ctx.restore();
  });
  // ستاره‌های بالای سر
  for (let i = 0; i < 12; i++) {
    const x = 100 + seeded(i * 13) * 1080;
    const y = 290 + seeded(i * 7) * 50;
    drawStar8(ctx, x, y, 4 + seeded(i) * 4, withAlpha(b, 0.6 + 0.4 * Math.sin(g * 2 + i)), g * 0.3 + i, true);
  }
  drawAudioAuraRing(ctx, 150, 410, 40, g, e, a);
  drawWipeText(ctx, 'پایدار بمان؛ این راهِ پیامبران است', cx, 112, '800 36px "Vazirmatn", sans-serif', '#fef3c7', withAlpha(a, 0.7), clamp01(t / 2));
  drawVerseCard(ctx, cx, 560, 'فَاسْتَقِمْ كَمَا أُمِرْتَ', 'سورهٔ هود • آیهٔ ۱۱۲', a, clamp01((t - d * 0.6) / 2), 520);
};
