/* ------------------------------------------------------------------
   timeline2.ts — اپیزود ۲: «تسلیم؛ رمز موفقیتِ پیامبران»
   فایل صوتی: k-WhatsApp Audio 2026-10-03 at 18.07.51 (3).ogg — ۱۴:۴۰
   زمان‌بندی فصل‌ها و زیرنویس‌ها بر اساس رونویسیِ خودکارِ همین صدا
   (Whisper) تنظیم شده است؛ متن‌ها خلاصهٔ مفهومیِ گفتارند.
------------------------------------------------------------------ */

export const EP2_AUDIO_URL =
  'https://raw.githubusercontent.com/momhammadph-wq/321/main/k-WhatsApp%20Audio%202026-10-03%20at%2018.07.51%20(3).ogg';

export const EP2_DURATION = 880.17;

export type Ep2SceneKey =
  | 'tasleem_key'
  | 'prophets_orbit'
  | 'ibrahim_idols'
  | 'ibrahim_fire'
  | 'self_idol'
  | 'mind_radio'
  | 'mind_brain'
  | 'signs_return'
  | 'energy_water'
  | 'six_steps'
  | 'heart_gps'
  | 'all_knowing'
  | 'sadaqa'
  | 'ghayb_vision'
  | 'steadfast';

export interface Ep2Chapter {
  id: number;
  sceneKey: Ep2SceneKey;
  title: string;
  subtitle: string;
  start: number;
  end: number;
  bgTop: string;
  bgBottom: string;
  accent: string;
  accentSecondary: string;
}

export interface Ep2Cue {
  start: number;
  end: number;
  text: string;
  highlight?: boolean;
}

export const EP2_CHAPTERS: Ep2Chapter[] = [
  { id: 1, sceneKey: 'tasleem_key', title: 'دروازهٔ تسلیم', subtitle: 'کلیدِ گشایشِ زندگی', start: 0, end: 28, bgTop: '#120f2a', bgBottom: '#2b1a3a', accent: '#fbbf24', accentSecondary: '#fde68a' },
  { id: 2, sceneKey: 'prophets_orbit', title: 'منظومهٔ پیامبران', subtitle: 'جایی که تسلیم شدند، موفقیت آغاز شد', start: 28, end: 62, bgTop: '#071a30', bgBottom: '#13284a', accent: '#fbbf24', accentSecondary: '#38bdf8' },
  { id: 3, sceneKey: 'ibrahim_idols', title: 'ابراهیمِ بت‌شکن', subtitle: 'نخستین مُسلِم؛ حنیف و موحّد', start: 62, end: 95, bgTop: '#1a1024', bgBottom: '#2e1d2c', accent: '#f59e0b', accentSecondary: '#fde047' },
  { id: 4, sceneKey: 'ibrahim_fire', title: 'آتش، گلستان شد', subtitle: 'تنها، امّا تسلیم', start: 95, end: 150, bgTop: '#1f0d12', bgBottom: '#2a1a12', accent: '#fb923c', accentSecondary: '#38bdf8' },
  { id: 5, sceneKey: 'self_idol', title: 'بتِ منیّت را بشکن', subtitle: 'در اداره، محلِ کار و خانه', start: 150, end: 240, bgTop: '#0c1426', bgBottom: '#1b2440', accent: '#fbbf24', accentSecondary: '#22d3ee' },
  { id: 6, sceneKey: 'mind_radio', title: 'ذهن، دستگاهِ فرستنده', subtitle: 'ورودی ← پردازش ← خروجی', start: 240, end: 300, bgTop: '#0a1430', bgBottom: '#16204a', accent: '#a78bfa', accentSecondary: '#38bdf8' },
  { id: 7, sceneKey: 'mind_brain', title: 'ذهن، مغز نیست', subtitle: 'ایمان به غیب', start: 300, end: 360, bgTop: '#170e2c', bgBottom: '#24143e', accent: '#fbbf24', accentSecondary: '#c084fc' },
  { id: 8, sceneKey: 'signs_return', title: 'جهان پاسخ می‌دهد', subtitle: 'نشانه‌ها از جایی که فکرش را نمی‌کنی', start: 360, end: 420, bgTop: '#06202a', bgBottom: '#0d3340', accent: '#2dd4bf', accentSecondary: '#fbbf24' },
  { id: 9, sceneKey: 'energy_water', title: 'آب و ظرف', subtitle: 'همه‌چیز انرژی و نور است', start: 420, end: 450, bgTop: '#041a2e', bgBottom: '#0a2d48', accent: '#38bdf8', accentSecondary: '#67e8f9' },
  { id: 10, sceneKey: 'six_steps', title: 'شش گام', subtitle: 'از تسلیم تا صدّق بالحُسنی', start: 450, end: 540, bgTop: '#0f1028', bgBottom: '#1e1a40', accent: '#fbbf24', accentSecondary: '#4ade80' },
  { id: 11, sceneKey: 'heart_gps', title: 'دلِ با خدا', subtitle: 'هدایت، بی‌نیاز از GPS', start: 540, end: 600, bgTop: '#08201a', bgBottom: '#123628', accent: '#4ade80', accentSecondary: '#fbbf24' },
  { id: 12, sceneKey: 'all_knowing', title: 'علمِ بی‌کران', subtitle: 'حتی بال‌زدنِ یک پشه', start: 600, end: 630, bgTop: '#050d22', bgBottom: '#0f1c3a', accent: '#60a5fa', accentSecondary: '#fde68a' },
  { id: 13, sceneKey: 'sadaqa', title: 'صدّق بالحُسنی', subtitle: 'پیامِ خدا را تصدیق کن', start: 630, end: 720, bgTop: '#1d1130', bgBottom: '#2e1838', accent: '#fbbf24', accentSecondary: '#f472b6' },
  { id: 14, sceneKey: 'ghayb_vision', title: 'چشمِ دل', subtitle: 'تصور، شکر و لبخندِ پیشاپیش', start: 720, end: 800, bgTop: '#0e0f2a', bgBottom: '#1f1640', accent: '#c084fc', accentSecondary: '#fbbf24' },
  { id: 15, sceneKey: 'steadfast', title: 'پایداری', subtitle: 'سنّتِ پیامبران و پیشینیان', start: 800, end: 880.17, bgTop: '#0b1a16', bgBottom: '#16302a', accent: '#fbbf24', accentSecondary: '#4ade80' },
];

export const EP2_CAPTIONS: Ep2Cue[] = [
  { start: 0, end: 9, text: 'موشن گرافیک «تسلیم؛ رمزِ موفقیتِ پیامبران»', highlight: true },
  { start: 9, end: 19, text: 'داستانِ پیامبران بارها تکرار شده است…' },
  { start: 19, end: 28, text: 'و در همهٔ آن‌ها یک رمز پنهان است: تسلیم.' },
  { start: 28, end: 38, text: 'یونس، یوسف، ابراهیم، موسی، عیسی و پیامبرِ خاتم ﷺ…' },
  { start: 38, end: 47, text: 'همه را که ببینیم، جایی که تسلیم شدند…' },
  { start: 47, end: 55, text: 'همان‌جا شروعِ موفقیتِ زندگی‌شان بود.' },
  { start: 55, end: 62, text: 'تسلیم یعنی اسلام؛ اسلام یعنی تسلیم.' },
  { start: 62, end: 71, text: 'اولین کسی که «مُسلِم» نامیده شد، ابراهیم بود.' },
  { start: 71, end: 79, text: 'پیامبر فرمود: همه چون ابراهیم باشید.' },
  { start: 79, end: 87, text: 'ابراهیم یکتاپرست بود؛ نمادِ نخستینِ توحید.' },
  { start: 87, end: 95, text: 'حنیف بود، موحّد بود، بت‌شکن بود.' },
  { start: 95, end: 104, text: 'موسی، هارون را داشت؛ عیسی، حواریون را؛' },
  { start: 104, end: 112, text: 'و پیامبر ﷺ، علی ؏ را کنارِ خود داشت.' },
  { start: 112, end: 121, text: 'امّا ابراهیم هیچ‌کس را نداشت؛ تنها بود.' },
  { start: 121, end: 130, text: 'تنها بت‌ها را شکست و تنها ایستاد.' },
  { start: 130, end: 140, text: 'او را در آتش انداختند؛ و او گفت: خدایا، تو خود می‌دانی.' },
  { start: 140, end: 150, text: 'و آتش، سرد و سلامت شد؛ گلستان شد.', highlight: true },
  { start: 150, end: 162, text: 'ما هم باید این‌گونه باشیم؛ در اداره، در محلِ کار…' },
  { start: 162, end: 174, text: 'هر جا که هستیم، حتی در خانواده.' },
  { start: 174, end: 186, text: 'خودت را بپذیر، دوستانت را بپذیر، شرایط را بپذیر.' },
  { start: 186, end: 198, text: 'بتِ «منِ» درونت را بشکن…' },
  { start: 198, end: 210, text: 'منیّت، بزرگ‌ترین بتی است که باید شکسته شود.' },
  { start: 210, end: 222, text: 'تو خالقِ زندگیِ خودت هستی؛ می‌توانی درستش کنی.' },
  { start: 222, end: 232, text: 'فونداسیونِ غلط را خراب کن…' },
  { start: 232, end: 240, text: 'و روی پایهٔ تسلیم، دوباره بساز.' },
  { start: 240, end: 250, text: 'این تسلیم شدن‌ها، ثمره دارد؛ مثلِ تسلیمِ مریم.' },
  { start: 250, end: 260, text: 'گامِ اول: تسلیم. گامِ دوم: ورودیِ ذهن.' },
  { start: 260, end: 270, text: 'ذهنِ انسان مثلِ دستگاهِ ارسالِ فرکانس است.' },
  { start: 270, end: 280, text: 'ورودیِ خوب، پردازشِ خوب، و خروجیِ خوب می‌سازد.' },
  { start: 280, end: 290, text: 'سورهٔ حمد هم همین است: ستایش، ورودی؛ هدایت، پردازش…' },
  { start: 290, end: 300, text: 'و نعمت یا غضب، خروجی است.' },
  { start: 300, end: 312, text: 'باورِ فراوانی را در ذهنت نهادینه کن.' },
  { start: 312, end: 324, text: 'ذهن، مغز نیست؛ مغز فیزیکی است و دیده می‌شود.' },
  { start: 324, end: 336, text: 'ذهن متافیزیکی است؛ دیده نمی‌شود.' },
  { start: 336, end: 348, text: 'مثلِ باور، مثلِ ایمان؛ دیده نمی‌شود امّا هست.' },
  { start: 348, end: 360, text: 'الَّذِينَ يُؤْمِنُونَ بِالْغَيْبِ؛ ایمان به غیب.', highlight: true },
  { start: 360, end: 370, text: 'وقتی فرکانس می‌فرستی، وارد سیستمِ جهان می‌شود…' },
  { start: 370, end: 380, text: 'و به شکلِ نشانهٔ هدایت به تو برمی‌گردد.' },
  { start: 380, end: 390, text: 'در ماشین نشسته‌ای، رادیو چیزی می‌گوید؛ جوابِ سؤالت!' },
  { start: 390, end: 400, text: 'یا کودکی حرفی می‌زند، یا تلفنی زنگ می‌خورد.' },
  { start: 400, end: 410, text: 'یا سرِ راه از رهگذری نشانی می‌پرسی…' },
  { start: 410, end: 420, text: 'و همان‌جا راه برایت روشن می‌شود.' },
  { start: 420, end: 428, text: 'این‌ها جریانِ انرژی است.' },
  { start: 428, end: 436, text: 'مثلِ آب: در استوانه، استوانه می‌شود؛ در مستطیل، مستطیل.' },
  { start: 436, end: 444, text: 'در مثلث، مثلث؛ آب همه انرژی است، همه نور است.' },
  { start: 444, end: 450, text: 'ظرفِ ذهنت، شکلِ زندگی‌ات را می‌سازد.' },
  { start: 450, end: 462, text: 'گامِ چهارم: سیستم. گامِ پنجم: هدایت.' },
  { start: 462, end: 474, text: 'گامِ ششم: صدّق بالحُسنی؛ تأیید کن.' },
  { start: 474, end: 486, text: 'تأیید کن که این نشانه‌های هدایت از سوی خداست.' },
  { start: 486, end: 498, text: 'فرزندت زنگ می‌زند، کسی که به یادش بودی پیدا می‌شود…' },
  { start: 498, end: 510, text: 'اول تسلیم شو؛ دوم، ورودی‌های ذهن را درست کن.' },
  { start: 510, end: 520, text: 'سوم، فرکانس بفرست؛ زندگی‌ات را با باور و عمل بساز.' },
  { start: 520, end: 530, text: 'چهارم، سیستمِ جهانِ آفرینش که قانونمند است.' },
  { start: 530, end: 540, text: 'پنجم، هدایت؛ و ششم، تصدیقِ نیکی‌ها.' },
  { start: 540, end: 550, text: 'هدایت می‌شوی؛ لازم نیست حتماً موبایل داشته باشی.' },
  { start: 550, end: 560, text: 'نیازی به GPS نیست؛ دلت با خدا باشد.' },
  { start: 560, end: 572, text: 'نشانه‌ها را ببین؛ با پیکان یا با قاطر، به مقصد می‌رسی.' },
  { start: 572, end: 586, text: 'خدا برای همه‌چیز راه را معلوم کرده است.' },
  { start: 586, end: 600, text: 'کافی است دل بسپاری و نشانه‌ها را دنبال کنی.' },
  { start: 600, end: 610, text: 'خدا همه‌چیز را می‌داند…' },
  { start: 610, end: 620, text: 'حتی بال‌زدنِ یک پشه را.' },
  { start: 620, end: 630, text: 'وَلَٰكِنَّ أَكْثَرَهُمْ لَا يَعْلَمُونَ؛ امّا بیشترِ مردم نمی‌دانند.' },
  { start: 630, end: 642, text: 'پس این می‌شود هدایت…' },
  { start: 642, end: 654, text: 'و در آخر: خدا برایت پیام فرستاده.' },
  { start: 654, end: 666, text: 'بگو: دست‌مریزاد خدا؛ پیامت رسید.' },
  { start: 666, end: 680, text: 'تأیید کن، تصدیق کن؛ صدّق بالحُسنی.', highlight: true },
  { start: 680, end: 700, text: 'چه زیباست این راه؛ چه زیباست!' },
  { start: 700, end: 720, text: 'تفاوت در همین دیدن است.' },
  { start: 720, end: 735, text: 'اگر مسلمان باشی و درست ببینی، مشکلی نمی‌ماند.' },
  { start: 735, end: 750, text: 'با بینش و تصور، بشارت را از قبل ببین.' },
  { start: 750, end: 765, text: 'شکرِ خدا را بگو؛ لبخند بزن.' },
  { start: 765, end: 780, text: 'این کارِ غیبی است؛ غیب در کار است.' },
  { start: 780, end: 800, text: 'تصویرش را بکش، و با شکر منتظرش باش.' },
  { start: 800, end: 815, text: 'پایدار باش؛ اشتیاقِ پایدار داشته باش.' },
  { start: 815, end: 835, text: 'بایدها را با تسلیم پیش ببر.' },
  { start: 835, end: 855, text: 'سنّتِ پیشینیان همین بوده است.' },
  { start: 855, end: 870, text: 'پیامبر ﷺ همیشه همین را آموزش می‌داد.' },
  { start: 870, end: 880.17, text: 'تسلیم ۝ صدّق بالحُسنی ۝ فَسَنُيَسِّرُهُ لِلْيُسْرَىٰ', highlight: true },
];

export function getEp2Chapter(t: number): Ep2Chapter {
  for (const c of EP2_CHAPTERS) if (t >= c.start && t < c.end) return c;
  return t < 0 ? EP2_CHAPTERS[0] : EP2_CHAPTERS[EP2_CHAPTERS.length - 1];
}

export function getEp2Caption(t: number): Ep2Cue | null {
  return EP2_CAPTIONS.find((c) => t >= c.start && t < c.end) ?? null;
}
