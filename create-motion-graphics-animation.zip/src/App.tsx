import { useCallback, useEffect, useRef, useState } from 'react';
import { CHAPTERS, INTRO, TOTAL, VOICE_DUR, drawMotionFrame, energyAt } from './motion/renderer';
import { formatTimeFa, toFaDigits } from './motion/prims';
import { FILE_INFO, FINAL_VIDEO_URL, GROUPS } from './links';

const VOICE_URL = 'https://raw.githubusercontent.com/midiovfxy-svg2/gamnasr/main/nasr-s1-e5.mp3';

/** Tiny generative ambient pad so the in-browser preview also has a soft bed under the voice. */
class AmbientPad {
  private ctx?: AudioContext;
  private master?: GainNode;
  private ensure() {
    if (this.ctx) return;
    const AC: typeof AudioContext = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AC();
    const master = ctx.createGain();
    master.gain.value = 0;
    const lp = ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 900;
    lp.connect(master);
    master.connect(ctx.destination);
    [73.42, 146.83, 220, 293.66, 349.23, 440].forEach((f, i) => {
      for (const det of [-5, 6]) {
        const o = ctx.createOscillator();
        o.type = i < 2 ? 'sine' : 'triangle';
        o.frequency.value = f;
        o.detune.value = det;
        const g = ctx.createGain();
        g.gain.value = 0.2 / (i + 1.5);
        const l = ctx.createOscillator();
        l.frequency.value = 0.05 + i * 0.027;
        const lg = ctx.createGain();
        lg.gain.value = g.gain.value * 0.55;
        l.connect(lg);
        lg.connect(g.gain);
        o.connect(g);
        g.connect(lp);
        o.start();
        l.start();
      }
    });
    this.ctx = ctx;
    this.master = master;
  }
  set(on: boolean) {
    if (!on && !this.ctx) return;
    this.ensure();
    void this.ctx!.resume();
    this.master!.gain.setTargetAtTime(on ? 0.06 : 0, this.ctx!.currentTime, 0.5);
  }
}

function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!on)}
      className={`flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-bold transition ${
        on ? 'border-amber-400/60 bg-amber-400/15 text-amber-200' : 'border-slate-600/60 bg-slate-800/40 text-slate-400'
      }`}
    >
      <span className={`h-2 w-2 rounded-full ${on ? 'bg-amber-300 shadow-[0_0_8px_#fbbf24]' : 'bg-slate-600'}`} />
      {label}
    </button>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const padRef = useRef(new AmbientPad());
  const tRef = useRef(0);
  const playingRef = useRef(false);
  const audioOkRef = useRef(true);
  const optsRef = useRef({ showSubtitles: true, showHud: true });

  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [subs, setSubs] = useState(true);
  const [hud, setHud] = useState(true);
  const [music, setMusic] = useState(true);
  const [audioState, setAudioState] = useState<'idle' | 'ok' | 'error'>('idle');

  const draw = useCallback(() => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext('2d');
    if (!ctx) return;
    drawMotionFrame(ctx, tRef.current, c.width, c.height, energyAt(tRef.current), optsRef.current);
  }, []);

  // audio element
  useEffect(() => {
    const a = new Audio();
    a.preload = 'auto';
    a.src = VOICE_URL;
    a.addEventListener('canplay', () => setAudioState('ok'));
    a.addEventListener('error', () => {
      audioOkRef.current = false;
      setAudioState('error');
    });
    audioRef.current = a;
    return () => {
      a.pause();
      a.src = '';
    };
  }, []);

  // canvas sizing + fonts
  useEffect(() => {
    const c = canvasRef.current!;
    const dpr = Math.min(1.5, window.devicePixelRatio || 1);
    c.width = Math.round(1280 * dpr);
    c.height = Math.round(720 * dpr);
    draw();
    const fonts = (document as Document & { fonts?: FontFaceSet }).fonts;
    if (fonts) {
      Promise.all([
        fonts.load('700 20px "Vazirmatn"', 'فصل'),
        fonts.load('900 20px "Vazirmatn"', 'فصل'),
        fonts.load('500 20px "Vazirmatn"', 'فصل'),
        fonts.load('700 40px "Amiri"', 'إِيَّاكَ'),
      ])
        .catch(() => undefined)
        .then(() => draw());
    }
  }, [draw]);

  // master clock
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    let lastUi = 0;
    const loop = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      if (playingRef.current) {
        const a = audioRef.current;
        const vt = tRef.current - INTRO;
        const inVoice = vt >= 0 && vt < VOICE_DUR - 0.05;
        if (a && audioOkRef.current && inVoice) {
          if (a.paused) {
            a.currentTime = Math.max(0, vt);
            void a.play().catch(() => {
              audioOkRef.current = false;
            });
            tRef.current += dt;
          } else if (a.readyState >= 2 && !a.seeking) {
            const target = a.currentTime + INTRO;
            tRef.current = Math.abs(target - tRef.current) > 0.25 ? target : tRef.current + dt + (target - tRef.current) * 0.1;
          }
          if (a.ended) tRef.current = INTRO + VOICE_DUR;
        } else {
          if (a && !a.paused) a.pause();
          tRef.current += dt;
        }
        if (tRef.current >= TOTAL) {
          tRef.current = TOTAL - 0.001;
          playingRef.current = false;
          setPlaying(false);
          padRef.current.set(false);
        }
        draw();
        if (now - lastUi > 250) {
          lastUi = now;
          setTime(tRef.current);
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [draw]);

  const toggle = useCallback(() => {
    const next = !playingRef.current;
    if (next && tRef.current >= TOTAL - 0.1) tRef.current = 0;
    playingRef.current = next;
    setPlaying(next);
    if (!next) audioRef.current?.pause();
    padRef.current.set(next && music);
  }, [music]);

  const seek = useCallback(
    (T: number) => {
      tRef.current = Math.max(0, Math.min(TOTAL - 0.01, T));
      const a = audioRef.current;
      const vt = tRef.current - INTRO;
      if (a && audioOkRef.current) {
        if (vt >= 0 && vt < VOICE_DUR) {
          try {
            a.currentTime = vt;
          } catch {
            /* not seekable yet */
          }
        } else a.pause();
      }
      setTime(tRef.current);
      draw();
    },
    [draw],
  );

  useEffect(() => {
    optsRef.current = { showSubtitles: subs, showHud: hud };
    draw();
  }, [subs, hud, draw]);
  useEffect(() => {
    padRef.current.set(playingRef.current && music);
  }, [music]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        toggle();
      } else if (e.code === 'ArrowLeft') seek(tRef.current + 5);
      else if (e.code === 'ArrowRight') seek(tRef.current - 5);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [toggle, seek]);

  const curCh = [...CHAPTERS].reverse().find((c) => time - INTRO >= c.start) || CHAPTERS[0];

  return (
    <div dir="rtl" className="min-h-screen bg-[#050814] text-slate-100" style={{ fontFamily: '"Vazirmatn", sans-serif' }}>
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(ellipse_at_top,rgba(251,191,36,0.10),transparent_55%),radial-gradient(ellipse_at_bottom_left,rgba(56,189,248,0.08),transparent_50%)]" />
      <div className="relative mx-auto max-w-6xl px-4 pb-20 pt-8 sm:px-6">
        {/* header */}
        <header className="mb-7 flex flex-col items-center text-center">
          <span className="mb-3 rounded-full border border-amber-400/40 bg-amber-400/10 px-4 py-1 text-xs font-bold text-amber-200">
            موشن‌گرافیک المان‌محور • فصل ۱ • قسمت ۵
          </span>
          <h1 className="text-5xl leading-tight text-amber-200 drop-shadow-[0_0_24px_rgba(251,191,36,0.45)] sm:text-6xl" style={{ fontFamily: '"Amiri", serif', fontWeight: 700 }}>
            إِيَّاكَ نَعْبُدُ
          </h1>
          <p className="mt-3 text-xl font-black sm:text-2xl">من فقط تو را انتخاب می‌کنم</p>
          <p className="mt-2 text-sm text-slate-400">برگرفته از بیانات استاد حاج نصرالله باستین • {toFaDigits('10:28')} دقیقه • ۷۲۰p</p>
        </header>

        {/* player */}
        <section className="overflow-hidden rounded-3xl border border-slate-700/60 bg-slate-900/60 shadow-[0_30px_90px_-30px_rgba(0,0,0,0.9)] backdrop-blur">
          <div ref={stageRef} className="group relative bg-black">
            <canvas ref={canvasRef} onClick={toggle} className="block aspect-video w-full cursor-pointer" />
            {!playing && (
              <button
                type="button"
                onClick={toggle}
                aria-label="پخش"
                className="absolute left-1/2 top-1/2 flex h-20 w-20 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-amber-300/70 bg-slate-950/70 text-amber-200 shadow-[0_0_40px_rgba(251,191,36,0.45)] transition hover:scale-110"
              >
                <svg viewBox="0 0 24 24" className="h-9 w-9 translate-x-0.5 fill-current">
                  <path d="M8 5v14l11-7z" />
                </svg>
              </button>
            )}
          </div>
          <div className="space-y-3 p-4">
            <div className="flex items-center gap-3" dir="ltr">
              <button
                type="button"
                onClick={toggle}
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-amber-400 text-slate-950 transition hover:bg-amber-300"
                aria-label={playing ? 'توقف' : 'پخش'}
              >
                <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current">
                  {playing ? <path d="M6 5h4v14H6zM14 5h4v14h-4z" /> : <path d="M8 5v14l11-7z" />}
                </svg>
              </button>
              <span className="w-12 shrink-0 text-center text-xs font-bold tabular-nums text-slate-300">{formatTimeFa(time)}</span>
              <div className="relative flex-1">
                <input
                  type="range"
                  min={0}
                  max={TOTAL}
                  step={0.1}
                  value={time}
                  onChange={(e) => seek(Number(e.target.value))}
                  className="h-2 w-full cursor-pointer accent-amber-400"
                  aria-label="نوار زمان"
                />
              </div>
              <span className="w-12 shrink-0 text-center text-xs font-bold tabular-nums text-slate-500">{formatTimeFa(TOTAL)}</span>
              <button
                type="button"
                onClick={() => stageRef.current?.requestFullscreen?.()}
                className="shrink-0 rounded-lg border border-slate-600/60 p-2 text-slate-300 hover:border-amber-400/60 hover:text-amber-200"
                aria-label="تمام‌صفحه"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-none stroke-current" strokeWidth="2">
                  <path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />
                </svg>
              </button>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap gap-2">
                <Toggle on={subs} onChange={setSubs} label="زیرنویس" />
                <Toggle on={hud} onChange={setHud} label="نوار فصل و زمان" />
                <Toggle on={music} onChange={setMusic} label="موسیقی زمینه (پیش‌نمایش)" />
              </div>
              <div className="text-xs text-slate-400">
                <span className="font-bold" style={{ color: curCh.accent }}>
                  {curCh.badge}
                </span>
                {'  '}
                {curCh.title}
                {audioState === 'error' && <span className="mr-3 text-rose-300">صدا بارگذاری نشد؛ تصویر بدون صدا پخش می‌شود.</span>}
              </div>
            </div>
          </div>
        </section>
        <p className="mt-3 text-center text-xs leading-6 text-slate-500">
          این پیش‌نمایش همان انیمیشن را زنده در مرورگر رندر می‌کند (صدای اصلی از گیت‌هاب). نسخهٔ نهایی با صدای تقویت‌شده، موسیقی زمینه و افکت‌های صوتی در فایل MP4 زیر است.
        </p>

        {/* downloads */}
        <section className="mt-8 rounded-3xl border border-amber-400/30 bg-gradient-to-br from-amber-400/10 via-slate-900/60 to-slate-900/60 p-6">
          <h2 className="text-2xl font-black text-amber-200">نسخهٔ نهایی و دانلود</h2>
          <p className="mt-1 text-sm text-slate-300">{FILE_INFO}</p>
          <div className="mt-5 overflow-hidden rounded-2xl border border-slate-700/60 bg-black">
            <video controls preload="none" className="block aspect-video w-full" src={FINAL_VIDEO_URL} />
          </div>
          <p className="mt-2 text-xs leading-6 text-slate-400">
            پخش مستقیمِ فایل نهایی از میزبان خارجی (صدای تقویت‌شده + موسیقی زمینه + افکت‌های صوتی). اگر میزبان فایل را حذف کرده باشد، از پیش‌نمایش زندهٔ بالا استفاده کنید.
          </p>
          {GROUPS.map((g) => (
            <div key={g.title} className="mt-7">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h3 className="text-lg font-black text-slate-100">{g.title}</h3>
                <span className="text-xs text-slate-400" dir="ltr">
                  {g.file} • {g.size}
                </span>
              </div>
              <div className="mt-3 grid gap-3 md:grid-cols-2">
                {g.links.map((d) => (
                  <a
                    key={d.url}
                    href={d.url}
                    target="_blank"
                    rel="noreferrer"
                    className="group flex items-center gap-4 rounded-2xl border border-slate-600/50 bg-slate-950/50 p-4 transition hover:border-amber-400/70 hover:bg-slate-900"
                  >
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-amber-400 text-slate-950 transition group-hover:scale-110">
                      <svg viewBox="0 0 24 24" className="h-6 w-6 fill-none stroke-current" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M12 4v11m0 0l-4.5-4.5M12 15l4.5-4.5M5 20h14" />
                      </svg>
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-2 font-black text-slate-100">
                        {d.host}
                        {d.direct && <span className="rounded-full bg-emerald-400/15 px-2 py-0.5 text-[10px] font-bold text-emerald-300">لینک مستقیم</span>}
                      </span>
                      <span className="block truncate text-xs text-sky-300" dir="ltr">
                        {d.url}
                      </span>
                      <span className="mt-0.5 block text-xs leading-5 text-slate-400">{d.note}</span>
                    </span>
                  </a>
                ))}
              </div>
            </div>
          ))}
        </section>

        {/* chapters */}
        <section className="mt-8">
          <h2 className="mb-4 text-xl font-black">فصل‌های انیمیشن</h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {CHAPTERS.map((c) => {
              const active = c.id === curCh.id;
              return (
                <button
                  type="button"
                  key={c.id}
                  onClick={() => seek(c.start + INTRO + (c.id === 1 ? -INTRO : 0))}
                  className={`rounded-2xl border p-4 text-right transition hover:-translate-y-0.5 ${active ? 'bg-slate-800/80' : 'bg-slate-900/50'}`}
                  style={{ borderColor: active ? c.accent : 'rgba(71,85,105,0.5)', background: active ? undefined : `linear-gradient(135deg, ${c.bgTop}, ${c.bgBottom})` }}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold" style={{ color: c.accent }}>
                      {c.badge}
                    </span>
                    <span className="tabular-nums text-slate-400">{formatTimeFa(c.start + INTRO)}</span>
                  </div>
                  <div className="mt-2 font-black leading-7 text-slate-100">{c.title}</div>
                </button>
              );
            })}
          </div>
        </section>

        {/* specs */}
        <section className="mt-8 grid gap-3 text-sm sm:grid-cols-2 lg:grid-cols-4">
          {[
            ['تصویر', '۱۲۸۰×۷۲۰ • ۳۰ فریم • H.264'],
            ['صدای سخنران', 'حذف نویز ملایم، کمپرسور و نرمال‌سازی تا ‎−۱۶ LUFS'],
            ['موسیقی زمینه', 'پدِ ملایمِ ساخته‌شده به‌صورت اختصاصی، با کاهش خودکار زیر صدا'],
            ['افکت‌های صوتی', 'هم‌زمان با ورود هر المان، آیه و تغییر فصل'],
          ].map(([k, v]) => (
            <div key={k} className="rounded-2xl border border-slate-700/60 bg-slate-900/50 p-4">
              <div className="text-xs font-bold text-amber-300">{k}</div>
              <div className="mt-1 leading-6 text-slate-300">{v}</div>
            </div>
          ))}
        </section>
        <p className="mt-6 text-center text-xs leading-6 text-slate-500">
          زیرنویس‌ها بر اساس رونویسی ماشینیِ صدا و ویرایش خلاصه تهیه شده‌اند و پیش از انتشار عمومی، بازبینی انسانی توصیه می‌شود. فضا: کلید Space برای پخش/توقف.
        </p>
      </div>
    </div>
  );
}
