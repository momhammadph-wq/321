export interface DownloadLink {
  host: string;
  url: string;
  note: string;
  direct?: boolean;
}

export interface DownloadGroup {
  title: string;
  file: string;
  size: string;
  links: DownloadLink[];
}

/** Verified direct link (HTTP 206, video/mp4, 93,184,805 bytes) – also used by the embedded <video>. */
export const FINAL_VIDEO_URL = 'https://x0.at/kmpC.mp4';

export const FILE_INFO = 'مدت ۱۰:۲۸ • ۱۲۸۰×۷۲۰ • ۳۰ فریم بر ثانیه • H.264 + AAC استریو • بارگذاری‌شده در ۱۰ نوامبر ۲۰۲۶';

export const GROUPS: DownloadGroup[] = [
  {
    title: 'ویدیوی نهایی (MP4)',
    file: 'iyyaka-nabudu-motion-720p.mp4',
    size: '93.2 MB',
    links: [
      { host: 'x0.at', url: 'https://x0.at/kmpC.mp4', note: 'لینک مستقیم فایل؛ آزمایش‌شده. ماندگاری طبق قوانین سایت (موقت، معمولاً چند هفته).', direct: true },
      { host: 'gofile.io', url: 'https://gofile.io/d/fTmTC9pc', note: 'صفحهٔ دانلود؛ در صورت عدم استفاده پس از مدتی حذف می‌شود.' },
      { host: 'uguu.se', url: 'https://h.uguu.se/nWOkfKbZ.mp4', note: 'لینک مستقیم؛ آزمایش‌شده، اما کوتاه‌مدت (چند ساعت).', direct: true },
      { host: 'tmpfiles.org', url: 'https://tmpfiles.org/wWA1WIblmg1X/iyyaka-nabudu-motion-720p.mp4', note: 'صفحهٔ دانلود؛ این سایت فایل را ۶۰ دقیقه پس از بارگذاری حذف می‌کند.' },
    ],
  },
  {
    title: 'صدای میکس‌شده (سخنرانی + موسیقی + افکت)',
    file: 'iyyaka-nabudu-audio-mix.mp3',
    size: '15.1 MB',
    links: [
      { host: 'x0.at', url: 'https://x0.at/OOS1.mp3', note: 'لینک مستقیم فایل MP3.', direct: true },
      { host: 'gofile.io', url: 'https://gofile.io/d/jtAkSpZd', note: 'صفحهٔ دانلود.' },
    ],
  },
  {
    title: 'سورس کامل انیمیشن',
    file: 'iyyaka-nabudu-source.zip',
    size: '53 KB',
    links: [
      { host: 'x0.at', url: 'https://x0.at/nQVB.zip', note: 'لینک مستقیم؛ موتور Canvas، خط زمانی، اسکریپت رندر و میکس.', direct: true },
      { host: 'gofile.io', url: 'https://gofile.io/d/oBVJQeSa', note: 'صفحهٔ دانلود.' },
    ],
  },
];
