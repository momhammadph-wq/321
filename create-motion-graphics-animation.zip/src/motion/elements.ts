// Reusable animated "elements": icon badges, kinetic pills, verse cards, info cards, stamps…
// Every element receives its `age` (seconds since it appeared) so pop-ins stay locked to the narration.
import {
  type Ctx,
  AR,
  FA,
  TAU,
  clamp01,
  easeOutBack,
  easeOutCubic,
  easeOutElastic,
  glowText,
  lerp,
  panel,
  ringBurst,
  rr,
  softGlow,
  withAlpha,
  wrapText,
} from './prims';
import { drawIcon } from './icons';

export const RED = '#f87171';
export const GREEN = '#4ade80';
export const GOLD = '#fbbf24';

/** Circular glass badge holding a vector icon. */
export function iconBadge(ctx: Ctx, icon: string, x: number, y: number, r: number, color: string, age: number, t: number) {
  if (age <= 0) return;
  const s = easeOutBack(age / 0.6);
  ringBurst(ctx, x, y, age / 0.9, color, r * 1.9);
  softGlow(ctx, x, y, r * 2.0, color, 0.2 * clamp01(age / 0.4));
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.globalAlpha *= clamp01(age / 0.25);
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, TAU);
  const g = ctx.createRadialGradient(-r * 0.3, -r * 0.4, r * 0.1, 0, 0, r);
  g.addColorStop(0, 'rgba(34,46,84,0.96)');
  g.addColorStop(1, 'rgba(8,12,28,0.96)');
  ctx.fillStyle = g;
  ctx.fill();
  ctx.lineWidth = Math.max(1.8, r * 0.045);
  ctx.strokeStyle = withAlpha(color, 0.9);
  ctx.stroke();
  ctx.save();
  ctx.rotate(t * 0.35);
  ctx.setLineDash([r * 0.16, r * 0.2]);
  ctx.lineWidth = 1.4;
  ctx.strokeStyle = withAlpha(color, 0.45);
  ctx.beginPath();
  ctx.arc(0, 0, r + 7, 0, TAU);
  ctx.stroke();
  ctx.restore();
  drawIcon(ctx, icon, 0, 0, r * 1.22, color, t);
  ctx.restore();
}

/** Kinetic floating Persian pill; icon sits on the right (RTL). `struck` 0..1 draws a red strike-through. */
export function pill(
  ctx: Ctx,
  cx: number,
  cy: number,
  label: string,
  age: number,
  color: string,
  icon?: string,
  t = 0,
  struck = 0,
  fs = 20,
) {
  if (age <= 0) return;
  const s = easeOutBack(age / 0.55);
  ringBurst(ctx, cx, cy, age / 0.8, color, 62);
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(s, s);
  ctx.globalAlpha *= clamp01(age / 0.22) * (1 - struck * 0.5);
  ctx.font = `700 ${fs}px ${FA}`;
  const tw = ctx.measureText(label).width;
  const h = fs + 26;
  const ic = icon ? h - 4 : 0;
  const w = tw + 40 + ic;
  ctx.save();
  ctx.scale(1, 0.5);
  softGlow(ctx, 0, 0, w * 0.62, color, 0.16);
  ctx.restore();
  panel(ctx, -w / 2, -h / 2, w, h, h / 2, struck > 0.5 ? RED : color, 0.8, 0.9);
  if (icon) {
    ctx.beginPath();
    ctx.arc(w / 2 - h / 2, 0, h / 2 - 5, 0, TAU);
    ctx.fillStyle = withAlpha(color, 0.2);
    ctx.fill();
    drawIcon(ctx, icon, w / 2 - h / 2, 0, h * 0.56, color, t);
  }
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#f8fafc';
  const tx = -ic / 2 + (icon ? 4 : 0);
  ctx.fillText(label, tx, 1);
  if (struck > 0) {
    ctx.strokeStyle = RED;
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(tx + tw / 2 + 6, 1);
    ctx.lineTo(tx + tw / 2 + 6 - (tw + 12) * easeOutCubic(struck), 1);
    ctx.stroke();
  }
  ctx.restore();
}

/** Ornamental Quran / key-sentence card: Amiri headline, Persian meaning, reference tab, light sweep. */
export function verseCard(
  ctx: Ctx,
  cx: number,
  cy: number,
  w: number,
  ar: string,
  fa: string | undefined,
  ref: string | undefined,
  age: number,
  color: string,
  t: number,
  energy: number,
) {
  if (age <= 0) return;
  const s = lerp(0.82, 1, easeOutBack(age / 0.8));
  const h = fa ? 176 : 124;
  ringBurst(ctx, cx, cy, age / 1.2, color, w * 0.5);
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(s, s);
  ctx.globalAlpha *= clamp01(age / 0.45);
  ctx.save();
  ctx.scale(1, 0.42);
  softGlow(ctx, 0, 0, w * 0.66, color, 0.24 + energy * 0.12);
  ctx.restore();
  panel(ctx, -w / 2, -h / 2, w, h, 24, color, 0.9, 0.92);
  // inner hairline frame + side rosettes
  ctx.strokeStyle = withAlpha(color, 0.3);
  ctx.lineWidth = 1;
  rr(ctx, -w / 2 + 9, -h / 2 + 9, w - 18, h - 18, 17);
  ctx.stroke();
  for (const sx of [-1, 1]) drawIcon(ctx, 'star8', (w / 2 - 38) * sx, 0, 30, color, t);
  // Arabic headline, auto-fitted
  let size = 48;
  ctx.font = `700 ${size}px ${AR}`;
  const mw = ctx.measureText(ar).width;
  if (mw > w - 150) size = Math.floor((size * (w - 150)) / mw);
  glowText(ctx, ar, 0, fa ? -20 : -2, `700 ${size}px ${AR}`, '#fde68a', withAlpha(color, 0.75), 14);
  if (fa) {
    const dw = (w - 220) * easeOutCubic((age - 0.3) / 0.8);
    ctx.strokeStyle = withAlpha(color, 0.5);
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.moveTo(-dw / 2, 24);
    ctx.lineTo(dw / 2, 24);
    ctx.stroke();
    ctx.globalAlpha *= clamp01((age - 0.5) / 0.5);
    glowText(ctx, fa, 0, 55, `700 23px ${FA}`, '#e2e8f0');
  }
  if (ref) {
    ctx.font = `700 14px ${FA}`;
    const rw = ctx.measureText(ref).width + 30;
    rr(ctx, -rw / 2, -h / 2 - 13, rw, 26, 13);
    ctx.fillStyle = '#0b1226';
    ctx.fill();
    ctx.strokeStyle = withAlpha(color, 0.8);
    ctx.lineWidth = 1.2;
    ctx.stroke();
    glowText(ctx, ref, 0, -h / 2 + 1, `700 14px ${FA}`, color);
  }
  // light sweep
  const sw = (age - 0.2) / 1.3;
  if (sw > 0 && sw < 1) {
    ctx.save();
    rr(ctx, -w / 2, -h / 2, w, h, 24);
    ctx.clip();
    const x = lerp(w / 2 + 80, -w / 2 - 80, sw);
    const g = ctx.createLinearGradient(x - 70, 0, x + 70, 0);
    g.addColorStop(0, 'rgba(255,255,255,0)');
    g.addColorStop(0.5, 'rgba(255,255,255,0.16)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.fillRect(x - 70, -h / 2, 140, h);
    ctx.restore();
  }
  ctx.restore();
}

/** Vertical info card that flips in: icon badge, bold title, optional 2-line caption. */
export function infoCard(
  ctx: Ctx,
  cx: number,
  cy: number,
  w: number,
  h: number,
  icon: string,
  title: string,
  sub: string | undefined,
  age: number,
  color: string,
  t: number,
) {
  if (age <= 0) return;
  const p = easeOutBack(age / 0.65);
  ringBurst(ctx, cx, cy - h / 2 + 70, age / 0.9, color, 90);
  ctx.save();
  ctx.translate(cx, cy + (1 - easeOutCubic(age / 0.6)) * 40 + Math.sin(t * 1.4 + cx * 0.01) * 4);
  ctx.scale(lerp(0.2, 1, p), 1);
  ctx.globalAlpha *= clamp01(age / 0.3);
  softGlow(ctx, 0, 0, w * 0.8, color, 0.13);
  panel(ctx, -w / 2, -h / 2, w, h, 22, color, 0.75, 0.9);
  iconBadge(ctx, icon, 0, -h / 2 + 76, 44, color, Math.max(0.61, age - 0.15), t);
  ctx.font = `800 22px ${FA}`;
  let lines = wrapText(ctx, title, w - 30, 2);
  const ty = -h / 2 + 156;
  lines.forEach((l, i) => glowText(ctx, l, 0, ty + i * 30, `800 22px ${FA}`, '#f8fafc', withAlpha(color, 0.5), 6));
  if (sub) {
    ctx.font = `500 16px ${FA}`;
    const sy = ty + lines.length * 30 + 6;
    lines = wrapText(ctx, sub, w - 34, 3);
    lines.forEach((l, i) => glowText(ctx, l, 0, sy + i * 25, `500 16px ${FA}`, '#cbd5e1'));
  }
  ctx.restore();
}

/** Rubber-stamp verdict that slams in with a small rotation. */
export function stamp(ctx: Ctx, x: number, y: number, text: string, age: number, color: string, rot = -0.1) {
  if (age <= 0) return;
  const p = clamp01(age / 0.35);
  const s = lerp(2.6, 1, easeOutCubic(p)) * (1 + 0.06 * (1 - easeOutElastic(clamp01(age / 0.9))));
  ringBurst(ctx, x, y, (age - 0.25) / 0.8, color, 150);
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(s, s);
  ctx.globalAlpha *= p;
  ctx.font = `900 26px ${FA}`;
  const w = ctx.measureText(text).width + 44;
  rr(ctx, -w / 2, -27, w, 54, 12);
  ctx.fillStyle = 'rgba(6,10,24,0.9)';
  ctx.fill();
  ctx.strokeStyle = color;
  ctx.lineWidth = 3;
  ctx.stroke();
  rr(ctx, -w / 2 + 5, -22, w - 10, 44, 8);
  ctx.lineWidth = 1;
  ctx.stroke();
  glowText(ctx, text, 0, 1, `900 26px ${FA}`, color, withAlpha(color, 0.6), 8);
  ctx.restore();
}

/** One line of kinetic typography: punches in from 1.3x, optional underline sweep. */
export function bigLine(ctx: Ctx, text: string, x: number, y: number, size: number, age: number, color: string, arabic = false, underline = false) {
  if (age <= 0) return;
  const p = clamp01(age / 0.5);
  const s = lerp(1.35, 1, easeOutBack(p));
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(s, s);
  ctx.globalAlpha *= clamp01(age / 0.3);
  const font = arabic ? `700 ${size}px ${AR}` : `900 ${size}px ${FA}`;
  glowText(ctx, text, 0, 0, font, color, withAlpha(color === '#f8fafc' ? '#38bdf8' : color, 0.55), size > 34 ? 14 : 8);
  if (underline) {
    ctx.font = font;
    const w = ctx.measureText(text).width * easeOutCubic((age - 0.25) / 0.7);
    ctx.strokeStyle = withAlpha(color, 0.8);
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(w / 2, size * 0.72);
    ctx.lineTo(-w / 2, size * 0.72);
    ctx.stroke();
  }
  ctx.restore();
}

/** Small right-aligned bullet row used inside comparison panels. */
export function bulletRow(ctx: Ctx, xRight: number, y: number, text: string, age: number, color: string, bad: boolean, t: number) {
  if (age <= 0) return;
  const p = easeOutCubic(age / 0.5);
  ctx.save();
  ctx.globalAlpha *= clamp01(age / 0.3);
  ctx.translate((1 - p) * 40, 0);
  drawIcon(ctx, bad ? 'cross' : 'check', xRight - 14, y, 30, bad ? RED : color, t);
  glowText(ctx, text, xRight - 40, y + 1, `600 19px ${FA}`, '#e2e8f0', undefined, 0, 'right');
  ctx.restore();
}
