// Hand-drawn vector icon set (100x100 box centred on 0,0). Everything is pure Canvas2D paths so the
// exact same artwork renders in the browser and in the offline Skia renderer.
import { type Ctx, AR, FA, TAU, withAlpha } from './prims';

type Fn = (c: Ctx, col: string, t: number) => void;
const PI = Math.PI;
const fill = (c: Ctx, col: string, a = 0.3) => {
  c.fillStyle = withAlpha(col, a);
  c.fill();
};
const line = (c: Ctx, x1: number, y1: number, x2: number, y2: number) => {
  c.beginPath();
  c.moveTo(x1, y1);
  c.lineTo(x2, y2);
  c.stroke();
};
const circ = (c: Ctx, x: number, y: number, r: number, f = 0, col = '') => {
  c.beginPath();
  c.arc(x, y, r, 0, TAU);
  if (f > 0) fill(c, col, f);
  c.stroke();
};
const poly = (c: Ctx, pts: number[], col: string, f = 0.3, close = true) => {
  c.beginPath();
  c.moveTo(pts[0], pts[1]);
  for (let i = 2; i < pts.length; i += 2) c.lineTo(pts[i], pts[i + 1]);
  if (close) c.closePath();
  if (f > 0) fill(c, col, f);
  c.stroke();
};
const spark = (c: Ctx, x: number, y: number, r: number) => {
  c.save();
  c.lineWidth = Math.max(2, r * 0.3);
  line(c, x - r, y, x + r, y);
  line(c, x, y - r, x, y + r);
  c.restore();
};
const box = (c: Ctx, x: number, y: number, w: number, h: number, col: string, f = 0.3) => {
  c.beginPath();
  c.rect(x, y, w, h);
  if (f > 0) fill(c, col, f);
  c.stroke();
};

const ICONS: Record<string, Fn> = {
  gold(c, col) {
    const bar = (x: number, y: number) => poly(c, [x - 16, y - 9, x + 16, y - 9, x + 23, y + 9, x - 23, y + 9], col, 0.42);
    bar(-23, 24);
    bar(23, 24);
    bar(0, 4);
    spark(c, 26, -24, 9);
    spark(c, -30, -14, 6);
  },
  coin(c, col) {
    circ(c, 0, 0, 36, 0.3, col);
    c.save();
    c.lineWidth = 2.5;
    circ(c, 0, 0, 26);
    c.restore();
    spark(c, 0, 0, 12);
  },
  scale(c, col) {
    line(c, 0, -34, 0, 34);
    line(c, -22, 36, 22, 36);
    line(c, -36, -26, 36, -26);
    for (const s of [-1, 1]) {
      c.save();
      c.lineWidth = 3;
      line(c, 36 * s, -26, 36 * s - 12, 4);
      line(c, 36 * s, -26, 36 * s + 12, 4);
      c.restore();
      c.beginPath();
      c.arc(36 * s, 4, 13, 0, PI);
      c.closePath();
      fill(c, col, 0.4);
      c.stroke();
    }
  },
  sajdah(c, col) {
    circ(c, -31, 17, 9, 0.45, col);
    c.beginPath();
    c.moveTo(-20, 14);
    c.quadraticCurveTo(-2, -24, 24, -6);
    c.lineTo(30, 25);
    c.lineTo(46, 26);
    c.stroke();
    line(c, -14, 8, -42, 28);
    c.save();
    c.lineWidth = 3;
    line(c, -48, 36, 48, 36);
    c.restore();
  },
  pray(c, col) {
    circ(c, 0, -30, 10, 0.45, col);
    line(c, 0, -18, 0, 14);
    line(c, 0, 14, -12, 40);
    line(c, 0, 14, 12, 40);
    poly(c, [0, -8, -18, -4, -24, -26], col, 0, false);
    poly(c, [0, -8, 18, -4, 24, -26], col, 0, false);
  },
  kaaba(c, col) {
    box(c, -30, -24, 60, 54, col, 0.4);
    c.save();
    c.strokeStyle = '#fde68a';
    line(c, -30, -8, 30, -8);
    c.lineWidth = 3;
    box(c, 6, 4, 13, 26, col, 0);
    c.restore();
  },
  heart(c, col) {
    c.beginPath();
    c.moveTo(0, 34);
    c.bezierCurveTo(-52, 2, -36, -38, 0, -12);
    c.bezierCurveTo(36, -38, 52, 2, 0, 34);
    fill(c, col, 0.4);
    c.stroke();
  },
  fork(c, col) {
    line(c, 0, 40, 0, 8);
    for (const s of [-1, 1]) {
      c.beginPath();
      c.moveTo(0, 8);
      c.quadraticCurveTo(-4 * s, -18, -30 * s, -30);
      c.stroke();
      poly(c, [-16 * s, -34, -30 * s, -30, -27 * s, -15], col, 0, false);
    }
  },
  sword(c, _col) {
    c.save();
    c.lineWidth = 6;
    line(c, -20, 20, 30, -30);
    c.lineWidth = 5;
    line(c, -32, 10, -10, 32);
    c.lineWidth = 8;
    line(c, -24, 24, -37, 37);
    c.restore();
  },
  shield(c, col) {
    c.beginPath();
    c.moveTo(0, -38);
    c.lineTo(30, -26);
    c.lineTo(30, 2);
    c.quadraticCurveTo(28, 26, 0, 40);
    c.quadraticCurveTo(-28, 26, -30, 2);
    c.lineTo(-30, -26);
    c.closePath();
    fill(c, col, 0.3);
    c.stroke();
    spark(c, 0, 0, 12);
  },
  tent(c, col) {
    poly(c, [0, -30, 40, 32, -40, 32], col, 0.32);
    c.save();
    c.lineWidth = 3;
    poly(c, [0, -2, 12, 32, -12, 32], col, 0.5);
    line(c, 0, -30, 0, -46);
    poly(c, [0, -46, 15, -41, 0, -36], col, 0.8);
    c.restore();
  },
  sun(c, col, t) {
    circ(c, 0, 0, 17, 0.5, col);
    c.save();
    c.rotate(t * 0.5);
    for (let i = 0; i < 8; i++) {
      c.rotate(TAU / 8);
      line(c, 26, 0, 38, 0);
    }
    c.restore();
  },
  moon(c, col) {
    c.beginPath();
    c.arc(0, 0, 32, 0.991, -0.991, false);
    c.arc(14, 0, 27, -1.44, 1.44, true);
    c.closePath();
    fill(c, col, 0.42);
    c.stroke();
    spark(c, 24, -12, 7);
  },
  mountain(c, col) {
    poly(c, [-46, 32, -14, -24, 4, 6, 18, -10, 46, 32], col, 0.32);
    c.save();
    c.lineWidth = 3;
    poly(c, [-22, -10, -14, -2, -6, -10], col, 0, false);
    c.restore();
  },
  key(c, col) {
    circ(c, -22, 0, 14, 0.3, col);
    line(c, -8, 0, 38, 0);
    line(c, 26, 0, 26, 13);
    line(c, 37, 0, 37, 10);
  },
  door(c, col) {
    c.beginPath();
    c.moveTo(-26, 40);
    c.lineTo(-26, -10);
    c.arc(0, -10, 26, PI, 0);
    c.lineTo(26, 40);
    c.closePath();
    fill(c, col, 0.22);
    c.stroke();
    c.beginPath();
    c.moveTo(-10, 40);
    c.lineTo(-10, -6);
    c.arc(0, -6, 10, PI, 0);
    c.lineTo(10, 40);
    c.closePath();
    fill(c, col, 0.7);
  },
  book(c, col) {
    for (const s of [-1, 1]) {
      c.beginPath();
      c.moveTo(0, -20);
      c.quadraticCurveTo(-22 * s, -32, -44 * s, -24);
      c.lineTo(-44 * s, 26);
      c.quadraticCurveTo(-22 * s, 18, 0, 30);
      c.closePath();
      fill(c, col, 0.3);
      c.stroke();
      c.save();
      c.lineWidth = 2.5;
      line(c, -12 * s, -12, -34 * s, -14);
      line(c, -12 * s, 0, -34 * s, -2);
      line(c, -12 * s, 12, -34 * s, 10);
      c.restore();
    }
  },
  sprout(c, col) {
    line(c, -34, 36, 34, 36);
    c.beginPath();
    c.moveTo(0, 36);
    c.quadraticCurveTo(-3, 10, 0, -6);
    c.stroke();
    c.beginPath();
    c.moveTo(0, -4);
    c.quadraticCurveTo(-30, -8, -36, -36);
    c.quadraticCurveTo(-6, -32, 0, -4);
    fill(c, col, 0.45);
    c.stroke();
    c.beginPath();
    c.moveTo(0, 8);
    c.quadraticCurveTo(26, 6, 36, -18);
    c.quadraticCurveTo(8, -18, 0, 8);
    fill(c, col, 0.45);
    c.stroke();
  },
  tree(c, col) {
    c.save();
    c.lineWidth = 7;
    line(c, 0, 42, 0, 10);
    c.restore();
    circ(c, -17, 4, 15, 0.35, col);
    circ(c, 17, 4, 15, 0.35, col);
    circ(c, 0, -14, 24, 0.4, col);
  },
  hands(c, _col) {
    for (const s of [-1, 1]) {
      c.beginPath();
      c.moveTo(-3 * s, 34);
      c.quadraticCurveTo(-42 * s, 30, -40 * s, -12);
      c.stroke();
      line(c, -24 * s, 12, -15 * s, -8);
    }
    spark(c, 0, -26, 10);
  },
  eye(c, col) {
    c.beginPath();
    c.moveTo(-42, 0);
    c.quadraticCurveTo(0, -38, 42, 0);
    c.quadraticCurveTo(0, 38, -42, 0);
    fill(c, col, 0.2);
    c.stroke();
    circ(c, 0, 0, 12, 0.7, col);
  },
  people(c, col) {
    const one = (x: number, y: number, r: number) => {
      circ(c, x, y, r, 0.45, col);
      c.beginPath();
      c.arc(x, y + r * 3.9, r * 2.1, PI, 0);
      c.closePath();
      fill(c, col, 0.3);
      c.stroke();
    };
    one(-28, -8, 8);
    one(28, -8, 8);
    one(0, -16, 11);
  },
  user(c, col) {
    circ(c, 0, -16, 14, 0.45, col);
    c.beginPath();
    c.moveTo(-30, 38);
    c.quadraticCurveTo(-30, 6, 0, 6);
    c.quadraticCurveTo(30, 6, 30, 38);
    c.closePath();
    fill(c, col, 0.3);
    c.stroke();
  },
  flag(c, col) {
    line(c, -24, -42, -24, 42);
    c.beginPath();
    c.moveTo(-24, -36);
    c.quadraticCurveTo(0, -48, 14, -34);
    c.quadraticCurveTo(28, -22, 40, -32);
    c.lineTo(40, 0);
    c.quadraticCurveTo(28, 10, 14, -2);
    c.quadraticCurveTo(0, -14, -24, -4);
    c.closePath();
    fill(c, col, 0.4);
    c.stroke();
  },
  clock(c, col, t) {
    circ(c, 0, 0, 34, 0.2, col);
    c.save();
    c.rotate(t * 0.8);
    line(c, 0, 0, 0, -24);
    c.restore();
    c.save();
    c.rotate(t * 0.07);
    line(c, 0, 0, 15, 0);
    c.restore();
  },
  chain(c, _col) {
    c.save();
    c.lineWidth = 6;
    for (const x of [-42, -2]) {
      c.beginPath();
      c.moveTo(x + 12, -12);
      c.lineTo(x + 32, -12);
      c.arc(x + 32, 0, 12, -PI / 2, PI / 2);
      c.lineTo(x + 12, 12);
      c.arc(x + 12, 0, 12, PI / 2, -PI / 2);
      c.stroke();
    }
    c.restore();
  },
  broken(c, _col) {
    c.save();
    c.lineWidth = 6;
    for (const s of [-1, 1]) {
      c.beginPath();
      c.arc(30 * s, 0, 13, s > 0 ? -PI * 0.75 : PI * 0.25, s > 0 ? PI * 0.75 : -PI * 0.25);
      c.stroke();
    }
    c.lineWidth = 3;
    line(c, 0, -10, 0, -26);
    line(c, -8, -8, -16, -22);
    line(c, 8, -8, 16, -22);
    line(c, 0, 10, 0, 24);
    c.restore();
  },
  star8(c, col) {
    box(c, -24, -24, 48, 48, col, 0.15);
    c.save();
    c.rotate(PI / 4);
    box(c, -24, -24, 48, 48, col, 0.15);
    c.restore();
    circ(c, 0, 0, 8, 0.8, col);
  },
  check(c, col) {
    circ(c, 0, 0, 34, 0.25, col);
    c.save();
    c.lineWidth = 7;
    poly(c, [-16, 2, -4, 14, 18, -12], col, 0, false);
    c.restore();
  },
  cross(c, col) {
    circ(c, 0, 0, 34, 0.25, col);
    c.save();
    c.lineWidth = 7;
    line(c, -13, -13, 13, 13);
    line(c, 13, -13, -13, 13);
    c.restore();
  },
  question(c, col) {
    circ(c, 0, 0, 34, 0.2, col);
    c.fillStyle = col;
    c.font = `900 50px ${FA}`;
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText('؟', 0, 3);
  },
  bolt(c, col) {
    poly(c, [8, -42, -22, 6, -2, 6, -10, 42, 24, -8, 2, -8], col, 0.5);
  },
  dumbbell(c, col) {
    c.save();
    c.lineWidth = 7;
    line(c, -22, 0, 22, 0);
    c.restore();
    box(c, -36, -22, 12, 44, col, 0.45);
    box(c, 24, -22, 12, 44, col, 0.45);
    box(c, -46, -12, 8, 24, col, 0.45);
    box(c, 38, -12, 8, 24, col, 0.45);
  },
  fire(c, col, t) {
    const w = Math.sin(t * 6) * 2;
    c.beginPath();
    c.moveTo(w, -42);
    c.bezierCurveTo(4, -18, 34, -6, 26, 20);
    c.bezierCurveTo(22, 36, 8, 42, 0, 42);
    c.bezierCurveTo(-18, 42, -30, 28, -26, 10);
    c.bezierCurveTo(-24, -2, -14, -8, -12, -20);
    c.bezierCurveTo(-4, -12, -2, -26, w, -42);
    fill(c, col, 0.4);
    c.stroke();
    c.beginPath();
    c.moveTo(0, 8);
    c.quadraticCurveTo(13, 22, 0, 34);
    c.quadraticCurveTo(-13, 22, 0, 8);
    fill(c, col, 0.75);
  },
  drop(c, col) {
    c.beginPath();
    c.moveTo(0, -40);
    c.bezierCurveTo(32, -2, 30, 38, 0, 38);
    c.bezierCurveTo(-30, 38, -32, -2, 0, -40);
    fill(c, col, 0.4);
    c.stroke();
  },
  crown(c, col) {
    poly(c, [-36, 24, -40, -16, -18, 4, 0, -28, 18, 4, 40, -16, 36, 24], col, 0.4);
    line(c, -36, 35, 36, 35);
  },
  compass(c, col, t) {
    circ(c, 0, 0, 36, 0.15, col);
    c.save();
    c.rotate(0.6 + Math.sin(t * 1.3) * 0.2);
    poly(c, [0, -26, 9, 0, 0, 26, -9, 0], col, 0.6);
    c.restore();
  },
  target(c, col) {
    circ(c, -4, 4, 34, 0.12, col);
    circ(c, -4, 4, 21, 0.12, col);
    circ(c, -4, 4, 7, 0.9, col);
    line(c, 2, -2, 40, -40);
    poly(c, [40, -40, 26, -38, 38, -26], col, 0.9);
  },
  bird(c, col) {
    c.beginPath();
    c.moveTo(-38, 8);
    c.quadraticCurveTo(-10, -20, 22, -6);
    c.lineTo(42, -14);
    c.lineTo(30, 4);
    c.quadraticCurveTo(10, 32, -38, 8);
    fill(c, col, 0.38);
    c.stroke();
    c.beginPath();
    c.moveTo(4, 0);
    c.quadraticCurveTo(-2, -40, -32, -36);
    c.quadraticCurveTo(-22, -12, -12, 2);
    fill(c, col, 0.5);
    c.stroke();
  },
  lamp(c, col) {
    circ(c, 0, -38, 5);
    line(c, -12, -28, 12, -28);
    poly(c, [-14, -26, -20, 22, 20, 22, 14, -26], col, 0.22);
    line(c, -24, 31, 24, 31);
    c.beginPath();
    c.moveTo(0, -14);
    c.bezierCurveTo(12, 0, 10, 14, 0, 14);
    c.bezierCurveTo(-10, 14, -12, 0, 0, -14);
    fill(c, col, 0.85);
  },
  ladder(c) {
    line(c, -18, 42, -9, -42);
    line(c, 18, 42, 9, -42);
    for (let i = 0; i < 4; i++) {
      const y = 28 - i * 20;
      const w = 15.5 - i * 2.1;
      line(c, -w, y, w, y);
    }
  },
  wave(c) {
    for (let k = 0; k < 3; k++) {
      const y = -18 + k * 18;
      c.beginPath();
      c.moveTo(-44, y);
      c.bezierCurveTo(-30, y - 14, -16, y + 14, 0, y);
      c.bezierCurveTo(16, y - 14, 30, y + 14, 44, y);
      c.stroke();
    }
  },
  staff(c) {
    c.save();
    c.lineWidth = 6;
    c.beginPath();
    c.moveTo(-16, 42);
    c.lineTo(8, -26);
    c.quadraticCurveTo(14, -46, 28, -36);
    c.quadraticCurveTo(34, -28, 26, -22);
    c.stroke();
    c.restore();
    spark(c, -26, -16, 8);
    spark(c, 32, 8, 6);
  },
  mosque(c, col) {
    c.beginPath();
    c.moveTo(-24, 10);
    c.quadraticCurveTo(-28, -18, -2, -32);
    c.quadraticCurveTo(24, -18, 20, 10);
    c.closePath();
    fill(c, col, 0.4);
    c.stroke();
    line(c, -2, -32, -2, -44);
    box(c, -34, 10, 62, 28, col, 0.25);
    c.save();
    c.lineWidth = 6;
    line(c, 41, -30, 41, 38);
    c.restore();
    poly(c, [35, -30, 41, -44, 47, -30], col, 0.8);
  },
  road(c, col) {
    poly(c, [-30, 42, -7, -38, 7, -38, 30, 42], col, 0.25);
    c.save();
    c.lineWidth = 3.5;
    line(c, 0, 32, 0, 18);
    line(c, 0, 6, 0, -6);
    line(c, 0, -16, 0, -26);
    c.restore();
  },
  gift(c, col) {
    box(c, -28, -8, 56, 44, col, 0.3);
    box(c, -34, -22, 68, 14, col, 0.5);
    line(c, 0, -22, 0, 36);
    circ(c, -11, -32, 9);
    circ(c, 11, -32, 9);
  },
  wheat(c, col) {
    line(c, 0, 44, 0, -12);
    for (let i = 0; i < 4; i++) {
      const y = -32 + i * 14;
      for (const s of [-1, 1]) {
        c.beginPath();
        c.ellipse(10 * s, y, 6, 11, 0.6 * s, 0, TAU);
        fill(c, col, 0.5);
        c.stroke();
      }
    }
    c.beginPath();
    c.ellipse(0, -42, 5, 9, 0, 0, TAU);
    fill(c, col, 0.5);
    c.stroke();
  },
  stone(c, col) {
    poly(c, [-42, 32, -32, -4, -8, -24, 24, -16, 42, 32], col, 0.35);
    c.save();
    c.lineWidth = 2.5;
    poly(c, [-8, -24, -2, -4, -14, 12], col, 0, false);
    poly(c, [24, -16, 14, 6], col, 0, false);
    c.restore();
  },
  battery(c, col, t) {
    box(c, -38, -20, 66, 40, col, 0.12);
    box(c, 28, -8, 9, 16, col, 0.8);
    const n = 1 + (Math.floor(t * 1.6) % 4);
    for (let i = 0; i < Math.min(4, n); i++) {
      c.beginPath();
      c.rect(-32 + i * 14.5, -14, 10.5, 28);
      fill(c, col, 0.85);
    }
  },
  globe(c, col) {
    circ(c, 0, 0, 36, 0.2, col);
    c.save();
    c.lineWidth = 2.5;
    c.beginPath();
    c.ellipse(0, 0, 16, 36, 0, 0, TAU);
    c.stroke();
    line(c, -36, 0, 36, 0);
    line(c, -31, -18, 31, -18);
    line(c, -31, 18, 31, 18);
    c.restore();
  },
  up(c, col) {
    line(c, 0, 38, 0, -30);
    poly(c, [-20, -12, 0, -38, 20, -12], col, 0, false);
  },
  idol(c, col) {
    circ(c, 0, -26, 11, 0.4, col);
    poly(c, [-12, -12, 12, -12, 18, 22, -18, 22], col, 0.35);
    box(c, -28, 22, 56, 14, col, 0.5);
  },
  ship(c, col) {
    poly(c, [-40, 10, 40, 10, 27, 34, -27, 34], col, 0.4);
    line(c, 0, 10, 0, -40);
    poly(c, [4, -36, 30, 2, 4, 2], col, 0.5);
    poly(c, [-4, -26, -22, 2, -4, 2], col, 0.3);
  },
  link(c, col) {
    ICONS.chain(c, col, 0);
  },
  allah(c, col) {
    c.fillStyle = '#fde68a';
    c.font = `700 62px ${AR}`;
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.shadowColor = withAlpha(col, 0.8);
    c.shadowBlur = 10;
    c.fillText('الله', 0, -4);
  },
};

export const ICON_NAMES = Object.keys(ICONS);

/** Draw icon `name` centred on (x,y) fitted into a `size` px box. `txt:…` renders a short label instead. */
export function drawIcon(c: Ctx, name: string, x: number, y: number, size: number, color: string, t = 0) {
  c.save();
  c.translate(x, y);
  c.scale(size / 100, size / 100);
  c.strokeStyle = color;
  c.lineWidth = 5;
  c.lineCap = 'round';
  c.lineJoin = 'round';
  if (name.startsWith('txt:')) {
    const s = name.slice(4);
    c.fillStyle = color;
    c.font = `900 ${s.length > 2 ? 34 : 50}px ${FA}`;
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText(s, 0, 3);
  } else {
    (ICONS[name] || ICONS.star8)(c, color, t);
  }
  c.restore();
}
