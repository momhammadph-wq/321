// Core math / colour / drawing helpers shared by the browser player and the offline MP4 renderer.
export type Ctx = CanvasRenderingContext2D;

export const W = 1280;
export const H = 720;
export const FA = '"Vazirmatn", sans-serif';
export const AR = '"Amiri", serif';
export const TAU = Math.PI * 2;

export const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const easeOutCubic = (t: number) => 1 - Math.pow(1 - clamp01(t), 3);
export const easeInCubic = (t: number) => Math.pow(clamp01(t), 3);
export const easeInOutCubic = (t: number) => {
  const x = clamp01(t);
  return x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
};
export const easeOutBack = (t: number) => {
  const x = clamp01(t);
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};
export const easeOutElastic = (t: number) => {
  const x = clamp01(t);
  if (x === 0 || x === 1) return x;
  return Math.pow(2, -10 * x) * Math.sin((x * 10 - 0.75) * (TAU / 3)) + 1;
};
/** Progress (0..1) of something that starts at `at` and takes `dur` seconds. */
export const pr = (t: number, at: number, dur = 0.7) => clamp01((t - at) / dur);

const FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
export function toFaDigits(input: string | number): string {
  return String(input).replace(/\d/g, (d) => FA_DIGITS[Number(d)]);
}
export function formatTimeFa(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return toFaDigits(`${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}`);
}

const rgbCache = new Map<string, [number, number, number]>();
export function hexToRgb(hex: string): [number, number, number] {
  let v = rgbCache.get(hex);
  if (!v) {
    const n = parseInt(hex.replace('#', ''), 16);
    v = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
    rgbCache.set(hex, v);
  }
  return v;
}
export function lerpColor(hexA: string, hexB: string, t: number): string {
  const a = hexToRgb(hexA);
  const b = hexToRgb(hexB);
  const k = clamp01(t);
  return `rgb(${Math.round(lerp(a[0], b[0], k))},${Math.round(lerp(a[1], b[1], k))},${Math.round(lerp(a[2], b[2], k))})`;
}
export function withAlpha(hex: string, alpha: number): string {
  const c = hexToRgb(hex);
  return `rgba(${c[0]},${c[1]},${c[2]},${clamp01(alpha).toFixed(3)})`;
}

export function rr(ctx: Ctx, x: number, y: number, w: number, h: number, r: number) {
  const q = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + q, y);
  ctx.lineTo(x + w - q, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + q);
  ctx.lineTo(x + w, y + h - q);
  ctx.quadraticCurveTo(x + w, y + h, x + w - q, y + h);
  ctx.lineTo(x + q, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - q);
  ctx.lineTo(x, y + q);
  ctx.quadraticCurveTo(x, y, x + q, y);
  ctx.closePath();
}

/** Deterministic pseudo-random – keeps particles identical on every render pass. */
export function seeded(i: number): number {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453123;
  return x - Math.floor(x);
}

/** Cheap soft glow (radial gradient) – used instead of shadowBlur for large shapes. */
export function softGlow(ctx: Ctx, x: number, y: number, r: number, color: string, alpha: number) {
  if (alpha <= 0.003 || r <= 0) return;
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, withAlpha(color, alpha));
  g.addColorStop(0.55, withAlpha(color, alpha * 0.32));
  g.addColorStop(1, withAlpha(color, 0));
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, TAU);
  ctx.fill();
}

/** Slowly rotating Islamic geometric mandala (rings, Rub-el-Hizb squares, 12 rays, rosette). */
export function drawMandala(ctx: Ctx, cx: number, cy: number, radius: number, rot: number, color: string, alpha: number) {
  if (alpha <= 0.003) return;
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(rot);
  ctx.strokeStyle = withAlpha(color, alpha);
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, TAU);
  ctx.moveTo(radius * 0.84, 0);
  ctx.arc(0, 0, radius * 0.84, 0, TAU);
  const side = radius * 1.18;
  ctx.rect(-side / 2, -side / 2, side, side);
  ctx.stroke();
  ctx.save();
  ctx.rotate(Math.PI / 4);
  ctx.strokeRect(-side / 2, -side / 2, side, side);
  ctx.restore();
  ctx.beginPath();
  for (let i = 0; i < 12; i++) {
    const a = (i * TAU) / 12;
    ctx.moveTo(Math.cos(a) * radius * 0.42, Math.sin(a) * radius * 0.42);
    ctx.lineTo(Math.cos(a) * radius * 0.96, Math.sin(a) * radius * 0.96);
  }
  for (let i = 0; i <= 16; i++) {
    const a = (i * TAU) / 16;
    const r = i % 2 === 0 ? radius * 0.42 : radius * 0.24;
    if (i === 0) ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
    else ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
  }
  ctx.stroke();
  ctx.restore();
}

/** Drifting star-dust; every 5th mote takes the chapter accent and breathes with the voice. */
export function drawParticles(ctx: Ctx, t: number, accent: string, energy: number) {
  for (let i = 0; i < 70; i++) {
    const px = seeded(i * 3 + 1) * W + Math.sin(t * 0.3 + i) * 6;
    const py = (((seeded(i * 3 + 2) * H - t * (4 + seeded(i) * 9)) % H) + H) % H;
    const sz = 0.8 + seeded(i * 5) * 2.0;
    const tw = 0.25 + 0.55 * (0.5 + 0.5 * Math.sin(t * (1.2 + seeded(i * 7) * 2.5) + i));
    ctx.fillStyle = i % 5 === 0 ? withAlpha(accent, tw * (0.7 + energy * 0.5)) : `rgba(226,232,240,${(tw * 0.5).toFixed(3)})`;
    ctx.beginPath();
    ctx.arc(px, py, sz, 0, TAU);
    ctx.fill();
  }
}

export function glowText(
  ctx: Ctx,
  text: string,
  x: number,
  y: number,
  font: string,
  fill: string,
  glow?: string,
  blur = 14,
  align: CanvasTextAlign = 'center',
) {
  ctx.save();
  ctx.font = font;
  ctx.textAlign = align;
  ctx.textBaseline = 'middle';
  if (glow && blur > 0) {
    ctx.shadowColor = glow;
    ctx.shadowBlur = blur;
  }
  ctx.fillStyle = fill;
  ctx.fillText(text, x, y);
  ctx.restore();
}

export function wrapText(ctx: Ctx, text: string, maxWidth: number, maxLines = 2): string[] {
  const words = text.split(' ');
  const lines: string[] = [];
  let cur = '';
  for (const word of words) {
    const test = cur ? `${cur} ${word}` : word;
    if (ctx.measureText(test).width <= maxWidth) cur = test;
    else {
      if (cur) lines.push(cur);
      cur = word;
    }
  }
  if (cur) lines.push(cur);
  return lines.slice(0, maxLines);
}

/** Organic audio-reactive halo ring around a hero element. */
export function drawAura(ctx: Ctx, cx: number, cy: number, baseR: number, t: number, energy: number, color: string) {
  const r = baseR + energy * 16;
  softGlow(ctx, cx, cy, r * 1.7, color, 0.2 + energy * 0.16);
  ctx.save();
  ctx.lineWidth = 2;
  for (let k = 0; k < 2; k++) {
    ctx.strokeStyle = withAlpha(color, (k === 0 ? 0.5 : 0.22) + energy * 0.3);
    ctx.beginPath();
    for (let i = 0; i <= 72; i++) {
      const a = (i / 72) * TAU;
      const wave =
        Math.sin(a * 6 + t * (3.2 + k)) * (2.5 + energy * 11) + Math.cos(a * 10 - t * 2.2) * (1.5 + energy * 7);
      const q = r + k * 14 + wave;
      if (i === 0) ctx.moveTo(cx + Math.cos(a) * q, cy + Math.sin(a) * q);
      else ctx.lineTo(cx + Math.cos(a) * q, cy + Math.sin(a) * q);
    }
    ctx.closePath();
    ctx.stroke();
  }
  ctx.restore();
}

/** Expanding ring "impact" that accompanies an element pop-in (p: 0..1). */
export function ringBurst(ctx: Ctx, x: number, y: number, p: number, color: string, maxR = 70) {
  if (p <= 0 || p >= 1) return;
  const e = easeOutCubic(p);
  ctx.save();
  ctx.strokeStyle = withAlpha(color, (1 - p) * 0.75);
  ctx.lineWidth = 3 * (1 - p) + 0.5;
  ctx.beginPath();
  ctx.arc(x, y, maxR * e, 0, TAU);
  ctx.stroke();
  ctx.fillStyle = withAlpha(color, (1 - p) * 0.9);
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * TAU + 0.3;
    const d = maxR * (0.5 + 0.75 * e);
    ctx.beginPath();
    ctx.arc(x + Math.cos(a) * d, y + Math.sin(a) * d, 2.6 * (1 - p), 0, TAU);
    ctx.fill();
  }
  ctx.restore();
}

/** Animated dashed light filament between two points (p: draw progress 0..1). */
export function filament(ctx: Ctx, x1: number, y1: number, x2: number, y2: number, p: number, color: string, t: number) {
  if (p <= 0) return;
  const e = easeOutCubic(p);
  const ex = lerp(x1, x2, e);
  const ey = lerp(y1, y2, e);
  ctx.save();
  ctx.strokeStyle = withAlpha(color, 0.38);
  ctx.lineWidth = 1.6;
  ctx.setLineDash([5, 7]);
  ctx.lineDashOffset = -t * 14;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(ex, ey);
  ctx.stroke();
  ctx.setLineDash([]);
  // travelling spark
  const k = (t * 0.45 + seeded(x2 + y2)) % 1;
  ctx.fillStyle = withAlpha(color, 0.85 * p);
  ctx.beginPath();
  ctx.arc(lerp(x1, ex, k), lerp(y1, ey, k), 2.4, 0, TAU);
  ctx.fill();
  ctx.restore();
}

/** Frosted glass panel with accent border and a thin highlight on top. */
export function panel(ctx: Ctx, x: number, y: number, w: number, h: number, r: number, accent: string, borderAlpha = 0.7, fillAlpha = 0.86) {
  rr(ctx, x, y, w, h, r);
  const g = ctx.createLinearGradient(0, y, 0, y + h);
  g.addColorStop(0, `rgba(16,24,48,${fillAlpha})`);
  g.addColorStop(1, `rgba(7,11,26,${fillAlpha})`);
  ctx.fillStyle = g;
  ctx.fill();
  ctx.lineWidth = 1.6;
  ctx.strokeStyle = withAlpha(accent, borderAlpha);
  ctx.stroke();
  ctx.save();
  ctx.globalAlpha *= 0.5;
  ctx.strokeStyle = withAlpha(accent, 0.55);
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(x + r, y + 4);
  ctx.lineTo(x + w - r, y + 4);
  ctx.stroke();
  ctx.restore();
}
