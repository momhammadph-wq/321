// Frame compositor: backdrop → mandalas → particles → active scene → chapter sting → intro/outro → HUD → captions.
// `T` is film time in seconds; narration ("voice time") starts INTRO seconds into the film.
import {
  type Ctx,
  AR,
  FA,
  H,
  TAU,
  W,
  clamp01,
  drawMandala,
  drawParticles,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  formatTimeFa,
  glowText,
  lerp,
  lerpColor,
  rr,
  softGlow,
  toFaDigits,
  withAlpha,
  wrapText,
} from './prims';
import { drawBackdrop, drawLayout, layoutTimes } from './scenes';
import { iconBadge } from './elements';
import { CAPTIONS, CHAPTERS, FILM, VOICE_DUR } from './timeline';
import { ENERGY } from './energy';
import type { Chapter, SfxEvent } from './types';

export const INTRO = 3.0;
export const TOTAL = 628.0;
export const FPS = 30;
export { CHAPTERS, VOICE_DUR };

const RECAP = ['gold', 'sajdah', 'heart', 'hands', 'compass', 'sprout', 'check'];

export interface RenderOptions {
  showSubtitles: boolean;
  showHud: boolean;
}

// ---- voice energy (30 samples / second of narration, base-36 encoded) ----
const EN = new Float32Array(ENERGY.length);
for (let i = 0; i < ENERGY.length; i++) EN[i] = parseInt(ENERGY[i], 36) / 35;
export function energyAt(T: number): number {
  const x = (T - INTRO) * 30;
  const i = Math.floor(x);
  if (i < 1 || i >= EN.length - 2) return 0.22 + 0.14 * Math.sin(T * 2.4) * Math.sin(T * 0.9);
  const f = x - i;
  const a = (EN[i - 1] + 2 * EN[i] + EN[i + 1]) / 4;
  const b = (EN[i] + 2 * EN[i + 1] + EN[i + 2]) / 4;
  return a + (b - a) * f;
}

export function chapterIndexAt(vt: number): number {
  for (let i = CHAPTERS.length - 1; i >= 0; i--) if (vt >= CHAPTERS[i].start) return i;
  return 0;
}

function drawSting(ctx: Ctx, ch: Chapter, a: number, t: number) {
  // chapter title banner: in 0..0.5, hold, out 2.2..2.8
  if (a < 0 || a > 2.8) return;
  const vis = Math.min(clamp01(a / 0.35), clamp01((2.8 - a) / 0.55));
  ctx.save();
  ctx.globalAlpha = vis * 0.62;
  ctx.fillStyle = '#040712';
  ctx.fillRect(0, 0, W, H);
  ctx.globalAlpha = vis;
  const p = easeOutCubic(a / 0.6);
  const bw = lerp(200, 820, p);
  const g = ctx.createLinearGradient(640 - bw / 2, 0, 640 + bw / 2, 0);
  g.addColorStop(0, withAlpha(ch.accent, 0));
  g.addColorStop(0.5, withAlpha(ch.accent, 0.95));
  g.addColorStop(1, withAlpha(ch.accent, 0));
  ctx.fillStyle = g;
  ctx.fillRect(640 - bw / 2, 300, bw, 2.5);
  ctx.fillRect(640 - bw / 2, 420, bw, 2.5);
  drawMandala(ctx, 640, 360, 190, t * 0.2, ch.accent, 0.2 * vis);
  const s = easeOutBack(a / 0.55);
  ctx.translate(640, 360);
  ctx.scale(lerp(0.7, 1, s), lerp(0.7, 1, s));
  glowText(ctx, ch.badge, 0, -34, `700 21px ${FA}`, ch.accent2, withAlpha(ch.accent2, 0.5), 8);
  glowText(ctx, ch.title, 0, 12, `900 42px ${FA}`, '#f8fafc', withAlpha(ch.accent, 0.7), 16);
  ctx.restore();
}

function drawIntro(ctx: Ctx, T: number) {
  const out = clamp01((T - (INTRO - 0.35)) / 0.9);
  if (out >= 1) return;
  ctx.save();
  ctx.globalAlpha = 1 - out;
  ctx.fillStyle = 'rgba(4,7,18,0.86)';
  ctx.fillRect(0, 0, W, H);
  const m = easeOutCubic(T / 1.2);
  softGlow(ctx, 640, 330, 420 * m, '#fbbf24', 0.2);
  drawMandala(ctx, 640, 330, 250 * lerp(0.6, 1, m), T * 0.25, '#fbbf24', 0.3 * m);
  drawMandala(ctx, 640, 330, 170 * lerp(0.6, 1, m), -T * 0.35, '#38bdf8', 0.22 * m);
  const a1 = T - 0.3;
  if (a1 > 0) {
    ctx.save();
    const s = lerp(1.5, 1, easeOutBack(a1 / 0.7));
    ctx.translate(640, 292);
    ctx.scale(s, s);
    ctx.globalAlpha *= clamp01(a1 / 0.35);
    glowText(ctx, FILM.introAr, 0, 0, `700 84px ${AR}`, '#fde68a', 'rgba(251,191,36,0.75)', 26);
    ctx.restore();
  }
  const a2 = T - 1.05;
  if (a2 > 0) {
    ctx.save();
    ctx.globalAlpha *= clamp01(a2 / 0.4);
    glowText(ctx, FILM.introFa, 640, 392 + (1 - easeOutCubic(a2 / 0.5)) * 16, `900 34px ${FA}`, '#f8fafc', 'rgba(56,189,248,0.5)', 12);
    ctx.restore();
  }
  const a3 = T - 1.6;
  if (a3 > 0) {
    ctx.save();
    ctx.globalAlpha *= clamp01(a3 / 0.4);
    glowText(ctx, FILM.speaker, 640, 446, `600 21px ${FA}`, '#cbd5e1');
    ctx.restore();
  }
  ctx.restore();
}

function drawOutro(ctx: Ctx, T: number) {
  const a = T - (INTRO + FILM.outroAt);
  if (a <= 0) return;
  const p = easeOutCubic(a / 1.6);
  const fadeEnd = clamp01((TOTAL - T) / 0.8);
  ctx.save();
  ctx.globalAlpha = p;
  ctx.fillStyle = 'rgba(4,8,20,0.9)';
  ctx.fillRect(0, 0, W, H);
  ctx.globalAlpha = p;
  softGlow(ctx, 640, 320, 430, '#fbbf24', 0.2);
  drawMandala(ctx, 640, 320, 235, T * 0.12, '#fbbf24', 0.28);
  drawMandala(ctx, 640, 320, 160, -T * 0.18, '#4ade80', 0.2);
  const s = lerp(1.25, 1, easeOutBack(a / 0.9));
  ctx.save();
  ctx.translate(640, 286);
  ctx.scale(s, s);
  glowText(ctx, FILM.outroAr, 0, 0, `700 56px ${AR}`, '#fde68a', 'rgba(251,191,36,0.7)', 22);
  ctx.restore();
  ctx.globalAlpha = p * clamp01((a - 1.0) / 0.7);
  glowText(ctx, FILM.outroFa, 640, 374, `800 28px ${FA}`, '#4ade80', 'rgba(74,222,128,0.45)', 12);
  ctx.globalAlpha = p * clamp01((a - 2.0) / 0.7);
  glowText(ctx, FILM.credit, 640, 434, `500 19px ${FA}`, '#cbd5e1');
  ctx.globalAlpha = p;
  RECAP.forEach((ic, i) => iconBadge(ctx, ic, 640 + (3 - i) * 78, 522, 25, i % 2 ? '#4ade80' : '#fbbf24', a - 3 - i * 0.3, T));
  ctx.restore();
  if (fadeEnd < 1) {
    ctx.fillStyle = `rgba(0,0,0,${(1 - fadeEnd).toFixed(3)})`;
    ctx.fillRect(0, 0, W, H);
  }
}

export function drawMotionFrame(ctx: Ctx, T: number, pixelW: number, pixelH: number, energy: number, opts: RenderOptions) {
  const vt = T - INTRO;
  const ci = chapterIndexAt(vt);
  const ch = CHAPTERS[ci];
  const next = CHAPTERS[Math.min(CHAPTERS.length - 1, ci + 1)];
  const toEnd = ch.end - vt;
  const blend = toEnd < 1.2 && next !== ch ? easeInOutCubic(1 - toEnd / 1.2) : 0;

  ctx.save();
  ctx.setTransform(pixelW / W, 0, 0, pixelH / H, 0, 0);
  ctx.globalAlpha = 1;
  if ('direction' in ctx) ctx.direction = 'rtl';

  // 1. atmosphere
  const bg = ctx.createLinearGradient(0, 0, 0, H);
  bg.addColorStop(0, lerpColor(ch.bgTop, next.bgTop, blend));
  bg.addColorStop(1, lerpColor(ch.bgBottom, next.bgBottom, blend));
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);
  const rad = ctx.createRadialGradient(640, 345, 40, 640, 345, 760);
  rad.addColorStop(0, withAlpha(ch.accent, 0.13 + energy * 0.08));
  rad.addColorStop(1, 'rgba(3,6,18,0.66)');
  ctx.fillStyle = rad;
  ctx.fillRect(0, 0, W, H);

  // 2. sacred geometry + dust
  drawMandala(ctx, 640, 355, 310 + energy * 6, T * 0.045, ch.accent, 0.075);
  drawMandala(ctx, 640, 355, 220, -T * 0.06, ch.accent2, 0.065);
  drawParticles(ctx, T, ch.accent, energy);
  const local = vt - ch.start;
  const bdA = Math.min(ci === 0 ? 1 : clamp01(local / 1.0), next !== ch ? clamp01(toEnd / 0.6) : 1);
  drawBackdrop(ctx, ch.backdrop, T, ch.accent, ch.accent2, bdA);

  // 3. active scene phase
  const phz = ch.phases.find((p) => vt >= p.from && vt < p.to) || (vt < ch.phases[0].from ? ch.phases[0] : undefined);
  if (phz) {
    const fin = clamp01((vt - phz.from) / 0.45);
    const fout = clamp01((phz.to - vt) / 0.4);
    ctx.save();
    const stv = ci > 0 && local >= 0 && local < 2.8 ? Math.min(clamp01(local / 0.35), clamp01((2.8 - local) / 0.55)) : 0;
    ctx.globalAlpha = Math.min(fin, fout) * (1 - stv) * (1 - clamp01((T - INTRO - FILM.outroAt) / 1.0));
    const sc = 1 + (1 - easeOutCubic(fout)) * 0.05 + 0.012 * Math.sin(T * 0.37);
    ctx.translate(640 + Math.sin(T * 0.23) * 6, 360 + (1 - easeOutCubic(fin)) * 16);
    ctx.scale(sc, sc);
    ctx.translate(-640, -360);
    drawLayout(ctx, phz.layout, { vt, t: T, energy, ch, from: phz.from });
    ctx.restore();
  }

  // 4. chapter change: light wipe + title sting
  if (ci > 0) drawSting(ctx, ch, local, T);
  const wipe = next !== ch && toEnd < 0.5 ? 0.5 - toEnd : ci > 0 && local < 0.5 ? 0.5 + local : -1;
  if (wipe >= 0) {
    const x = lerp(W + 300, -300, wipe);
    const g = ctx.createLinearGradient(x - 260, 0, x + 260, 0);
    g.addColorStop(0, 'rgba(255,255,255,0)');
    g.addColorStop(0.5, withAlpha(next !== ch && toEnd < 0.5 ? next.accent : ch.accent, 0.3));
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.fillRect(x - 260, 0, 520, H);
  }

  // 5. intro / outro cards
  if (T < INTRO + 0.6) drawIntro(ctx, T);
  const inOutro = T > INTRO + FILM.outroAt;
  if (inOutro) drawOutro(ctx, T);

  // 6. HUD
  if (opts.showHud && !inOutro) {
    const hudA = clamp01((T - 1.2) / 0.8);
    ctx.save();
    ctx.globalAlpha = hudA;
    const top = ctx.createLinearGradient(0, 0, 0, 80);
    top.addColorStop(0, 'rgba(4,7,18,0.8)');
    top.addColorStop(1, 'rgba(4,7,18,0)');
    ctx.fillStyle = top;
    ctx.fillRect(0, 0, W, 80);
    // chapter badge (right)
    ctx.font = `700 16px ${FA}`;
    const label = `${ch.badge}  |  ${ch.title}`;
    const bw = Math.min(700, ctx.measureText(label).width + 46);
    rr(ctx, W - bw - 34, 18, bw, 40, 20);
    ctx.fillStyle = 'rgba(11,17,36,0.8)';
    ctx.fill();
    ctx.strokeStyle = withAlpha(ch.accent, 0.62);
    ctx.lineWidth = 1.4;
    ctx.stroke();
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = ch.accent;
    ctx.fillText(label, W - 56, 39);
    // time pill (left) + live voice meter
    rr(ctx, 34, 18, 160, 40, 20);
    ctx.fillStyle = 'rgba(11,17,36,0.8)';
    ctx.fill();
    ctx.strokeStyle = 'rgba(148,163,184,0.35)';
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.font = `700 15px ${FA}`;
    ctx.textAlign = 'center';
    ctx.fillStyle = '#e2e8f0';
    ctx.fillText(`${formatTimeFa(T)} / ${formatTimeFa(TOTAL)}`, 114, 39);
    for (let i = 0; i < 7; i++) {
      const hgt = 4 + (0.25 + 0.75 * Math.abs(Math.sin(T * (5 + i * 1.3) + i * 2))) * energy * 26;
      ctx.fillStyle = withAlpha(ch.accent, 0.85);
      ctx.fillRect(206 + i * 7, 39 - hgt / 2, 4, hgt);
    }
    // progress line with chapter ticks (fills right → left)
    const pct = clamp01(T / TOTAL);
    ctx.fillStyle = 'rgba(255,255,255,0.1)';
    ctx.fillRect(0, 0, W, 4);
    const bar = ctx.createLinearGradient(W, 0, 0, 0);
    bar.addColorStop(0, ch.accent);
    bar.addColorStop(1, ch.accent2);
    ctx.fillStyle = bar;
    ctx.fillRect(W * (1 - pct), 0, W * pct, 4);
    ctx.fillStyle = 'rgba(255,255,255,0.55)';
    for (const c of CHAPTERS) if (c.id > 1) ctx.fillRect(W * (1 - (c.start + INTRO) / TOTAL) - 1, 0, 2, 7);
    softGlow(ctx, W * (1 - pct), 2, 10, '#ffffff', 0.8);
    ctx.restore();
  }

  // 7. caption capsule
  if (opts.showSubtitles && !inOutro) {
    let cue = null;
    for (const c of CAPTIONS) {
      if (vt >= c.s && vt < c.e) {
        cue = c;
        break;
      }
    }
    if (cue) {
      const a = Math.min(clamp01((vt - cue.s) / 0.2), clamp01((cue.e - vt) / 0.15));
      ctx.save();
      ctx.globalAlpha = a;
      ctx.font = `600 22px ${FA}`;
      const lines = wrapText(ctx, cue.text, 960, 2);
      const boxH = lines.length === 2 ? 80 : 52;
      const boxY = H - boxH - 20 + (1 - a) * 6;
      const boxW = Math.min(1050, Math.max(...lines.map((l) => ctx.measureText(l).width)) + 76);
      rr(ctx, (W - boxW) / 2, boxY, boxW, boxH, 18);
      ctx.fillStyle = 'rgba(6,10,24,0.86)';
      ctx.fill();
      ctx.strokeStyle = withAlpha(cue.hl ? '#fbbf24' : ch.accent, 0.6);
      ctx.lineWidth = 1.4;
      ctx.stroke();
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = cue.hl ? '#fde68a' : '#f8fafc';
      if (lines.length === 1) ctx.fillText(lines[0], 640, boxY + boxH / 2 + 1);
      else {
        ctx.fillText(lines[0], 640, boxY + 24);
        ctx.fillText(lines[1], 640, boxY + 56);
      }
      ctx.restore();
    }
  }
  ctx.restore();
}

/** Sound-effect cue sheet derived from the very same timeline that drives the picture. */
export function getSfxEvents(): SfxEvent[] {
  const ev: SfxEvent[] = [
    { t: 0.12, k: 'boom' },
    { t: 0.32, k: 'chime' },
    { t: 1.05, k: 'pop' },
    { t: 1.6, k: 'pop' },
    { t: INTRO - 0.55, k: 'whoosh' },
  ];
  let lastPop = -9;
  CHAPTERS.forEach((ch, i) => {
    if (i > 0) {
      ev.push({ t: INTRO + ch.start - 0.5, k: 'whoosh' });
      ev.push({ t: INTRO + ch.start + 0.08, k: 'chime', g: 0.85 });
    }
    ch.phases.forEach((p, j) => {
      if (j > 0) ev.push({ t: INTRO + p.from - 0.12, k: 'swish' });
      const lt = layoutTimes(p.layout);
      lt.pops
        .slice()
        .sort((a, b) => a - b)
        .forEach((at) => {
          if (at - lastPop < 0.3) return;
          lastPop = at;
          ev.push({ t: INTRO + at, k: 'pop' });
        });
      lt.shimmer.forEach((at) => ev.push({ t: INTRO + at - 0.05, k: 'shimmer' }));
      lt.good.forEach((at) => ev.push({ t: INTRO + at, k: 'ding' }));
      lt.bad.forEach((at) => ev.push({ t: INTRO + at, k: 'thud' }));
    });
  });
  const o = INTRO + FILM.outroAt;
  ev.push({ t: o - 0.35, k: 'whoosh', g: 0.8 }, { t: o + 0.25, k: 'shimmer' });
  RECAP.forEach((_, i) => ev.push({ t: o + 3 + i * 0.3, k: 'pop', g: 0.9 }));
  return ev.sort((a, b) => a.t - b.t);
}

export const _unused = [TAU, toFaDigits];
