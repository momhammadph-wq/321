// Data-driven, element-oriented scene layouts + ambient backdrops.
import {
  type Ctx,
  FA,
  H,
  TAU,
  W,
  clamp01,
  drawAura,
  easeInOutCubic,
  easeOutBack,
  easeOutCubic,
  filament,
  glowText,
  lerp,
  panel,
  ringBurst,
  softGlow,
  toFaDigits,
  withAlpha,
} from './prims';
import { GREEN, RED, bigLine, bulletRow, iconBadge, infoCard, pill, stamp, verseCard } from './elements';
import { drawIcon } from './icons';
import type { Backdrop, Chapter, El, Layout, Side } from './types';

export interface SceneState {
  vt: number; // voice time
  t: number; // global clock for ambient motion
  energy: number;
  ch: Chapter;
  from: number; // phase start (voice time)
}

type L<K extends Layout['kind']> = Extract<Layout, { kind: K }>;

const HERO_SLOTS = [
  [985, 212],
  [295, 212],
  [1042, 342],
  [238, 342],
  [978, 472],
  [302, 472],
  [640, 138],
  [640, 552],
];

function sceneTitle(ctx: Ctx, text: string, s: SceneState, y = 120) {
  const a = s.vt - s.from - 0.15;
  if (a <= 0) return;
  ctx.save();
  ctx.globalAlpha *= clamp01(a / 0.5);
  const p = easeOutCubic(a / 0.7);
  glowText(ctx, text, 640, y + (1 - p) * -14, `800 28px ${FA}`, '#f8fafc', withAlpha(s.ch.accent, 0.6), 10);
  ctx.font = `800 28px ${FA}`;
  const w = Math.min(520, ctx.measureText(text).width) * p;
  const g = ctx.createLinearGradient(640 - w / 2, 0, 640 + w / 2, 0);
  g.addColorStop(0, withAlpha(s.ch.accent, 0));
  g.addColorStop(0.5, withAlpha(s.ch.accent, 0.9));
  g.addColorStop(1, withAlpha(s.ch.accent, 0));
  ctx.fillStyle = g;
  ctx.fillRect(640 - w / 2, y + 24, w, 2.5);
  ctx.restore();
}

function hero(ctx: Ctx, l: L<'hero'>, s: SceneState) {
  const cx = 640;
  const cy = l.title ? 316 : 342;
  const col = l.color || s.ch.accent;
  const a0 = s.vt - s.from - 0.1;
  if (a0 > 0) {
    ctx.save();
    ctx.globalAlpha *= clamp01(a0 / 0.6);
    // slow light rays behind the hero
    ctx.translate(cx, cy);
    ctx.rotate(s.t * 0.12);
    for (let i = 0; i < 12; i++) {
      ctx.rotate(TAU / 12);
      const len = 150 + Math.sin(s.t * 1.7 + i) * 14 + s.energy * 34;
      const g = ctx.createLinearGradient(92, 0, 92 + len, 0);
      g.addColorStop(0, withAlpha(col, 0.3));
      g.addColorStop(1, withAlpha(col, 0));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(92, -6);
      ctx.lineTo(92 + len, 0);
      ctx.lineTo(92, 6);
      ctx.closePath();
      ctx.fill();
    }
    ctx.restore();
    ctx.save();
    ctx.globalAlpha *= clamp01(a0 / 0.6);
    drawAura(ctx, cx, cy, 106, s.t, s.energy, col);
    ctx.restore();
  }
  iconBadge(ctx, l.icon, cx, cy, 90, col, a0, s.t);
  if (l.title && a0 > 0.4) {
    ctx.save();
    ctx.globalAlpha *= clamp01((a0 - 0.4) / 0.5);
    glowText(ctx, l.title, cx, cy + 140, `800 27px ${FA}`, '#f8fafc', withAlpha(col, 0.6), 10);
    if (l.sub) glowText(ctx, l.sub, cx, cy + 176, `500 18px ${FA}`, '#cbd5e1');
    ctx.restore();
  }
  l.items.forEach((it, i) => {
    const age = s.vt - it.at;
    if (age <= 0) return;
    const [sx, sy] = HERO_SLOTS[i % HERO_SLOTS.length];
    const fy = sy + Math.sin(s.t * 1.6 + i * 1.7) * 5;
    const c = it.bad ? RED : it.color || (i % 2 ? s.ch.accent2 : col);
    const ang = Math.atan2(fy - cy, sx - cx);
    filament(ctx, cx + Math.cos(ang) * 104, cy + Math.sin(ang) * 104, sx, fy, age / 0.6, c, s.t);
    const struck = l.strikeAt != null ? clamp01((s.vt - l.strikeAt - i * 0.16) / 0.5) : 0;
    pill(ctx, sx, fy, it.label, age, c, it.icon || (it.bad ? 'cross' : undefined), s.t, struck);
  });
  if (l.verdict) stamp(ctx, 640, 556, l.verdict.text, s.vt - l.verdict.at, l.verdict.good ? GREEN : RED, -0.05);
}

function versus(ctx: Ctx, l: L<'versus'>, s: SceneState) {
  const w = 480;
  const h = 440;
  const y0 = 128;
  const side = (sd: Side, x0: number, dir: number) => {
    const age = s.vt - sd.at;
    if (age <= 0) return;
    const p = easeOutCubic(age / 0.7);
    ctx.save();
    ctx.translate(dir * (1 - p) * 140, 0);
    ctx.globalAlpha *= clamp01(age / 0.4);
    softGlow(ctx, x0 + w / 2, y0 + h / 2, 340, sd.color, 0.1 + s.energy * 0.04);
    panel(ctx, x0, y0, w, h, 26, sd.color, 0.7, 0.84);
    iconBadge(ctx, sd.icon, x0 + w - 72, y0 + 68, 44, sd.color, age - 0.2, s.t);
    glowText(ctx, sd.name, x0 + w - 134, y0 + (sd.sub ? 52 : 68), `900 30px ${FA}`, '#f8fafc', withAlpha(sd.color, 0.6), 8, 'right');
    if (sd.sub) glowText(ctx, sd.sub, x0 + w - 134, y0 + 90, `500 17px ${FA}`, '#cbd5e1', undefined, 0, 'right');
    const dw = (w - 48) * easeOutCubic((age - 0.3) / 0.7);
    ctx.fillStyle = withAlpha(sd.color, 0.4);
    ctx.fillRect(x0 + w - 24 - dw, y0 + 130, dw, 1.5);
    sd.items.forEach((it, i) => bulletRow(ctx, x0 + w - 30, y0 + 168 + i * 44, it.label, s.vt - it.at, sd.color, !!it.bad, s.t));
    ctx.restore();
    if (sd.verdict) stamp(ctx, x0 + w / 2 - 70, y0 + h - 40, sd.verdict.text, s.vt - sd.verdict.at, sd.verdict.good ? GREEN : RED, dir * 0.07);
  };
  side(l.right, 660, 1);
  side(l.left, 140, -1);
  const am = s.vt - Math.max(l.right.at, l.left.at) - 0.3;
  if (l.mid && am > 0) {
    const sc = easeOutBack(am / 0.5) * (1 + s.energy * 0.08);
    ctx.save();
    ctx.translate(640, y0 + h / 2);
    ctx.scale(sc, sc);
    ctx.beginPath();
    ctx.arc(0, 0, 31, 0, TAU);
    ctx.fillStyle = '#0b1226';
    ctx.fill();
    ctx.strokeStyle = s.ch.accent;
    ctx.lineWidth = 2;
    ctx.stroke();
    glowText(ctx, l.mid, 0, 1, `900 20px ${FA}`, s.ch.accent);
    ctx.restore();
  }
}

function path(ctx: Ctx, l: L<'path'>, s: SceneState) {
  const n = l.steps.length;
  const pts = l.steps.map((_, i) => {
    const k = n === 1 ? 0.5 : i / (n - 1);
    return [lerp(1085, 195, k), (l.fall ? lerp(215, 430, k) : lerp(450, 240, k)) + Math.sin(i * 2.1 + 0.5) * 18];
  });
  if (l.title) sceneTitle(ctx, l.title, s);
  const a0 = s.vt - s.from;
  ctx.save();
  ctx.globalAlpha *= clamp01(a0 / 0.6);
  ctx.strokeStyle = 'rgba(148,163,184,0.25)';
  ctx.lineWidth = 2;
  ctx.setLineDash([3, 9]);
  ctx.beginPath();
  pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])));
  ctx.stroke();
  ctx.restore();
  for (let i = 1; i < n; i++) {
    const p = easeInOutCubic((s.vt - (l.steps[i].at - 0.55)) / 0.6);
    if (p <= 0) continue;
    const ex = lerp(pts[i - 1][0], pts[i][0], p);
    const ey = lerp(pts[i - 1][1], pts[i][1], p);
    for (const [lw, al] of [
      [9, 0.16],
      [3, 0.9],
    ]) {
      ctx.strokeStyle = withAlpha(s.ch.accent, al);
      ctx.lineWidth = lw;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(pts[i - 1][0], pts[i - 1][1]);
      ctx.lineTo(ex, ey);
      ctx.stroke();
    }
    if (p < 1) softGlow(ctx, ex, ey, 22, '#ffffff', 0.7);
  }
  l.steps.forEach((st, i) => {
    const age = s.vt - st.at;
    if (age <= 0) return;
    const c = st.bad ? RED : st.color || (i % 2 ? s.ch.accent2 : s.ch.accent);
    const y = pts[i][1] + Math.sin(s.t * 1.5 + i) * 4;
    iconBadge(ctx, st.icon || `txt:${toFaDigits(i + 1)}`, pts[i][0], y, 44, c, age, s.t);
    pill(ctx, pts[i][0], y + 76, st.label, age - 0.15, c, undefined, s.t, 0, 18);
    if (st.sub && age > 0.4) {
      ctx.save();
      ctx.globalAlpha *= clamp01((age - 0.4) / 0.4);
      glowText(ctx, st.sub, pts[i][0], y + 112, `500 15px ${FA}`, '#cbd5e1');
      ctx.restore();
    }
  });
}

function rowPills(ctx: Ctx, items: El[], s: SceneState, y0: number, perRow = 3, dx = 300) {
  items.forEach((it, i) => {
    const row = Math.floor(i / perRow);
    const inRow = Math.min(perRow, items.length - row * perRow);
    const j = i % perRow;
    const x = 640 + ((inRow - 1) / 2 - j) * dx;
    const c = it.bad ? RED : it.color || (i % 2 ? s.ch.accent2 : s.ch.accent);
    pill(ctx, x, y0 + row * 72 + Math.sin(s.t * 1.5 + i * 1.3) * 4, it.label, s.vt - it.at, c, it.icon || (it.bad ? 'cross' : undefined), s.t);
  });
}

function verse(ctx: Ctx, l: L<'verse'>, s: SceneState) {
  const has = !!(l.items && l.items.length);
  verseCard(ctx, 640, has ? 250 : 335, 900, l.ar, l.fa, l.ref, s.vt - l.at, s.ch.accent, s.t, s.energy);
  if (has) rowPills(ctx, l.items!, s, 430);
}

function cards(ctx: Ctx, l: L<'cards'>, s: SceneState) {
  const n = l.items.length;
  const gap = 26;
  const w = Math.min(250, (1100 - (n - 1) * gap) / n);
  const total = n * w + (n - 1) * gap;
  if (l.title) sceneTitle(ctx, l.title, s);
  l.items.forEach((it, i) => {
    const x = 640 + total / 2 - w / 2 - i * (w + gap);
    const c = it.bad ? RED : it.color || (i % 2 ? s.ch.accent2 : s.ch.accent);
    infoCard(ctx, x, 372, w, 300, it.icon || 'star8', it.label, it.sub, s.vt - it.at, c, s.t);
  });
}

function fork(ctx: Ctx, l: L<'fork'>, s: SceneState) {
  const O = [1040, 345];
  const J = [760, 345];
  const U = [300, 212];
  const D = [300, 478];
  const C = [520, 345];
  const a0 = s.vt - l.from.at;
  if (a0 <= 0) return;
  const c = s.vt - l.chooseAt;
  const bez = (E: number[], k: number) => [
    (1 - k) * (1 - k) * J[0] + 2 * (1 - k) * k * C[0] + k * k * E[0],
    (1 - k) * (1 - k) * J[1] + 2 * (1 - k) * k * C[1] + k * k * E[1],
  ];
  const upC = l.up.color || GREEN;
  const dnC = l.down.color || RED;
  const road = (E: number[], col: string, alpha: number, prog: number) => {
    ctx.save();
    ctx.globalAlpha *= alpha;
    for (const [lw, al, dash] of [
      [22, 0.1, 0],
      [3, 0.85, 1],
    ]) {
      ctx.strokeStyle = withAlpha(col, al);
      ctx.lineWidth = lw;
      ctx.lineCap = 'round';
      if (dash) {
        ctx.setLineDash([12, 12]);
        ctx.lineDashOffset = s.t * 22;
      } else ctx.setLineDash([]);
      ctx.beginPath();
      ctx.moveTo(J[0], J[1]);
      for (let k = 0.04; k <= prog + 0.001; k += 0.04) {
        const p = bez(E, k);
        ctx.lineTo(p[0], p[1]);
      }
      ctx.stroke();
    }
    ctx.restore();
  };
  // trunk road
  const tp = easeOutCubic(a0 / 0.8);
  ctx.save();
  ctx.strokeStyle = withAlpha(s.ch.accent, 0.8);
  ctx.lineWidth = 3;
  ctx.setLineDash([12, 12]);
  ctx.lineDashOffset = s.t * 22;
  ctx.beginPath();
  ctx.moveTo(O[0], O[1]);
  ctx.lineTo(lerp(O[0], J[0], tp), J[1]);
  ctx.stroke();
  ctx.restore();
  const upOn = l.choose === 'up';
  const fadeLose = c > 0 ? lerp(1, 0.28, clamp01(c / 1.0)) : 1;
  road(U, upC, upOn ? 1 : fadeLose, easeOutCubic((s.vt - l.up.at + 0.5) / 0.9));
  road(D, dnC, upOn ? fadeLose : 1, easeOutCubic((s.vt - l.down.at + 0.5) / 0.9));
  // destinations
  for (const [E, el, col, on] of [
    [U, l.up, upC, upOn],
    [D, l.down, dnC, !upOn],
  ] as [number[], El, string, boolean][]) {
    const age = s.vt - el.at;
    if (age <= 0) continue;
    ctx.save();
    ctx.globalAlpha *= on ? 1 : fadeLose;
    if (on && c > 1.4) softGlow(ctx, E[0], E[1], 150 + s.energy * 30, col, 0.3);
    iconBadge(ctx, el.icon || 'star8', E[0], E[1], 60, col, age, s.t);
    pill(ctx, E[0], E[1] + 92, el.label, age - 0.15, col, undefined, s.t, 0, 20);
    ctx.restore();
  }
  iconBadge(ctx, l.from.icon || 'user', O[0], O[1], 62, s.ch.accent, a0, s.t);
  pill(ctx, O[0], O[1] + 96, l.from.label, a0 - 0.15, s.ch.accent, undefined, s.t, 0, 20);
  // the travelling soul
  let ox = J[0];
  let oy = J[1];
  if (c <= 0) {
    const k = clamp01((a0 - 0.6) / 1.2);
    ox = lerp(O[0] - 70, J[0], easeInOutCubic(k));
    if (k >= 1) {
      const wob = Math.sin(s.t * 5.2);
      const p = bez(wob > 0 ? U : D, Math.abs(wob) * 0.1);
      ox = p[0];
      oy = p[1];
    }
  } else {
    const p = bez(upOn ? U : D, easeInOutCubic(c / 1.5) * 0.86);
    ox = p[0];
    oy = p[1];
    ringBurst(ctx, (upOn ? U : D)[0], (upOn ? U : D)[1], (c - 1.4) / 1.0, upOn ? upC : dnC, 150);
  }
  if (a0 > 0.6) {
    softGlow(ctx, ox, oy, 34 + s.energy * 12, '#ffffff', 0.6);
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(ox, oy, 8, 0, TAU);
    ctx.fill();
  }
  if (l.note) pill(ctx, 660, 128, l.note.label, s.vt - l.note.at, l.note.color || s.ch.accent2, l.note.icon, s.t, 0, 22);
}

function quote(ctx: Ctx, l: L<'quote'>, s: SceneState) {
  const sizes = l.lines.map((x) => x.size || (x.ar ? 56 : 40));
  const gaps = sizes.map((z) => z * 1.6);
  const total = gaps.reduce((a, b) => a + b, 0);
  let y = (l.icon ? 392 : 345) - total / 2;
  if (l.icon) iconBadge(ctx, l.icon, 640, y - 64, 52, s.ch.accent, s.vt - s.from - 0.1, s.t);
  l.lines.forEach((ln, i) => {
    y += gaps[i] / 2;
    bigLine(ctx, ln.text, 640, y, sizes[i], s.vt - ln.at, ln.color || '#f8fafc', !!ln.ar, i === l.lines.length - 1);
    y += gaps[i] / 2;
  });
}

export function drawLayout(ctx: Ctx, l: Layout, s: SceneState) {
  switch (l.kind) {
    case 'hero':
      return hero(ctx, l, s);
    case 'versus':
      return versus(ctx, l, s);
    case 'path':
      return path(ctx, l, s);
    case 'verse':
      return verse(ctx, l, s);
    case 'cards':
      return cards(ctx, l, s);
    case 'fork':
      return fork(ctx, l, s);
    case 'quote':
      return quote(ctx, l, s);
  }
}

/** All element pop-in times of a layout (used to place sound effects). */
export function layoutTimes(l: Layout): { pops: number[]; shimmer: number[]; good: number[]; bad: number[] } {
  const r = { pops: [] as number[], shimmer: [] as number[], good: [] as number[], bad: [] as number[] };
  const add = (e?: El) => e && r.pops.push(e.at);
  switch (l.kind) {
    case 'hero':
      l.items.forEach(add);
      if (l.strikeAt != null) r.bad.push(l.strikeAt);
      if (l.verdict) (l.verdict.good ? r.good : r.bad).push(l.verdict.at);
      break;
    case 'versus':
      for (const sd of [l.right, l.left]) {
        r.pops.push(sd.at);
        sd.items.forEach(add);
        if (sd.verdict) (sd.verdict.good ? r.good : r.bad).push(sd.verdict.at);
      }
      break;
    case 'path':
      l.steps.forEach(add);
      break;
    case 'verse':
      r.shimmer.push(l.at);
      (l.items || []).forEach(add);
      break;
    case 'cards':
      l.items.forEach(add);
      break;
    case 'fork':
      add(l.from);
      add(l.up);
      add(l.down);
      add(l.note);
      (l.choose === 'up' ? r.good : r.bad).push(l.chooseAt + 1.4);
      break;
    case 'quote':
      l.lines.forEach((x) => r.pops.push(x.at));
      break;
  }
  return r;
}

// ------------------------------------------------------------------ backdrops
function ridge(ctx: Ctx, base: number, amp: number, freq: number, phase: number, top: string, stroke: string) {
  ctx.beginPath();
  ctx.moveTo(0, H);
  for (let x = 0; x <= W; x += 32) {
    ctx.lineTo(x, base + Math.sin(x * freq + phase) * amp + Math.sin(x * freq * 2.3 + phase * 1.7) * amp * 0.35);
  }
  ctx.lineTo(W, H);
  ctx.closePath();
  const g = ctx.createLinearGradient(0, base - amp, 0, H);
  g.addColorStop(0, top);
  g.addColorStop(1, 'rgba(4,7,18,0.9)');
  ctx.fillStyle = g;
  ctx.fill();
  ctx.strokeStyle = stroke;
  ctx.lineWidth = 1.6;
  ctx.stroke();
}

export function drawBackdrop(ctx: Ctx, kind: Backdrop, t: number, accent: string, accent2: string, alpha: number) {
  if (alpha <= 0.01 || kind === 'none') return;
  ctx.save();
  ctx.globalAlpha *= alpha;
  if (kind === 'hills' || kind === 'dunes') {
    ridge(ctx, 585, 26, 0.0042, 1.2, 'rgba(30,41,82,0.55)', withAlpha(accent, 0.2));
    ridge(ctx, 628, 20, 0.006, 4.0, 'rgba(18,26,58,0.7)', withAlpha(accent2, 0.22));
    if (kind === 'dunes') {
      for (const [x, y, k] of [
        [150, 578, 1],
        [232, 590, 0.7],
        [1100, 572, 0.9],
      ]) {
        ctx.fillStyle = 'rgba(8,12,28,0.85)';
        ctx.strokeStyle = withAlpha(accent, 0.35);
        ctx.beginPath();
        ctx.moveTo(x, y - 46 * k);
        ctx.lineTo(x + 42 * k, y);
        ctx.lineTo(x - 42 * k, y);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
      }
      drawIcon(ctx, 'moon', 1150, 150, 60, withAlpha(accent2, 0.5), t);
    }
  } else if (kind === 'waves') {
    for (let k = 0; k < 3; k++) {
      ctx.beginPath();
      ctx.moveTo(0, H);
      for (let x = 0; x <= W; x += 24) {
        ctx.lineTo(x, 590 + k * 22 + Math.sin(x * 0.011 + t * (0.7 + k * 0.25) + k * 2) * (11 - k * 2));
      }
      ctx.lineTo(W, H);
      ctx.closePath();
      ctx.fillStyle = withAlpha(k % 2 ? accent2 : accent, 0.1 + k * 0.03);
      ctx.fill();
      ctx.strokeStyle = withAlpha(accent, 0.22);
      ctx.lineWidth = 1.3;
      ctx.stroke();
    }
  } else if (kind === 'arches') {
    ctx.lineWidth = 2;
    for (const [cx, w, top, al] of [
      [640, 250, 92, 0.16],
      [160, 120, 250, 0.1],
      [1120, 120, 250, 0.1],
    ]) {
      for (let k = 0; k < 2; k++) {
        const ww = w - k * 16;
        const tp = top + k * 22;
        ctx.strokeStyle = withAlpha(k ? accent2 : accent, al);
        ctx.beginPath();
        ctx.moveTo(cx - ww, H);
        ctx.lineTo(cx - ww, tp + ww * 0.9);
        ctx.quadraticCurveTo(cx - ww, tp + ww * 0.25, cx, tp);
        ctx.quadraticCurveTo(cx + ww, tp + ww * 0.25, cx + ww, tp + ww * 0.9);
        ctx.lineTo(cx + ww, H);
        ctx.stroke();
      }
    }
  } else if (kind === 'rays') {
    ctx.translate(640, -60);
    for (let i = 0; i < 9; i++) {
      const a = Math.PI / 2 + (i - 4) * 0.19 + Math.sin(t * 0.25 + i) * 0.03;
      const g = ctx.createLinearGradient(0, 0, Math.cos(a) * 760, Math.sin(a) * 760);
      g.addColorStop(0, withAlpha(accent2, 0.13));
      g.addColorStop(1, withAlpha(accent2, 0));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(Math.cos(a - 0.045) * 780, Math.sin(a - 0.045) * 780);
      ctx.lineTo(Math.cos(a + 0.045) * 780, Math.sin(a + 0.045) * 780);
      ctx.closePath();
      ctx.fill();
    }
  } else if (kind === 'skyline') {
    ctx.fillStyle = 'rgba(6,9,22,0.6)';
    ctx.strokeStyle = withAlpha(accent, 0.25);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, H);
    ctx.lineTo(0, 628);
    const dome = (x: number, r: number) => {
      ctx.lineTo(x - r, 628);
      ctx.quadraticCurveTo(x - r * 1.1, 628 - r * 0.9, x, 628 - r * 1.5);
      ctx.quadraticCurveTo(x + r * 1.1, 628 - r * 0.9, x + r, 628);
    };
    const minaret = (x: number, h: number) => {
      ctx.lineTo(x - 7, 628);
      ctx.lineTo(x - 7, 628 - h);
      ctx.lineTo(x, 628 - h - 20);
      ctx.lineTo(x + 7, 628 - h);
      ctx.lineTo(x + 7, 628);
    };
    minaret(70, 110);
    dome(170, 52);
    minaret(270, 84);
    dome(420, 30);
    minaret(880, 84);
    dome(1010, 30);
    dome(1110, 52);
    minaret(1210, 110);
    ctx.lineTo(W, 628);
    ctx.lineTo(W, H);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }
  ctx.restore();
}
