// Data model of the film. ALL times are seconds of the original narration ("voice time").

export interface El {
  at: number;
  label: string;
  icon?: string;
  color?: string;
  sub?: string;
  bad?: boolean;
}

export interface Side {
  icon: string;
  name: string;
  sub?: string;
  color: string;
  at: number;
  items: El[];
  verdict?: { at: number; text: string; good: boolean };
}

export type Layout =
  | { kind: 'hero'; icon: string; title?: string; sub?: string; items: El[]; strikeAt?: number; color?: string; verdict?: { at: number; text: string; good: boolean } }
  | { kind: 'versus'; right: Side; left: Side; mid?: string }
  | { kind: 'path'; title?: string; steps: El[]; fall?: boolean }
  | { kind: 'verse'; ar: string; fa?: string; ref?: string; at: number; items?: El[] }
  | { kind: 'cards'; title?: string; items: El[] }
  | { kind: 'fork'; from: El; up: El; down: El; chooseAt: number; choose: 'up' | 'down'; note?: El }
  | { kind: 'quote'; icon?: string; lines: { at: number; text: string; color?: string; size?: number; ar?: boolean }[] };

export interface Phase {
  from: number;
  to: number;
  layout: Layout;
}

export type Backdrop = 'hills' | 'dunes' | 'waves' | 'arches' | 'rays' | 'skyline' | 'none';

export interface Chapter {
  id: number;
  title: string;
  badge: string;
  start: number;
  end: number;
  bgTop: string;
  bgBottom: string;
  accent: string;
  accent2: string;
  backdrop: Backdrop;
  phases: Phase[];
}

export interface Caption {
  s: number;
  e: number;
  text: string;
  hl?: boolean;
}

export interface SfxEvent {
  t: number;
  k: 'whoosh' | 'swish' | 'chime' | 'boom' | 'shimmer' | 'riser' | 'thud' | 'ding' | 'pop';
  g?: number;
}
